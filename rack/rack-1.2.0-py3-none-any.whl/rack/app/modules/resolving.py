from hio.base import doing
from hio.help import decking
from keri import core, kering
from keri.core import routing, eventing, parsing, serdering, coring
from keri.help import ogler
from mongoengine import connect, get_db

logger = ogler.getLogger()

def databaseInit(host, name, username=None, password=None):
    # Initialize the MongoDB client
    kwa = dict()

    if username:
        kwa["username"] = username

    if password:
        kwa["password"] = password

    connect(db=name, host=host, **kwa)


def get_resolver(keridb, aid: str, db_host, db_name, db_user, db_pass):
    cues = decking.Deck()
    rvy = routing.Revery(db=keridb, cues=cues)
    kvy = eventing.Kevery(db=keridb,
                          lax=True,
                          local=False,
                          rvy=rvy,
                          cues=cues)

    kvy.registerReplyRoutes(router=rvy.rtr)
    parser = parsing.Parser(kvy=kvy, rvy=rvy)  # removed hby from parser initialization

    databaseInit(host=db_host, name=db_name, username=db_user, password=db_pass)
    return CacheMissResolver(aid=aid, parser=parser)



class CacheMissResolver(doing.Doer):
    def __init__(self, aid: str, parser: parsing.Parser, msgs=None, **kwa):
        self.aid = aid
        self.parser = parser
        self.msgs = msgs if msgs is not None else decking.Deck()

        super(CacheMissResolver, self).__init__(**kwa)

    def recur(self, tyme=None):
        if self.msgs:
            cue = self.msgs.popleft()
            print(f"Resolving {len(self.msgs)} accounts: {cue}")
            pre = cue["pre"]

            kel = self.get_kel_direct_query(pre)
            if kel:
                try:
                    self.parser.parse(ims=bytearray(kel.encode("utf-8")), local=True)
                except Exception as e:
                    raise RuntimeError(f'An error occurred parsing kel into Kevery: {e}')

                logger.info(f"New or updated account added to {self.aid}: pre={pre}")


    @staticmethod
    def get_kel_direct_query(aid):
        """
        Direct query using MongoEngine's database access
        """
        db = get_db()

        try:
            # Direct query on the collection
            result = db.account.find_one({"_id": aid}, {"kel": 1})
            if result:
                return result.get("kel")
            else:
                if (team_server := db.team_server.find_one({"aid": aid})) is not None:
                    ims = CacheMissResolver.get_kel_stream(db, team_server["aid"])
                    return bytes(ims).decode("utf-8")

                return None
        except Exception as e:
            logger.error(f"Error in get_kel_direct_query: {e}")
            pass

        return None

    @staticmethod
    def get_kel_stream(db, aid, fn=0):
        events = db.event.find({"sad.i": aid}).sort("sn", 1)

        ims = bytearray()
        for event in events:
            atc = bytearray()  # attachments

            serder = serdering.SerderKERI(sad=event.get("sad"))
            ims.extend(serder.raw)

            sigs = event.get("sigs")
            atc.extend(core.Counter(code=core.Codens.ControllerIdxSigs,
                                    count=len(sigs), gvrsn=kering.Vrsn_1_0).qb64b)
            for sig in sigs:
                atc.extend(core.Siger(qb64=sig).qb64b)

            wigs = event.get("wigs")
            if wigs:
                atc.extend(core.Counter(code=core.Codens.WitnessIdxSigs,
                                        count=len(wigs), gvrsn=kering.Vrsn_1_0).qb64b)
                for wig in wigs:
                    atc.extend(core.Siger(qb64=wig).qb64b)

            if event.get("aes"):
                couple = event.get("aes")
                seqner = coring.Seqner(snh=couple["snh"])
                saider = coring.Saider(qb64=couple["said"])

                atc.extend(core.Counter(code=core.Codens.SealSourceCouples,
                                        count=1, gvrsn=kering.Vrsn_1_0).qb64b)
                atc.extend(seqner.qb64b)
                atc.extend(saider.qb64b)

            # add trans endorsement quadruples to attachments not controller
            # may have been originally key event attachments or receipted endorsements
            quads = event.get("vrcs")
            if quads:
                atc.extend(core.Counter(code=core.Codens.TransReceiptQuadruples,
                                        count=len(quads), gvrsn=kering.Vrsn_1_0).qb64b)
                for quad in quads:
                    prefixer = coring.Prefixer(qb64=quad["pre"])
                    seqner = coring.Seqner(snh=quad["snh"])
                    saider = coring.Saider(qb64=quad["said"])
                    siger = core.Siger(qb64=quad["sig"])

                    atc.extend(prefixer.qb64b)
                    atc.extend(seqner.qb64b)
                    atc.extend(saider.qb64b)
                    atc.extend(siger.qb64b)

            # add nontrans endorsement couples to attachments not witnesses
            # may have been originally key event attachments or receipted endorsements
            coups = event.get("rcts")
            if coups:
                atc.extend(core.Counter(code=core.Codens.NonTransReceiptCouples,
                                        count=len(coups), gvrsn=kering.Vrsn_1_0).qb64b)
                for coup in coups:
                    verfer = coring.Verfer(qb64=coup["verver"])
                    cigar = coring.Cigar(qb64=coup["cig"])

                    atc.extend(verfer.qb64b)
                    atc.extend(cigar.qb64b)

            # add first seen replay couple to attachments
            dts = coring.Dater(dts=event.get("dts"))
            atc.extend(core.Counter(code=core.Codens.FirstSeenReplayCouples,
                                    count=1, gvrsn=kering.Vrsn_1_0).qb64b)
            atc.extend(core.Number(num=fn, code=core.NumDex.Huge).qb64b)  # may not need to be Huge
            atc.extend(dts.qb64b)

            # prepend pipelining counter to attachments
            if len(atc) % 4:
                raise ValueError("Invalid attachments size={}, nonintegral"
                                 " quadlets.".format(len(atc)))
            pcnt = core.Counter(code=core.Codens.AttachmentGroup,
                                count=(len(atc) // 4), gvrsn=kering.Vrsn_1_0).qb64b
            ims.extend(pcnt)
            ims.extend(atc)

        return ims

