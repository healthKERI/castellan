# -*- encoding: utf-8 -*-
"""
rack.app.racking module

"""
import os
from pathlib import Path

from hio.core.http import ServerDoer
from keri import help
from keri.app import habbing, indirecting, configing
from keri.app.oobiing import Oobiery
from keri.vdr import credentialing
from prometheus_client import make_wsgi_app

from . import witnessing, delegating
from .routing import Router
from .watching import Watchmen, KeyStateVarianceAuthority
from ..core import basing, scheming
from ..core.moduling import ModuleLoader

logger = help.ogler.getLogger()
RACK_HAB_NAME = "rack"


def setup(name, metricsHost="127.0.0.1", metricsPort=9001, base=None, bran=None, cf=None):
    path = Path.home() / ".rack" / name
    if bran is None and os.path.exists(path):
        try:
            with open(path, "rt") as f:
                bran = f.read().rstrip("\n")
        except OSError:
            pass

    hby = habbing.Habery(name=name, base=base, bran=bran, cf=cf, temp=False)
    hbyDoer = habbing.HaberyDoer(habery=hby)
    hab = hby.habByName(RACK_HAB_NAME)

    cf = cf if cf is not None else configing.Configer(name=name,
                                                      base=base,
                                                      temp=hab.temp,
                                                      reopen=True)

    resolver = None
    config = cf.get()
    if "resolver" in config and "module_name" in config["resolver"]:
        resolver = config["resolver"]
        module_name = resolver["module_name"]
        function_name = resolver.get("function_name", None)
        search_path = resolver.get("search_path", [])
        params = resolver.get("params", {})
        params["keridb"] = hby.db
        params["aid"] = hab.pre

        try:
            loader = ModuleLoader(module_name, function_name, search_path, **params)
            if loader.load_module():
                resolver = loader.doer
                logger.info(f"Loading resolver module {module_name}.")
        except:
            logger.error(f"Unable to load resolver module {module_name}.")

    rt = basing.RouteTable(name=name, base=base, reopen=True, temp=False)
    eventer = witnessing.Eventer(hby=hby, hab=hab)
    rgy = credentialing.Regery(hby=hby, name=name, temp=False)
    routery = scheming.Routery(name=name, alias="rack", rt=rt, hby=hby, rgy=rgy)
    router = Router(hby=hby, rt=rt, routery=routery, cues=eventer.msgs, resolver=resolver)

    # Start Prometheus metrics endpoint
    app = make_wsgi_app()
    server = indirecting.createHttpServer(host=metricsHost, port=metricsPort, app=app)
    srvrDoer = ServerDoer(server=server)

    # Configure our mailbox director to read any rotation or delegated inception events
    oobiery = Oobiery(hby)
    mbd = indirecting.MailboxDirector(hby=hby, witnesses=False,
                                      topics=["/delegate", "/challenge"])

    watchmen = Watchmen(hby=hby, hab=hab, tock=60.0)
    kva = KeyStateVarianceAuthority(hby=hby, cues=watchmen.cues)
    delegation_resolver = delegating.ResolveDoer(rt=rt, hby=hby)

    doers = [hbyDoer, router, eventer, srvrDoer, mbd, watchmen, kva, *oobiery.doers, delegation_resolver]
    if resolver:
        doers.append(resolver)

    return doers
