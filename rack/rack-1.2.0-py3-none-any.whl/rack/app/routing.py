# -*- encoding: utf-8 -*-
"""
rack.app.routing module

"""
import random
import secrets

from hio.base import doing
from hio.help import decking
from keri import help
from keri import kering
from keri.core.serdering import SerderACDC

from . import delegating
from ..core.scheming import (LoadBalanceSchema, HttpOutboundSchema, HttpInboundSchema, HttpCallInboundSchema,
                             SftpInboundSchema, SftpOutboundSchema, RouterSchema, MllpInboundSchema, MllpOutboundSchema)
from ..proc import essr, http, tcp, sftp, mllp
from ..proc.http.serving import HttpSrvProcDoer
from ..proc.tcp.serving import TcpSrvProcDoer
from ..proc.sftp.serving import FilerDoer
from ..proc.mllp.serving import MLLPSrvProcDoer

logger = help.ogler.getLogger()


class Router(doing.DoDoer):

    def __init__(self, hby, rt, routery=None, cues=None, resolver=None):
        self.hby = hby
        self.rt = rt
        self.routery = routery
        self.sources = list()
        self.destinations = list()
        self.cues = cues if cues is not None else decking.Deck()
        self.misses = resolver.msgs if resolver else decking.Deck()

        self.routeProcesses = dict()
        self.scan = set()

        doers = self.setup()

        super(Router, self).__init__(doers=doers, always=True)

    def close(self):
        if self.rt:
            logger.info("Closing router database")
            self.rt.close()

    def setup(self):
        for route in self.rt.routes.values():
            self.addRoute(route_credential=route)

        doers = []
        for procs in self.routeProcesses.values():
            procs = [doer for doer in procs if doer not in doers]  # ensure unique
            doers.extend(procs)

        return doers

    def reload(self):
        doers = []
        for procs in self.routeProcesses.values():
            procs = [doer for doer in procs if doer not in doers]  # ensure unique
            doers.extend(procs)

        self.extend(doers)

    def addRoute(self, route_credential: SerderACDC):
        """ Add a new route to the router based on the provided credential

        Creates and configures route processors based on the schema type specified in the 
        route credential. Supports load balancing, HTTP inbound/outbound, and SFTP inbound/outbound
        route types.

        Parameters:
            route_credential (SerderACDC): The route credential containing configuration details
                                         and schema type for the route to be created

        The method stores created doers in self.routeProcesses using the credential SAID as key.
        """
        doers = []
        logger.info(f"Adding route {route_credential.said}")
        match route_credential.schema:
            case LoadBalanceSchema.said:
                doers.extend(self.create_load_balancer(route_credential))
            case RouterSchema.said:
                doers.extend(self.create_router(route_credential))
            case HttpOutboundSchema.said:
                doers.extend(self.create_http_outbound(route_credential))
            case HttpInboundSchema.said:
                doers.extend(self.create_http_inbound(route_credential))
            case HttpCallInboundSchema.said:
                doers.extend(self.create_httpcall_inbound(route_credential))
            case SftpInboundSchema.said:
                doers.extend(self.create_sftp_inbound(route_credential))
            case SftpOutboundSchema.said:
                doers.extend(self.create_sftp_outbound(route_credential))
            case MllpInboundSchema.said:
                doers.extend(self.create_mllp_inbound(route_credential))
            case MllpOutboundSchema.said:
                doers.extend(self.create_mllp_outbound(route_credential))

        self.routeProcesses[route_credential.said] = doers

    def create_load_balancer(self, route_credential: SerderACDC):
        """ Creates load balancer route processors based on provided route credential.

        Creates and configures TCP server, ESSR/DESSR processors, and routing filters to handle
        load balanced traffic across multiple destination hosts. The load balancer acts as a
        gateway that distributes incoming messages across configured destination endpoints.

        Parameters:
            route_credential (SerderACDC): The route credential containing configuration details
                                         including source AID, TCP host/port, and destination hosts

        Returns:
            list: List of configured processors (tcpsrv and filter) for handling load balanced routing
        """
        name = route_credential.said
        params = route_credential.attrib
        signer = params["aid"]

        tcp_params = params["tcpsrv"]
        host = tcp_params["host"]
        port = tcp_params["port"]

        tcpsrv = tcp.TcpSrvProc(router=self, name=name, src=signer, host=host, port=port,
                                params={}, misses=self.misses)
        top_dessr = essr.DessrProc(router=self, encryption_target=signer)
        top_essr = essr.EssrProc(router=self, signer=signer)

        procs = []
        doers = []

        if "essr_hosts" in params:
            for host_params in params["essr_hosts"]:
                aid = host_params["aid"]
                tcp_host = host_params["host"]
                tcp_port = host_params["port"]
                anchor = host_params.get("anchor", {})

                essr_proc = essr.EssrProc(router=self, signer=signer, encryption_target=aid, **anchor)
                tcp_proc = tcp.TcpProc(router=self, host=tcp_host, port=tcp_port, src=signer, dest=aid, params={})
                dessr_proc = essr.DessrProc(router=self, encryption_target=signer)

                inbound = decking.Deck()
                outbound = decking.Deck()
                flter = Filter(self, inbound, [essr_proc, tcp_proc, dessr_proc], outbound)
                procs.append(flter)
                doers.append(FilterDoer(flter))

        elif "http_hosts" in params:
            for host_params in params["http_hosts"]:
                http_host = host_params["host"]
                http_port = host_params["port"]

                http_proc = http.HttpProc(router=self, name=name, src=signer, host=http_host, port=http_port)
                procs.append(http_proc)
                doers.extend(http_proc.doers)

        remote_gateways = LoadBalancingFilter(self, inbound=decking.Deck(), procs=procs, outbound=decking.Deck())

        flter = Filter(self,
                       inbound=tcpsrv.outbound,
                       procs=[top_dessr, remote_gateways, top_essr],
                       outbound=tcpsrv.inbound)

        doers.extend([TcpSrvProcDoer(tcpsrv), FilterDoer(flter)])

        return doers


    def create_router(self, route_credential: SerderACDC):
        """ Creates router route processors based on provided route credential.

        Creates and configures TCP server, ESSR/DESSR processors, and routing filters to handle
        routed traffic by destinatiopn AID to multiple destination hosts. The router acts as a
        gateway that distributes incoming messages to the correct destination endpoints.

        Parameters:
            route_credential (SerderACDC): The route credential containing configuration details
                                         including source AID, TCP host/port, and destination hosts

        Returns:
            list: List of configured processors (tcpsrv and filter) for handling AID routed messages
        """
        name = route_credential.said
        params = route_credential.attrib
        signer = params["aid"]

        tcp_params = params["tcpsrv"]
        host = tcp_params["host"]
        port = tcp_params["port"]

        tcpsrv = tcp.TcpSrvProc(router=self, name=name, src=signer, host=host, port=port,
                                params={}, misses=self.misses)
        top_dessr = essr.DessrProc(router=self, encryption_target=signer)
        top_essr = essr.EssrProc(router=self, signer=signer)

        procs = []
        doers = []
        for host_params in params["hosts"]:
            name = host_params["name"]
            aid = host_params["aid"]
            tcp_host = host_params["host"]
            tcp_port = host_params["port"]
            anchor = host_params.get("anchor", {})

            essr_proc = essr.EssrProc(router=self, signer=signer, encryption_target=aid, **anchor)
            tcp_proc = tcp.TcpProc(router=self, host=tcp_host, port=tcp_port, src=signer, dest=aid, params={})
            dessr_proc = essr.DessrProc(router=self, encryption_target=signer)

            inbound = decking.Deck()
            outbound = decking.Deck()
            flter = Filter(self, inbound, [essr_proc, tcp_proc, dessr_proc], outbound)
            procs.append((aid, name, flter))
            doers.append(FilterDoer(flter))

        remote_gateways = RoutingFilter(self, inbound=decking.Deck(), procs=procs, outbound=decking.Deck())

        flter = Filter(self,
                       inbound=tcpsrv.outbound,
                       procs=[top_dessr, remote_gateways, top_essr],
                       outbound=tcpsrv.inbound)

        doers.extend([TcpSrvProcDoer(tcpsrv), FilterDoer(flter)])

        return doers

    def create_http_outbound(self, route_credential: SerderACDC):
        name = route_credential.said
        params = route_credential.attrib
        signer = params["aid"]

        httpsrv_params = params["httpsrv"]

        host = httpsrv_params["host"]
        port = httpsrv_params["port"]
        httpsrv = http.HttpSrvProc(router=self, name=name, src=signer, host=host, port=port, params=params)

        tcp_params = params["tcp"]
        aid = tcp_params["aid"]
        tcp_host = tcp_params["host"]
        tcp_port = tcp_params["port"]
        anchor = params.get("anchor", None)

        essr_proc = essr.EssrProc(router=self, signer=signer, encryption_target=aid, anchor=anchor)
        tcp_proc = tcp.TcpProc(router=self, host=tcp_host, port=tcp_port, src=signer, dest=aid, params={})
        dessr_proc = essr.DessrProc(router=self, encryption_target=signer)

        flter = Filter(self,
                       inbound=httpsrv.outbound,
                       procs=[essr_proc, tcp_proc, dessr_proc],
                       outbound=httpsrv.inbound)

        return [HttpSrvProcDoer(httpsrv), FilterDoer(flter)]

    def create_http_inbound(self, route_credential: SerderACDC):
        name = route_credential.said
        params = route_credential.attrib
        signer = params["aid"]
        logger.info(params)

        if params.get("tcprmt", None):
            tcp_params = params["tcprmt"]
            remote = True
        elif params.get("tcpsrv", None):
            tcp_params = params["tcpsrv"]
            remote = False
        else:
            raise ValueError("No TCP parameters provided")
        
        tcp_host = tcp_params["host"]
        tcp_port = tcp_params["port"]

        if not remote:
            tcpsrv = tcp.TcpSrvProc(router=self, name=name, src=signer, host=tcp_host, port=tcp_port,
                                    params={}, misses=self.misses)
        if remote:
            tcpsrv = tcp.TcpRemoteProc(router=self, src=signer, dest=tcp_params["aid"], host=tcp_host, port=tcp_port, params={})

        dessr_proc = essr.DessrProc(router=self, encryption_target=signer)

        http_params = params["http"]
        http_host = http_params["host"]
        http_port = http_params["port"]

        http_proc = http.HttpProc(router=self, name=name, src=signer, host=http_host, port=http_port)

        anchor = params.get("anchor", {})
        essr_proc = essr.EssrProc(router=self, signer=signer, encryption_target=None, **anchor)

        flter = Filter(self,
                       inbound=tcpsrv.outbound,
                       procs=[dessr_proc, http_proc, essr_proc],
                       outbound=tcpsrv.inbound)

        return [TcpSrvProcDoer(tcpsrv), FilterDoer(flter)]

    def create_sftp_inbound(self, route_credential:SerderACDC):
        name = route_credential.said
        params = route_credential.attrib
        signer = params["aid"]

        sftpsrv_params = params.get("sftp", {})
        base_path = sftpsrv_params.get("root")

        gateway_params = params["gateway"]
        gateway_aid = gateway_params["aid"]

        if params.get("tcprmt", None):
            tcp_params = params["tcprmt"]
            remote = True
        elif params.get("tcpsrv", None):
            tcp_params = params["tcpsrv"]
            remote = False
        else:
            raise ValueError("Either tcprmt or tcpsrv configuration is required")

        tcp_host = tcp_params["host"]
        tcp_port = tcp_params["port"]
        
        if not remote:
            tcpsrv = tcp.TcpSrvProc(router=self, name=name, src=signer, host=tcp_host, port=tcp_port,
                                    params={}, misses=self.misses)
        else:
            tcpsrv = tcp.TcpRemoteProc(router=self, src=signer, dest=gateway_aid, host=tcp_host, port=tcp_port, params={})

        dessr_proc = essr.DessrProc(router=self, encryption_target=signer)
        sftp_proc = sftp.SftpScannerProc(router=self, name=name, src=signer, base=base_path)
        anchor = params.get("anchor", {})
        essr_proc = essr.EssrProc(router=self, signer=signer, encryption_target=gateway_aid, **anchor)

        flter = Filter(self,
                       inbound=tcpsrv.outbound,
                       procs=[dessr_proc, sftp_proc, essr_proc],
                       outbound=tcpsrv.inbound,
                       label=f"sftp-inbound {signer} filter")

        return [TcpSrvProcDoer(tcpsrv), FilterDoer(flter)]

    def create_sftp_outbound(self, route_credential: SerderACDC):
        name = route_credential.said
        params = route_credential.attrib
        signer = params["aid"]

        sftpsrv_params = params.get("sftpsrv", {})
        base_path = sftpsrv_params.get("root")
        delete_original = sftpsrv_params.get("delete_original", True)

        sftpsrv = sftp.SftpPutProc(router=self, name=name, src=signer, base=base_path, delete=delete_original)

        tcp_params = params["tcp"]
        aid = tcp_params["aid"]
        tcp_host = tcp_params["host"]
        tcp_port = tcp_params["port"]
        anchor = params.get("anchor", None)

        essr_proc = essr.EssrProc(router=self, signer=signer, encryption_target=aid, anchor=anchor)
        tcp_proc = tcp.TcpProc(router=self, host=tcp_host, port=tcp_port, src=signer, dest=aid, params={})
        dessr_proc = essr.DessrProc(router=self, encryption_target=signer)

        flter = Filter(self,
                       inbound=sftpsrv.outbound,
                       procs=[essr_proc, tcp_proc, dessr_proc],
                       outbound=sftpsrv.inbound,
                       label=f"sftp-outbound {signer} filter")

        return [FilerDoer(sftpsrv), FilterDoer(flter)]

    def create_httpcall_inbound(self, route_credential: SerderACDC):
        name = route_credential.said
        params = route_credential.attrib
        signer = params["aid"]
        tcp_params = params["tcpsrv"]

        tcp_host = tcp_params["host"]
        tcp_port = tcp_params["port"]

        tcpsrv = tcp.TcpSrvProc(router=self, name=name, src=signer, host=tcp_host, port=tcp_port,
                                params={}, misses=self.misses)

        dessr_proc = essr.DessrProc(router=self, encryption_target=signer)

        http_params = params["httpcall"]
        http_app = http_params["app"]
        http_params = http_params["params"]

        http_proc = http.HttpCallProc(router=self, src=signer, app=http_app, **http_params)

        anchor = params.get("anchor", {})
        essr_proc = essr.EssrProc(router=self, signer=signer, encryption_target=None, **anchor)

        flter = Filter(self,
                       inbound=tcpsrv.outbound,
                       procs=[dessr_proc, http_proc, essr_proc],
                       outbound=tcpsrv.inbound)

        return [TcpSrvProcDoer(tcpsrv), FilterDoer(flter)]

    def create_mllp_outbound(self, route_credential: SerderACDC):
        """Create MLLP outbound route
        
        Creates a route that accepts MLLP messages on a server port and forwards them
        via TCP to a destination after ESSR encryption.
        
        Parameters:
            route_credential (SerderACDC): Route credential containing configuration
            
        Returns:
            list: List of doers for the MLLP outbound route
        """
        name = route_credential.said
        params = route_credential.attrib
        signer = params["aid"]

        mllpsrv_params = params["mllpsrv"]
        host = mllpsrv_params["host"]
        port = mllpsrv_params["port"]
        mllpsrv = mllp.MLLPSrvProc(router=self, name=name, src=signer, host=host, port=port, params=params)

        tcp_params = params["tcp"]
        aid = tcp_params["aid"]
        tcp_host = tcp_params["host"]
        tcp_port = tcp_params["port"]
        anchor = params.get("anchor", None)

        essr_proc = essr.EssrProc(router=self, signer=signer, encryption_target=aid, anchor=anchor)
        tcp_proc = tcp.TcpProc(router=self, host=tcp_host, port=tcp_port, src=signer, dest=aid, params={})
        dessr_proc = essr.DessrProc(router=self, encryption_target=signer)

        flter = Filter(self,
                       inbound=mllpsrv.outbound,
                       procs=[essr_proc, tcp_proc, dessr_proc],
                       outbound=mllpsrv.inbound)

        return [MLLPSrvProcDoer(mllpsrv), FilterDoer(flter)]

    def create_mllp_inbound(self, route_credential: SerderACDC):
        """Create MLLP inbound route
        
        Creates a route that accepts TCP messages on a server port, decrypts them,
        and forwards them via MLLP client to a destination.
        
        Parameters:
            route_credential (SerderACDC): Route credential containing configuration
            
        Returns:
            list: List of doers for the MLLP inbound route
        """
        name = route_credential.said
        params = route_credential.attrib
        signer = params["aid"]

        if params.get("tcprmt", None):
            tcp_params = params["tcprmt"]
            remote = True
        elif params.get("tcpsrv", None):
            tcp_params = params["tcpsrv"]
            remote = False
        else:
            raise ValueError("Either tcprmt or tcpsrv configuration is required")

        tcp_host = tcp_params["host"]
        tcp_port = tcp_params["port"]

        if not remote:
            tcpsrv = tcp.TcpSrvProc(router=self, name=name, src=signer, host=tcp_host, port=tcp_port,
                                    params={}, misses=self.misses)
        else:
            tcpsrv = tcp.TcpRemoteProc(router=self, src=signer, dest=signer, host=tcp_host, port=tcp_port, params={})

        dessr_proc = essr.DessrProc(router=self, encryption_target=signer)

        mllp_params = params["mllp"]
        mllp_host = mllp_params["host"]
        mllp_port = mllp_params["port"]

        # Create destination list for MLLP client 
        # For MLLP inbound, we need a dummy aid for the destination
        mllp_aid = f"mllp.{mllp_host}.{mllp_port}"  # Generate a consistent identifier
        dests = [(mllp_aid, mllp_host, mllp_port)]
        
        mllp_proc = mllp.MLLPProc(router=self, name=name, src=signer, dests=dests)

        anchor = params.get("anchor", {})
        essr_proc = essr.EssrProc(router=self, signer=signer, encryption_target=None, **anchor)

        flter = Filter(self,
                       inbound=tcpsrv.outbound,
                       procs=[dessr_proc, mllp_proc, essr_proc],
                       outbound=tcpsrv.inbound)

        return [TcpSrvProcDoer(tcpsrv), FilterDoer(flter)]

    @property
    def routes(self):
        return self.rt.routes if self.routery else {}

    def hab(self, aid):
        if (delegate := self.rt.cur.get(keys=(aid,))) is not None and delegate in self.hby.habs:
            return self.hby.habs[delegate]

        # We don't have a current signing delegate assigned, lets see if we can assign one.
        elif len(delegates := self.delegates(aid)) > 0:
            if delegates:  # if we have defined delegates, assign the first one as our current signer
                delegate = delegates[0]
                if delegate in self.hby.habs:
                    self.rt.cur.pin(keys=(aid,), val=delegate)
                    return self.hby.habs[delegate]

        elif aid in self.hby.habs:
            return self.hby.habs[aid]

        raise kering.ConfigurationError(f"Unable to find Hab for {aid}")

    def rotateSigner(self, aid):
        delegates = self.delegates(aid)
        if not delegates:
            raise kering.ConfigurationError(f"No delegates assigned for {aid}")

        if not (delegate := self.rt.cur.get(keys=(aid,))):
            if delegates:  # if we have defined delegates, assign the first one as our current signer
                delegate = delegates[0]
                if delegate in self.hby.habs:
                    self.rt.cur.pin(keys=(aid,), val=delegate)
        else:
            try:
                idx = delegates.index(delegate)
            except ValueError:
                delegate = delegates[0]
                if delegate in self.hby.habs:
                    self.rt.cur.pin(keys=(aid,), val=delegate)
            else:
                idx = (idx + 1) % len(delegates)
                delegate = delegates[idx]
                if delegate in self.hby.habs:
                    self.rt.cur.pin(keys=(aid,), val=delegate)

    def kever(self, aid):
        delegates = self.delegates(aid)
        if delegates:
            delegate = random.choice(delegates)
            if delegate in self.hby.kevers:
                return self.hby.kevers[delegate]
            else:
                raise kering.ConfigurationError(f"Unable to find kever for {aid}")
        elif aid in self.hby.kevers:
            return self.hby.kevers[aid]
        else:
            raise kering.ConfigurationError(f"Unable to find kever for {aid}")

    def delegates(self, aid):
        return self.rt.dlgs.get(keys=(aid,))

    def scanForDelegates(self, aid):
        if aid not in self.scan:
            delegating.scanForDelegates(self.hby, self.rt, aid)
            self.scan.add(aid)

    def shutdownInboundRoute(self, name):
        """ Shutdown an inbound route

        Parameters:
            name (str): Name of the route to be shutdown and deleted

        Returns:
            bool: True means everything was shutdown and deleted successfully

        """

        if (route := self.rt.inbs.get(keys=(name,))) is None:
            raise ValueError(f"{name} is not a valid inbound route")

        if self.shutdown(route):
            route.saids = list()
            route.lastPing = None
            self.rt.inbs.pin(keys=(name,), val=route)
            return True

        return False

    def shutdownOutboundRoute(self, name):
        """ Shutdown an outbound route

        Parameters:
            name (str): Name of the route to be shutdown and deleted

        Returns:
            bool: True means everything was shutdown and deleted successfully

        """
        if (route := self.rt.otbs.get(keys=(name,))) is None:
            raise ValueError(f"{name} is not a valid outbound route")

        if self.shutdown(route):
            route.saids = list()
            route.lastPing = None
            self.rt.otbs.pin(keys=(name,), val=route)
            return True

        return False

    def shutdownInboundSftpRoute(self, name):
        """ Shutdown an inbound route

        Parameters:
            name (str): Name of the route to be shutdown and deleted

        Returns:
            bool: True means everything was shutdown and deleted successfully

        """

        if (route := self.rt.inbSftps.get(keys=(name,))) is None:
            raise ValueError(f"{name} is not a valid inbound route")

        if self.shutdown(route):
            route.saids = list()
            route.lastPing = None
            self.rt.inbSftps.pin(keys=(name,), val=route)
            return True

        return False

    def shutdownOutboundSftpRoute(self, name):
        """ Shutdown an outbound route

        Parameters:
            name (str): Name of the route to be shutdown and deleted

        Returns:
            bool: True means everything was shutdown and deleted successfully

        """
        if (route := self.rt.otbSftps.get(keys=(name,))) is None:
            raise ValueError(f"{name} is not a valid outbound route")

        if self.shutdown(route):
            route.saids = list()
            route.lastPing = None
            self.rt.otbSftps.pin(keys=(name,), val=route)
            return True

        return False

    def shutdownInboundMllpRoute(self, name):
        """ Shutdown an inbound route

        Parameters:
            name (str): Name of the route to be shutdown and deleted

        Returns:
            bool: True means everything was shutdown and deleted successfully

        """

        if (route := self.rt.inbMllps.get(keys=(name,))) is None:
            raise ValueError(f"{name} is not a valid inbound route")

        if self.shutdown(route):
            route.saids = list()
            route.lastPing = None
            self.rt.inbMllps.pin(keys=(name,), val=route)
            return True

        return False

    def shutdownOutboundMllpRoute(self, name):
        """ Shutdown an outbound route

        Parameters:
            name (str): Name of the route to be shutdown and deleted

        Returns:
            bool: True means everything was shutdown and deleted successfully

        """
        if (route := self.rt.otbMllps.get(keys=(name,))) is None:
            raise ValueError(f"{name} is not a valid outbound route")

        if self.shutdown(route):
            route.saids = list()
            route.lastPing = None
            self.rt.otbMllps.pin(keys=(name,), val=route)
            return True

        return False

    def shutdownLoadBalancer(self, name):
        """ Shutdown a Load Balancer

        Parameters:
            name (str): Name of the Load Balancer to be shutdown and deleted

        Returns:
            bool: True means everything was shutdown and deleted successfully

        """
        if (route := self.rt.loadBalancers.get(keys=(name,))) is None:
            raise ValueError(f"{name} is not a valid outbound route")

        if self.shutdown(route):
            route.saids = list()
            route.lastPing = None
            self.rt.loadBalancers.pin(keys=(name,), val=route)
            return True

        return False

    def shutdownRouter(self, name):
        """ Shutdown a Load Balancer

        Parameters:
            name (str): Name of the Load Balancer to be shutdown and deleted

        Returns:
            bool: True means everything was shutdown and deleted successfully

        """
        if (route := self.rt.routers.get(keys=(name,))) is None:
            raise ValueError(f"{name} is not a valid outbound route")

        if self.shutdown(route):
            route.saids = list()
            route.lastPing = None
            self.rt.routers.pin(keys=(name,), val=route)
            return True

        return False


    def shutdown(self, route):
        """ Shutdown a given route preventing it from processing any additional messages.

        Stop route proc doers by removing from them hierarchy, delete the Rout records from the database,
        revoke the credentials and delete the credentials (and their TEL records) from the KERIpy databases.

        Parameters:
            route (Optional[InboundRoute|OutboundRoute]): Route record that is to be shutdown

        Returns:
            bool: True means everything was shutdown and deleted successfully

        """

        if not route.saids:
            raise ValueError(f"Route {route.name} is not current running")

        for said in route.saids:
            # Get the procs from the dict
            procs = self.routeProcesses.get(said, [])

            # First: Explicitly close all procs that have a close method
            for proc in procs:
                if hasattr(proc, 'close'):
                    logger.info(f"Closing {type(proc).__name__} for route {said}")
                    proc.close()

            # Second: Remove from doer hierarchy
            self.remove(procs)

            # Third: Clear from routeProcesses dict
            if said in self.routeProcesses:
                del self.routeProcesses[said]

            # Fourth: Delete the Rout record from the database and the credential
            self.routery.deleteRoute(said)

        return True


class Filter:
    """ Filter class for moving or blocking messages between sources and destinations """

    def __init__(self, router: Router, inbound: decking.Deck, procs: list, outbound: decking.Deck, label: str = None):
        """ Create Filter

        Parameters:
            router (Router): routing environment and Hab factory
            procs (list): The list of processors to route message through
            inbound (Deck): deck of inbound messages
            outbound (str): deck of outbound messages
            label (str): human readable label of this filter (for logging)

        """
        self.router = router
        self.inbound = inbound
        self.procs = procs
        self.outbound = outbound
        self.label = label

        self.ctxs = dict()

    def processInbound(self):
        while self.inbound:
            msg = self.inbound.pull()

            # Generate a unique message ID for this message.
            msgid = secrets.token_hex(8)  # 16 character hex string

            # Get existing context and save it to restore after this Filter is done
            ctx = msg.get("ctx", {})
            self.ctxs[msgid] = ctx

            # Replace existing context with the new one containing the messageID
            msg["ctx"] = dict(msgid=msgid)

            if self.label is not None:
                logger.info(f"{self.label}: msg recv.")

            self.procs[0].inbound.append(msg)

            if self.label is not None:
                logger.info(f"{self.label}: msg sent.")

    def processProcs(self):
        for i in range(len(self.procs) - 1):  # Exclude last proc, it's handled in processOutbound
            proc = self.procs[i]
            proc.service()
            while proc.outbound:
                msg = proc.outbound.popleft()
                self.procs[i + 1].inbound.append(msg)

                if self.label is not None:
                    logger.info(f"{self.label}: msg passed from {i} to {i + 1}.")

        last = self.procs[-1]
        last.service()

    def processOutbound(self):
        last = self.procs[-1]
        while last.outbound:
            msg = last.outbound.popleft()

            # Get internal context and replace it with the original context
            ctx = msg.get("ctx", {})
            msgid = ctx.get("msgid", None)

            if msgid:
                original_ctx = self.ctxs.get(msgid, {})
                msg["ctx"] = original_ctx

                # Delete the context, its no longer needed.
                del self.ctxs[msgid]

            self.outbound.append(msg)

    def service(self):
        self.processInbound()
        self.processProcs()
        self.processOutbound()

    def close(self):
        for proc in self.procs:
            proc.close()


class LoadBalancingFilter:
    """ Filter class for round-robin routing of messages between sources and destinations """

    def __init__(self, router: Router, inbound: decking.Deck, procs: list, outbound: decking.Deck, label: str = None):
        """ Create Filter

        Parameters:
            router (Router): routing environment and Hab factory
            procs (list): The list of processors to round-robin route message across
            inbound (Deck): deck of inbound messages
            outbound (str): deck of outbound messages
            label (str): human readable label of this filter (for logging)

        """
        self.router = router
        self.inbound = inbound
        self.procs = procs
        self.outbound = outbound
        self.label = label
        self.index = 0

        self.ctxs = dict()

    def processInbound(self):
        while self.inbound:
            msg = self.inbound.pull()

            # Generate a unique message ID for this message.
            msgid = secrets.token_hex(8)  # 16 character hex string

            # Get existing context and save it to restore after this Filter is done
            ctx = msg.get("ctx", {})
            self.ctxs[msgid] = ctx

            # Replace existing context with the new one containing the messageID
            msg["ctx"] = dict(msgid=msgid)

            if self.label is not None:
                logger.info(f"{self.label}: msg recv.")

            self.procs[self.index].inbound.append(msg)
            self.index = (self.index + 1) % len(self.procs)

            if self.label is not None:
                logger.info(f"{self.label}: msg sent to {self.index}.")

    def processProcs(self):
        """ Loop through all processors and move any new outbound messages to the filter outbound queue

        This method moves messages from the outbound queue of each processor to the outbound queue of this filter,
        after restoring the original context for each message.

        """
        for proc in self.procs:
            proc.service()
            while proc.outbound:
                msg = proc.outbound.popleft()

                ctx = msg.get("ctx", {})
                msgid = ctx.get("msgid")

                if msgid:
                    original_ctx = self.ctxs.get(msgid, {})
                    msg["ctx"] = original_ctx

                    # Delete the context, its no longer needed.
                    del self.ctxs[msgid]

                self.outbound.append(msg)

                if self.label is not None:
                    logger.info(f"{self.label}: msg passed from proc to outbound.")

    def service(self):
        self.processInbound()
        self.processProcs()

    def close(self):
        for proc in self.procs:
            proc.close()


class RoutingFilter:
    """ Filter class for round-robin routing of messages between sources and destinations """

    def __init__(self, router: Router, inbound: decking.Deck, procs: list, outbound: decking.Deck, label: str = None):
        """ Create Filter

        Parameters:
            router (Router): routing environment and Hab factory
            procs (list[tuple]): The list of destination AID, name and processor to route messages to via AID
            inbound (Deck): deck of inbound messages
            outbound (str): deck of outbound messages
            label (str): human readable label of this filter (for logging)

        """
        self.router = router
        self.inbound = inbound
        self.procs = {}

        for (aid, name, proc) in procs:
            self.procs[aid] = (name, proc)

        self.outbound = outbound
        self.label = label

        self.ctxs = dict()

    def processInbound(self):
        while self.inbound:
            msg = self.inbound.pull()

            dest = msg.get("dest", None)
            if not dest:
                logger.error(f"Message {msg} is missing a destination which is required for routing.")
                continue

            if dest not in self.procs:
                logger.error(f"Message {msg} is for an unknown destination {dest}.")
                continue

            name, proc = self.procs[dest]

            # Generate a unique message ID for this message.
            msgid = secrets.token_hex(8)  # 16 character hex string

            # Get existing context and save it to restore after this Filter is done
            ctx = msg.get("ctx", {})
            self.ctxs[msgid] = ctx

            # Replace existing context with the new one containing the messageID
            msg["ctx"] = dict(msgid=msgid)

            if self.label is not None:
                logger.info(f"{self.label}: msg recv.")

            proc.inbound.append(msg)

            if self.label is not None:
                logger.info(f"{self.label}: msg to {dest} sent to {name} proc.")

    def processProcs(self):
        """ Loop through all processors and move any new outbound messages to the filter outbound queue

        This method moves messages from the outbound queue of each processor to the outbound queue of this filter,
        after restoring the original context for each message.

        """
        for aid, (name, proc) in self.procs.items():
            proc.service()
            while proc.outbound:
                msg = proc.outbound.popleft()

                ctx = msg.get("ctx", {})
                msgid = ctx.get("msgid")

                if msgid:
                    original_ctx = self.ctxs.get(msgid, {})
                    msg["ctx"] = original_ctx

                    # Delete the context, its no longer needed.
                    del self.ctxs[msgid]

                self.outbound.append(msg)

                if self.label is not None:
                    logger.info(f"{self.label}: msg passed from proc to outbound.")

    def service(self):
        self.processInbound()
        self.processProcs()

    def close(self):
        for aid, (name, proc) in self.procs.items():
            proc.close()


class FilterDoer(doing.DoDoer):

    def __init__(self, flter: Filter, **kwa):
        self.flter = flter
        doers = []
        for proc in flter.procs:
            if hasattr(proc, "doers"):
                doers.extend(proc.doers)

        super(FilterDoer, self).__init__(doers=doers, always=True, **kwa)

    def recur(self, tyme, deeds=None):
        self.flter.service()

        return super(FilterDoer, self).recur(tyme, deeds)

    def exit(self, **kwargs):
        self.flter.close()
        super(self.__class__, self).exit()

