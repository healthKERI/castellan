# -*- encoding: utf-8 -*-
"""
rack.app.delegating module

"""
import getpass
import os
import stat
from dataclasses import dataclass
from pathlib import Path

import pyotp
import requests
from hio.base import doing
from hio.core import tcp
from hio.help import decking, Hict
from keri import help, kering
from keri.app import habbing, agenting, keeping, configing, oobiing
from keri.app.httping import CESR_DESTINATION_HEADER
from keri.core import serdering, coring, eventing
from keri.core.eventing import SealEvent
from keri.db import dbing
from keri.db.basing import OobiRecord
from keri.db.dbing import dgKey
from keri.help import helping
from keri.vdr import credentialing

from ..core.tcp import serving

logger = help.ogler.getLogger()


def setup(name, alias, bran=None, base=None, host="127.0.0.1", port=13633, maximum=12):
    path = Path.home() / ".rack" / name
    if bran is None and os.path.exists(path):
        try:
            with open(path, "rt") as f:
                bran = f.read().rstrip("\n")
        except OSError:
            pass

    hby = habbing.Habery(name=name, base=base, bran=bran, temp=False)
    hbyDoer = habbing.HaberyDoer(habery=hby)

    hab = hby.habByName(alias)

    server = tcp.Server(host=host, port=port)
    tcpSrvrDoer = tcp.ServerDoer(server=server)
    cues = decking.Deck()

    kvy = eventing.Kevery(db=hab.db, local=True)
    directant = serving.Directant(hab=hab, server=server, kvy=kvy, cues=cues)

    confirmDoer = ConfirmDoer(hby=hby, hab=hab, cues=cues, maximum=maximum)

    doers = [confirmDoer, tcpSrvrDoer, directant, hbyDoer]

    return doers


class ConfirmDoer(doing.DoDoer):

    def __init__(self, hby, hab, maximum=12, interact=True, cues=None, **kwa):
        self.hby = hby
        self.hab = hab
        self.maximum = maximum
        self.interact = interact
        self.cues = cues if cues is not None else decking.Deck()
        doers = [doing.doify(self.confirmDo)]
        super(ConfirmDoer, self).__init__(doers=doers, **kwa)

    def confirmDo(self, tymth, tock=0.0, **kwa):
        """
        Parameters:
            tymth (function): injected function wrapper closure returned by .tymen() of
                Tymist instance. Calling tymth() returns associated Tymist .tyme.
            tock (float): injected initial tock value

        Returns:  doifiable Doist compatible generator method
        """
        # enter context
        self.wind(tymth)
        self.tock = tock
        _ = (yield self.tock)

        while True:
            yield self.tock

            reqs = list()

            esc = self.escrowed()
            if len(esc) < self.maximum:
                yield self.tock
                continue

            for pre, sn, edig in esc:
                dgkey = dbing.dgKey(pre, edig)
                eraw = self.hby.db.getEvt(dgkey)
                if eraw is None:
                    continue

                eserder = serdering.SerderKERI(raw=bytes(eraw))  # escrowed event

                ilk = eserder.sad["t"]
                if ilk in (coring.Ilks.dip,):
                    delpre = eserder.sad["di"]

                elif ilk in (coring.Ilks.drt,):
                    dkever = self.hby.kevers[eserder.pre]
                    delpre = dkever.delpre

                else:
                    continue

                if delpre == self.hab.pre:
                    reqs.append((pre, sn, edig))

            print("The following delegation establishment events will be approved:")
            self.printAll(reqs)
            yield from self.approveAll(reqs)
            self.hby.kvy.processEscrowDelegables()
            self.removeEscrowed(reqs)

    def printAll(self, reqs):
        for (pre, sn, edig) in reqs:
            dgkey = dgKey(pre, edig)

            evt = self.hab.db.getEvt(dgkey)
            serder = serdering.SerderKERI(raw=bytes(evt))
            print(f"AID:  {pre}")
            print(f"Event Type:  {"Inception" if serder.ilk in (kering.Ilks.dip,) else "Rotation"}")
            print(f"Seq No.:  {serder.sn}")
            print(f"Signing Keys:")
            for idx, k in enumerate(serder.ked['k']):
                print(f"   {idx + 1}. {k}")
            print(f"Rotation Keys:")
            for idx, k in enumerate(serder.ked['n']):
                print(f"   {idx + 1}. {k}")
            print("\n")

    def rejectAll(self, reqs):
        pass

    def processEach(self, reqs):
        pass

    def approveAll(self, reqs):
        cur = self.hab.kever.sner.num

        anchors = list()
        for (pre, sn, edig) in reqs:
            dgkey = dgKey(pre, edig)
            raw = self.hab.db.getEvt(dgkey)
            serder = serdering.SerderKERI(raw=bytes(raw))
            anchors.append(dict(i=pre, s=serder.snh, d=edig))

        if self.interact:
            self.hab.interact(data=anchors)
        else:
            self.hab.rotate(data=anchors)

        if self.hab.kever.wits:
            c = codes(hab=self.hab)
            auths = dict()
            time = helping.nowIso8601()
            for wit, code in c.items():
                otp = pyotp.TOTP(s=c[wit])
                auths[wit] = f"{otp.at(helping.fromIso8601(time))}#{time}"

            receiptor = agenting.Receiptor(hby=self.hby)
            self.extend([receiptor])
            yield from receiptor.receipt(self.hab.pre, sn=self.hab.kever.sn, auths=auths)
            self.remove([receiptor])

        for (pre, sn, edig) in reqs:
            seqner = coring.Seqner(sn=self.hab.kever.serder.sn)
            couple = seqner.qb64b + self.hab.kever.serder.saidb
            dgkey = dbing.dgKey(pre, edig)
            self.hby.db.setAes(dgkey, couple)  # authorizer event seal (delegator/issuer)

        logger.info(f'Delegagtor Prefix  {self.hab.pre}: {len(reqs)} '
                    f'Delegate Events Anchored at Seq. No. {self.hab.kever.sner.num}')

        logger.info(f"Cueing up {dict(pre=self.hab.pre, sn=self.hab.kever.sner.num)}")
        self.cues.append(dict(pre=self.hab.pre, sn=self.hab.kever.sner.num))

    def escrowed(self):
        esc = []
        for (pre, sn), edig in self.hby.db.delegables.getItemIter():
            esc.append((pre, sn, edig))

        return esc

    def removeEscrowed(self, reqs):
        for (pre, sn, edig) in reqs:
            if not self.hby.db.delegables.rem(keys=(pre, sn)):
                self.hby.db.misfits.rem(keys=(pre, sn))


def codes(hab):
    cdes = dict()

    try:
        with open(Path.home() / ".rack" / hab.pre, "r") as f:
            lines = f.readlines()
            for line in lines:
                splits = line.split(':')
                if len(splits) != 2:
                    continue
                (aid, code) = splits
                cdes[aid] = code.rstrip()
    except OSError:
        pass

    return cdes


@dataclass
class InceptOptions:
    """ Options loaded from file parameter.

    """
    transferable: bool | None
    wits: list | None
    icount: int | None
    isith: int | str | list | None
    ncount: int | None
    nsith: int | str | list | None = '0'
    toad: int = 0
    delpre: str = None
    estOnly: bool = False
    data: list = None


def emptyOptions():
    """
    Initializes an empty inception options to be used only when required values are passed in at the command line
    """
    return InceptOptions(
        transferable=None, wits=None, icount=None, isith=None, ncount=None, nsith=None
    )


def init(args):
    name = args.name
    if name is None or name == "":
        raise kering.ConfigurationError("Name is required and can not be empty")

    base = args.base
    temp = args.temp
    bran = args.bran
    configFile = args.configFile
    configDir = args.configDir

    if not args.nopasscode and not bran:
        print("Creating encrypted keystore, please enter your 21 character passcode:")
        while True:
            bran = getpass.getpass("Passcode: ")
            retry = getpass.getpass("Re-enter passcode: ")

            if bran != retry:
                print("Passcodes do not match, try again.")
            else:
                break

    kwa = dict()
    kwa["salt"] = args.salt
    kwa["bran"] = bran
    kwa["aeid"] = args.aeid
    kwa["seed"] = args.seed
    if args.salt is None:
        kwa["algo"] = keeping.Algos.randy

    cf = None
    if configFile is not None:
        cf = configing.Configer(name=configFile,
                                base="",
                                headDirPath=configDir,
                                temp=False,
                                reopen=True,
                                clear=False)

    hby = habbing.Habery(name=name, base=base, temp=temp, cf=cf, **kwa)
    rgy = credentialing.Regery(hby=hby, name=name, base=base, temp=temp)

    print("KERI Keystore created at:", hby.ks.path)
    print("KERI Database created at:", hby.db.path)
    print("KERI Credential Store created at:", rgy.reger.path)
    if hby.mgr.aeid:
        print("\taeid:", hby.mgr.aeid)

    return hby, rgy


class Witness:
    name: str
    eid: str
    oobi: str
    secret: str


class Witnesser(doing.DoDoer):

    def __init__(self, hby, hab):
        self.hby = hby
        self.hab = hab
        self.wits = dict()
        self.msgs = decking.Deck()
        self.oobier = Oobier(hby=hby)

        doers = [self.oobier, doing.doify(self.witnessDo)]
        super(Witnesser, self).__init__(doers=doers, always=True)

    def witnessDo(self, tymth, tock=0.0, **kwa):
        # enter context
        self.wind(tymth)
        self.tock = tock
        _ = (yield self.tock)

        while True:
            if self.msgs:
                msg = self.msgs.pull()
                (name, eid, oobi) = msg
                witrec = Witness()
                witrec.name = name
                witrec.eid = eid
                witrec.oobi = oobi

                yield from self.oobier.oobi(witrec.name, witrec.oobi)
                witrec = self.witnessAuthenticate(witrec)
                self.wits[name] = witrec

            yield self.tock

    def witnessAuthenticate(self, witrec):
        body = bytearray()
        for msg in self.hab.db.clonePreIter(pre=self.hab.pre):
            body.extend(msg)

        fargs = dict(kel=(None, body.decode("utf-8"), "application/cesr"))

        if self.hab.kever.delegated:
            delkel = bytearray()
            for msg in self.hab.db.clonePreIter(self.hab.kever.delpre):
                delkel.extend(msg)

            fargs['delkel'] = (None, delkel.decode("utf-8"), "application/cesr")

        urls = (self.hab.fetchUrls(eid=witrec.eid, scheme=kering.Schemes.http)
                or self.hab.fetchUrls(eid=witrec.eid, scheme=kering.Schemes.https))
        if not urls:
            raise kering.MissingEntryError(f"unable to query witness {witrec.eid}, no http endpoint")

        url = urls[kering.Schemes.http] if kering.Schemes.http in urls else urls[kering.Schemes.https]
        headers = (Hict([
            (CESR_DESTINATION_HEADER, witrec.eid)
        ]))
        rep = requests.post(f"{url}/aids", files=fargs, headers=headers)
        data = rep.json()

        totp = data["totp"]
        m = coring.Matter(qb64=totp)  # refactor this to use cipher
        d = coring.Matter(qb64=self.hab.decrypt(ser=m.raw))
        otp = pyotp.TOTP(s=d.raw.decode('utf-8'), name=witrec.eid, issuer="Gator")

        mkdir(Path.home() / ".rack")

        auths = dict()
        path = Path.home() / ".rack" / self.hab.pre
        try:
            with open(path, "r") as f:
                lines = f.readlines()
                for line in lines:
                    splits = line.split(':')
                    if len(splits) != 2:
                        continue
                    (aid, code) = splits
                    auths[aid] = code
        except OSError:
            pass

        witrec.secret = otp.secret
        auths[witrec.eid] = otp.secret
        with open(path, "w") as f:
            for aid, code in auths.items():
                print(f"{aid}:{code.rstrip()}", file=f)

        os.chmod(path, stat.S_IRUSR | stat.S_IWUSR)
        print(f"Witness authentication code saved to {path}")
        return witrec

    @property
    def auths(self):
        codeTime = helping.nowIso8601()

        auths = dict()
        for wit in self.wits.values():
            otp = pyotp.TOTP(s=wit.secret)
            code = otp.at(helping.fromIso8601(codeTime))
            auths[wit.eid] = f"{code}#{codeTime}"

        return auths


def mkdir(dir_path):
    # Check if the directory exists
    if not os.path.exists(dir_path):
        # Create the directory
        os.makedirs(dir_path)
        print(f"Directory '{dir_path}' created.")

        # Set permissions to read/write for owner only (0o700 for directory)
        os.chmod(dir_path, stat.S_IRUSR | stat.S_IWUSR | stat.S_IXUSR)
        print(f"Permissions set to read/write/execute for owner only for '{dir_path}'.")


class Oobier(doing.DoDoer):

    def __init__(self, hby):
        self.hby = hby
        self.obi = oobiing.Oobiery(hby=self.hby)

        super(Oobier, self).__init__(doers=self.obi.doers, always=True)

    def oobi(self, name, oobi):
        obr = OobiRecord(date=helping.nowIso8601())
        obr.oobialias = name
        self.hby.db.oobis.put(keys=(oobi,), val=obr)

        while not self.obi.hby.db.roobi.get(keys=(oobi,)):
            yield 0.25

        obr = self.obi.hby.db.roobi.get(keys=(oobi,))
        print(oobi, obr.state)
        return obr


def makeRegistry(hab, rgy, registrar, registryName):
    registry = rgy.makeRegistry(name=registryName, prefix=hab.pre, noBackers=True)

    rseal = SealEvent(registry.regk, "0", registry.regd)
    rseal = dict(i=rseal.i, s=rseal.s, d=rseal.d)
    anc = hab.interact(data=[rseal])

    aserder = serdering.SerderKERI(raw=bytes(anc))
    registrar.incept(iserder=registry.vcp, anc=aserder)

    while not registrar.complete(pre=registry.regk, sn=0):
        rgy.processEscrows()
        yield

    return registry


def scanForDelegates(hby, rt, delegator):
    cloner = hby.db.clonePreIter(pre=delegator, fn=0)  # create iterator at 0
    rt.dlgs.rem(keys=(delegator,))
    for msg in cloner:
        srdr = serdering.SerderKERI(raw=msg)
        processDelegatorEventSeals(hby, rt, srdr)


def processDelegatorEventSeals(hby, rt, srdr):
    delegator = srdr.pre
    for anchor in srdr.seals:
        if 'i' not in anchor and 's' not in anchor and 'd' not in anchor:  # Event seal anchor
            continue

        delegate = anchor['i']
        if anchor['s'] != '0' or delegate != anchor['d']:  # Ensure this is an inception anchor
            continue

        delegateKever = hby.kevers[delegate]

        # Check for accidental registration of non-delegate or for a delegate that was neutered.
        if delegateKever.delpre != delegator or not delegateKever.ndigers:
            continue

        rt.dlgs.add(keys=(delegator,), val=delegate)

        logger.info(f"Signer {delegate} added for delegator {delegator}")


class ResolveDoer(doing.Doer):

    def __init__(self, rt, hby, **kwa):
        self.rt = rt
        self.hby = hby

        super(ResolveDoer, self).__init__(tock=3.0, **kwa)

    def recur(self, tyme):
        for (aid,), delegator in self.rt.gators.getItemIter():
            if delegator.local or delegator.resolved:
                continue

            if aid in self.hby.kevers:
                delegator.resolved = True
                self.hby.gators.pin(keys=(aid,), val=delegator)

        for (aid,), destination in self.rt.dsts.getItemIter():
            if destination.resolved:
                continue

            if aid in self.hby.kevers:
                destination.resolved = True
                self.rt.dsts.pin(keys=(aid,), val=destination)


class Delegatery:

    def __init__(self, hby, rt, hab):
        """ Factory for creating delegates for a give Delegator Hab1
        
        Parameters:
            hby (Habery):  database environment and Hab factory
            rt (RouteTable): RACK database environment 
            hab (Hab): delegator's hab
             
        """
        self.hby = hby
        self.rt = rt
        self.hab = hab

    def make(self, count=10, algo="randy", salt=None, icount=1, isith="1", ncount=1, nsith="1"):
        """ Create delegates from the delegator
        
        Parameters:
            count (int):  the number of delegates to create
            algo (str):  key generation algo, "salty" or "randy"
            salt: (str): 21 character length key generation salt
            icount (int): number of signing keys to create per delegate
            isith: (str): signing threshold
            ncount (int): number of rotation keys to create per delegate
            nsith: (str): rotation threshold

        Returns:
            list:  a list of delegate Habs

        """
        start = 0
        for hab in self.hby.habs.values():
            if hab.name.startswith(hab.name):
                start += 1

        anchors = list()
        delegates = list()
        for idx in range(count):
            alias = f"{self.hab.name}-{idx + start}"

            if self.hby.habByName(alias) is not None:
                raise ValueError(f"{alias} is already in use, please pick another alias prefix")

            kwargs = dict(algo=algo)
            if algo == 'salty':
                if salt is None or len(salt) != 24:
                    raise ValueError('Salt is required and must be 24 characters long')

                kwargs['salt'] = salt
                kwargs['icount'] = int(icount)
                kwargs['isith'] = int(isith)
                kwargs['ncount'] = int(ncount)
                kwargs['nsith'] = int(nsith)

            elif algo == 'randy':
                kwargs['salt'] = None
                kwargs['icount'] = int(icount)
                kwargs['isith'] = int(isith)
                kwargs['ncount'] = int(ncount)
                kwargs['nsith'] = int(nsith)

            kwargs['delpre'] = self.hab.pre
            kwargs['estOnly'] = False

            hab = self.hby.makeHab(name=alias, **kwargs)
            delegates.append(hab)
            anchors.append(dict(i=hab.pre, s="0", d=hab.pre))
            self.rt.dlgs.add(keys=(self.hab.pre,), val=hab.pre)

        self.hab.interact(data=anchors)

        for anchor in anchors:
            seqner = coring.Seqner(sn=self.hab.kever.serder.sn)
            couple = seqner.qb64b + self.hab.kever.serder.saidb
            dgkey = dbing.dgKey(anchor['i'], anchor['d'])
            self.hby.db.setAes(dgkey, couple)  # authorizer event seal (delegator/issuer)

        return delegates
