# -*- encoding: utf-8 -*-
"""
rack.app.ui.routering module

"""
import json
import math
import socket
from urllib.parse import urlparse

import falcon
from keri import kering
from keri.help import helping, ogler
from keri.kering import Schemes
from keri.vdr import credentialing

from rack.app.ui import templating
from rack.app.ui.templating import J2_ENV
from rack.core import scheming
from rack.core.basing import Router
from rack.core.scheming import Procs

logger = ogler.getLogger()


def loadEnds(app, router):
    routerCollectionEndpoint = RouterCollectionEnd(hby=router.hby, rt=router.rt)
    app.add_route("/routers", routerCollectionEndpoint)

    routerFormCreateEnd = RouterFormCreateEnd(hby=router.hby, rt=router.rt)
    app.add_route("/routers/forms/create", routerFormCreateEnd)

    routerFormDeleteEnd = RouterFormDeleteEnd(hby=router.hby, rt=router.rt)
    app.add_route("/routers/{name}/forms/delete", routerFormDeleteEnd)

    routerFormShutdownEnd = RouterFormShutdownEnd(hby=router.hby, rt=router.rt)
    app.add_route("/routers/{name}/forms/shutdown", routerFormShutdownEnd)

    routerResourceEnd = RouterResourceEnd(router=router)
    app.add_route("/routers/{name}", routerResourceEnd)

    routerLaunchEnd = RouterLaunchEnd(router=router, hby=router.hby, rt=router.rt)
    app.add_route("/routers/{name}/launch", routerLaunchEnd)

    routerExpResourceEnd = RouterExportResourceEnd(hby=router.hby, rt=router.rt)
    app.add_route("/routers/{name}/export", routerExpResourceEnd)


class RouterCollectionEnd:
    """ Router Collection Endpoint Class """

    def __init__(self, hby, rt):
        self.hby = hby
        self.rt = rt

    def on_get(self, req, rep):
        """ Router collection list endpoint

        Parameters:
            req (Request): Falcon HTTP request object
            rep (Response): Falcon HTTP response object
        """
        page = int(req.get_param("page", default=0))
        page_count = req.get_param("page_count", default=templating.PAGE_COUNT)

        start = page * page_count
        start = start + 1 if start > 0 else start

        count = 0
        routes = []
        for (name,), route in self.rt.routers.getItemIter():
            count += 1
            if count < start:
                continue

            hab = self.hby.habs[route.aid]

            r = dict(
                name=name,
                identifier=hab.name,
                tcpsrv=dict(
                    host=route.host,
                    port=route.port
                ) if route.host and route.port else None,
                hosts=route.hosts if route.hosts else [],
                saids=route.saids
            )

            if route.lastPing is not None:
                r['ping'] = helping.fromIso8601(route.lastPing).astimezone().strftime("%Y-%m-%d %H:%M:%S")

            if len(routes) == page_count:
                continue

            routes.append(r)

        data = dict(
            page=page,
            num_pages=math.ceil(count / page_count),
            count=count,
            routes=routes
        )

        template = J2_ENV.get_template('routers/routers.j2')

        rep.status = falcon.HTTP_200
        rep.content_type = "text/html"
        rep.text = template.render(page_title=f'RACK Administration - {self.hby.name}', tab="routers", **data)

    def _parse_hosts_from_form_data(self, data):
        """Parse hosts from form data into dictionary format"""
        hosts = []

        # Check if we have nested structure (HTMX converted format)
        if "hosts" in data and isinstance(data["hosts"], list):
            # Handle nested format: {"hosts": [{"aid": "...", "host": "...", "port": "...", "name": "..."}]}
            for host_info in data["hosts"]:
                if isinstance(host_info, dict):
                    host_aid = host_info.get("aid")
                    host_address = host_info.get("host")
                    host_port = host_info.get("port")
                    host_name = host_info.get("name", "")

                    if host_aid and host_address and host_port:
                        try:
                            host_port = int(host_port)
                            host_entry = {
                                "aid": host_aid,
                                "host": host_address,
                                "port": host_port,
                                "name": host_name
                            }
                            hosts.append(host_entry)
                        except (ValueError, TypeError):
                            raise ValueError(f"Invalid port number for host {host_address}")
        else:
            # Handle flat format: {"hosts[0][aid]": "...", "hosts[0][host]": "...", "hosts[0][port]": "...", "hosts[0][name]": "..."}
            host_indices = set()

            for key in data.keys():
                if key.startswith("hosts[") and "][" in key:
                    index_start = key.find("[") + 1
                    index_end = key.find("]")
                    index = int(key[index_start:index_end])
                    host_indices.add(index)

            for index in sorted(host_indices):
                host_aid = data.get(f"hosts[{index}][aid]")
                host_address = data.get(f"hosts[{index}][host]")
                host_port = data.get(f"hosts[{index}][port]")
                host_name = data.get(f"hosts[{index}][name]", "")

                if host_aid and host_address and host_port:
                    try:
                        host_port = int(host_port)
                        host_entry = {
                            "aid": host_aid,
                            "host": host_address,
                            "port": host_port,
                            "name": host_name
                        }
                        hosts.append(host_entry)
                    except (ValueError, TypeError):
                        raise ValueError(f"Invalid port number for host {host_address}")

        return hosts

    def on_post(self, req, rep):
        """ Create Router

        Parameters:
            req (Request): Falcon HTTP request object
            rep (Response): Falcon HTTP response object
        """
        data = req.media
        name = data.get("name", "")

        if not name:
            templating.error(rep, 'routers/create_router.j2', data,
                             msg="Name is required")
            return

        if self.rt.routers.get(keys=(name,)) is not None:
            templating.error(rep, 'routers/create_router.j2', data,
                             msg="Name is already in use as a router.")
            return

        aid = data.get("aid", None)
        if not aid:
            templating.error(rep, 'routers/create_router.j2', data,
                             msg="Local AID is required")
            return

        if aid not in self.hby.habs:
            templating.error(rep, 'routers/create_router.j2', data,
                             msg=f"{aid} is not a valid local source")
            return

        host = data.get("host", "127.0.0.1")
        port = int(data.get("port", 8080))

        try:
            hosts = self._parse_hosts_from_form_data(data)
        except ValueError as e:
            templating.error(rep, 'routers/create_router.j2', data, msg=str(e))
            return

        if not hosts:
            templating.error(rep, 'routers/create_router.j2', data,
                             msg="At least one host is required")
            return

        router = Router(
            aid=aid,
            host=host,
            port=port,
            hosts=hosts
        )

        router.anchoring = bool(data.get("anchoring", False))
        if router.anchoring:
            router.minimum = int(data.get("minimum", 0))
            router.maximum = int(data.get("maximum", 1000))
            router.frequency = int(data.get("frequency", 60))
            router.interval = data.get("interval", "minutes")
            router.interactions = int(data.get("interactions", 100))
            router.rotations = int(data.get("rotations", 100))
        else:
            router.minimum = 0
            router.maximum = 0
            router.frequency = 0
            router.interval = "minutes"
            router.interactions = 0
            router.rotations = 0

        self.rt.routers.pin(keys=(name,), val=router)
        self.rt.updateAidCounts()

        hxLocation = json.dumps({
            "path": f"/routers",
            "target": "body"
        })
        rep.set_header('HX-Location', hxLocation)
        rep.status = falcon.HTTP_200
        rep.text = b'Ok'


class RouterResourceEnd:
    def __init__(self, router):
        """

        Parameters:
            router (Router): Top level route coordinator

        """
        self.hby = router.hby
        self.rt = router.rt
        self.router = router

    def on_get(self, req, rep, name):
        """ Get a display of a router

        Args:
            req (Request): Falcon HTTP request object
            rep (Response): Falcon HTTP response object
            name (str): The name of the router

        Returns:

        """
        name = falcon.uri.decode(name)
        if (route := self.rt.routers.get(keys=(name,))) is None:
            templating.error(rep, "routers/edit_router.j2", dict(), f"{name} is not a valid router")
            return

        identifiers = []
        for (aid,), identifier in self.rt.gators.getItemIter():
            d = dict(aid=aid, alias=identifier.alias)
            identifiers.append(d)

        gateways = []
        for (aid,), destination in self.rt.dsts.getItemIter():
            d = dict(aid=aid, alias=destination.alias)
            gateways.append(d)

        ip_addresses = list()
        ip_addresses.append("0.0.0.0")
        hostname = socket.gethostname()

        for addr_info in socket.getaddrinfo(hostname, None):
            ip = addr_info[4][0]
            if ip not in ip_addresses:
                ip_addresses.append(ip)

        data = dict(
            name=name,
            route=route,
            identifiers=identifiers,
            gateways=gateways,
            ip_addresses=ip_addresses
        )

        template = J2_ENV.get_template("routers/edit_router.j2")

        rep.status = falcon.HTTP_200
        rep.content_type = "text/html"
        rep.text = template.render(page_title=f'RACK Edit Router - {self.hby.name}', **data)

    def _parse_hosts_from_form_data(self, data):
        """Parse hosts from form data into dictionary format"""
        hosts = []

        if "hosts" in data and isinstance(data["hosts"], list):
            # Handle nested format: {"hosts": [{"aid": "...", "host": "...", "port": "..."}]}
            for host_info in data["hosts"]:
                if isinstance(host_info, dict):
                    host_aid = host_info.get("aid")
                    host_address = host_info.get("host")
                    host_port = host_info.get("port")

                    if host_aid and host_address and host_port:
                        try:
                            host_port = int(host_port)
                            host_entry = {
                                "aid": host_aid,
                                "host": host_address,
                                "port": host_port
                            }
                            hosts.append(host_entry)
                        except (ValueError, TypeError):
                            raise ValueError(f"Invalid port number for host {host_address}")
        else:
            # Handle flat format: {"hosts[0][aid]": "...", "hosts[0][host]": "...", "hosts[0][port]": "..."}
            host_indices = set()

            for key in data.keys():
                if key.startswith("hosts[") and "][" in key:
                    index_start = key.find("[") + 1
                    index_end = key.find("]")
                    index = int(key[index_start:index_end])
                    host_indices.add(index)

            for index in sorted(host_indices):
                host_aid = data.get(f"hosts[{index}][aid]")
                host_address = data.get(f"hosts[{index}][host]")
                host_port = data.get(f"hosts[{index}][port]")

                if host_aid and host_address and host_port:
                    try:
                        host_port = int(host_port)
                        host_entry = {
                            "aid": host_aid,
                            "host": host_address,
                            "port": host_port
                        }
                        hosts.append(host_entry)
                    except (ValueError, TypeError):
                        raise ValueError(f"Invalid port number for host {host_address}")

        return hosts

    def on_post(self, req, rep, name):
        """ Router update endpoint

        Parameters:
            req (Request): Falcon HTTP request object
            rep (Response): Falcon HTTP response object
            name (str): The name of the router
        """
        name = falcon.uri.decode(name)
        data = req.media

        if (route := self.rt.routers.get(keys=(name,))) is None:
            templating.error(rep, 'routers/edit_router.j2', data,
                             msg=f"{name} is not a valid router.")
            return

        route.aid = data.get("aid", None)
        if not route.aid:
            templating.error(rep, 'routers/edit_router.j2', data,
                             msg="Local AID is required")
            return

        if route.aid not in self.hby.habs:
            templating.error(rep, 'routers/edit_router.j2', data,
                             msg=f"{route.aid} is not a valid local source")
            return

        route.host = data.get("host", "127.0.0.1")
        route.port = int(data.get("port", 8080))

        try:
            hosts = self._parse_hosts_from_form_data(data)
        except ValueError as e:
            templating.error(rep, 'routers/edit_router.j2', data, msg=str(e))
            return

        if not hosts:
            templating.error(rep, 'routers/edit_router.j2', data,
                             msg="At least one host is required")
            return

        route.hosts = hosts

        route.anchoring = bool(data.get("anchoring", False))
        if route.anchoring:
            route.minimum = int(data.get("minimum", 0))
            route.maximum = int(data.get("maximum", 1000))
            route.frequency = int(data.get("frequency", 60))
            route.interval = data.get("interval", "minutes")
            route.interactions = int(data.get("interactions", 100))
            route.rotations = int(data.get("rotations", 100))
        else:
            route.minimum = 0
            route.maximum = 0
            route.frequency = 0
            route.interval = "minutes"
            route.interactions = 0
            route.rotations = 0

        self.rt.routers.pin(keys=(name,), val=route)
        self.rt.updateAidCounts()

        hxLocation = json.dumps({
            "path": f"/routers",
            "target": "body"
        })
        rep.set_header('HX-Location', hxLocation)
        rep.status = falcon.HTTP_200
        rep.text = b'Ok'

    def on_delete(self, _, rep, name):
        """ Router delete endpoint

        Parameters:
            _ (Request): Falcon HTTP request object
            rep (Response): Falcon HTTP response object
            name (str): The name of the router
        """
        name = falcon.uri.decode(name)
        route = self.rt.routers.get(keys=(name,))

        if route is None:
            templating.error(rep, 'routers/edit_router.j2', dict(),
                             msg=f"Unable to delete router {name}.")
            return

        if not self.rt.routers.rem(keys=(name,)):
            templating.error(rep, 'routers/edit_router.j2', dict(),
                             msg=f"Unable to delete router {name}.")
            return

        self.rt.updateAidCounts()

        rep.status = falcon.HTTP_200
        hxLocation = json.dumps({
            "path": f"/routers",
            "target": "body"
        })
        rep.set_header('HX-Location', hxLocation)
        rep.text = b'Ok'

    def on_put(self, _, rep, name):
        """ Router shutdown endpoint

        Parameters:
            _ (Request): Falcon HTTP request object
            rep (Response): Falcon HTTP response object
            name (str): The name of the router
        """
        name = falcon.uri.decode(name)

        try:
            self.router.shutdownRouter(name)
        except ValueError as e:
            logger.info(e)
            templating.error(rep, 'routers/shutdown_router.j2', dict(),
                             msg=f"Unable to shutdown router {name}: {e}.")
            return

        rep.status = falcon.HTTP_200
        hxLocation = json.dumps({
            "path": f"/routers",
            "target": "body"
        })
        rep.set_header('HX-Location', hxLocation)
        rep.text = b'Ok'


class RouterLaunchEnd:
    def __init__(self, router, hby, rt):
        self.router = router
        self.hby = hby
        self.rt = rt

    def _create_fresh_connections(self):
        """Create fresh database connections for each operation"""
        rgy = credentialing.Regery(hby=self.hby, name=self.rt.name, temp=False)
        routery = scheming.Routery(name=self.rt.name, alias="rack", rt=self.rt, hby=self.hby, rgy=rgy)
        return rgy, routery

    def on_post(self, req, rep, name):
        """ Router launch endpoint

        Parameters:
            req (Request): Falcon HTTP request object
            rep (Response): Falcon HTTP response object
            name (str): The name of the router
        """
        name = falcon.uri.decode(name)
        data = req.media
        if (router := self.rt.routers.get(keys=(name,))) is None:
            templating.error(rep, 'launch_error_router.j2', data,
                             msg=f"{name} is not a valid router.")
            return

        if router.saids:
            templating.error(rep, 'launch_error_router.j2', data,
                             msg=f"{name} is already running.")
            return

        try:
            rgy, routery = self._create_fresh_connections()
            self.generateRouterRoutes(name, router, routery)
        except ValueError as e:
            templating.error(rep, 'routers/edit_router.j2', dict(),
                             msg=f"{e}")
            return

        hxLocation = json.dumps({
            "path": f"/routers",
            "target": "body"
        })
        rep.set_header('HX-Location', hxLocation)
        rep.status = falcon.HTTP_200
        rep.text = b'Ok'

    def generateRouterRoutes(self, name, router, routery):
        """ Generate routes for a Router

        Parameters:
            name (str): Name of the route group
            router (Router): The database definition of the router to generate
            routery (Routery): Fresh routery instance for route creation

        """
        router.saids = list()

        routeType = "router"
        config = self._build_route_config(router)
        route = routery.makeRoute(name=name, route_type=routeType, config=config)

        self.router.addRoute(routery.routes[route.said])
        self.router.reload()
        router.saids.append(route.said)
        self.rt.routers.pin(keys=(name,), val=router)
        logger.info(f"Router {name} launched: {router}")

    def _build_route_config(self, router):
        """Build router route configuration from route data"""
        aid = router.aid
        host = router.host or "127.0.0.1"
        port = router.port or 8080
        hosts = router.hosts or []

        if not hosts:
            raise ValueError("At least one host is required")

        hosts_config = []

        for host_dict in hosts:
            host_config = {
                "aid": host_dict["aid"],
                "host": host_dict["host"],
                "port": host_dict["port"],
                "name": self.rt.dsts.get(host_dict["aid"]).alias
            }

            if host_dict.get('minimum'):
                host_config["anchor"] = {
                    "minimum": host_dict.get('minimum'),
                    "maximum": host_dict.get('maximum'),
                    "frequency": host_dict.get('frequency'),
                    "interval": host_dict.get('interval'),
                    "interactions": host_dict.get('interactions'),
                    "rotations": host_dict.get('rotations')
                }

            hosts_config.append(host_config)

        config = {
            "aid": aid,
            "tcpsrv": {
                "host": host,
                "port": port
            },
            "hosts": hosts_config
        }

        if router.anchoring:
            config["anchor"] = {
                "minimum": router.minimum,
                "maximum": router.maximum,
                "frequency": router.frequency,
                "interval": router.interval,
                "interactions": router.interactions,
                "rotations": router.rotations
            }

        return config

class RouterFormCreateEnd:
    def __init__(self, hby, rt):
        self.hby = hby
        self.rt = rt

    def on_get(self, _, rep):
        """ Create Router form endpoint

        Parameters:
            _ (Request): Falcon HTTP request object
            rep (Response): Falcon HTTP response object
        """

        identifiers = []
        for (aid,), identifier in self.rt.gators.getItemIter():
            d = dict(aid=aid, alias=identifier.alias)
            identifiers.append(d)

        gateways = []
        for (aid,), destination in self.rt.dsts.getItemIter():
            d = dict(aid=aid, alias=destination.alias)
            gateways.append(d)

        ip_addresses = list()
        ip_addresses.append("0.0.0.0")
        hostname = socket.gethostname()

        for addr_info in socket.getaddrinfo(hostname, None):
            ip = addr_info[4][0]
            if ip not in ip_addresses:
                ip_addresses.append(ip)

        data = dict(
            identifiers=identifiers,
            gateways=gateways,
            ip_addresses=ip_addresses
        )

        template = J2_ENV.get_template('routers/create_router.j2')

        rep.status = falcon.HTTP_200
        rep.content_type = "text/html"
        rep.text = template.render(page_title=f'RACK Create Router - {self.hby.name}', **data)


class RouterFormDeleteEnd:
    def __init__(self, hby, rt):
        self.hby = hby
        self.rt = rt

    def on_get(self, _, rep, name):
        """ Router delete form endpoint

        Parameters:
            _ (Request): Falcon HTTP request object
            rep (Response): Falcon HTTP response object
            name (str): name of router

        """
        name = falcon.uri.decode(name)
        if (route := self.rt.routers.get(keys=(name,))) is None:
            templating.error(rep, "routers/delete_router.j2", dict(), f"{name} is not a valid router")
            return

        data = dict(
            name=name,
            route=route
        )

        template = J2_ENV.get_template('routers/delete_router.j2')

        rep.status = falcon.HTTP_200
        rep.content_type = "text/html"
        rep.text = template.render(page_title=f'RACK Delete Router - {self.hby.name}', **data)


class RouterFormShutdownEnd:
    def __init__(self, hby, rt):
        self.hby = hby
        self.rt = rt

    def on_get(self, _, rep, name):
        """ Router shutdown form endpoint

        Parameters:
            _ (Request): Falcon HTTP request object
            rep (Response): Falcon HTTP response object
            name (str): name of router

        """
        name = falcon.uri.decode(name)
        if (route := self.rt.routers.get(keys=(name,))) is None:
            templating.error(rep, "routers/shutdown_router.j2", dict(), f"{name} is not a valid router")
            return

        data = dict(
            name=name,
            route=route
        )

        template = J2_ENV.get_template('routers/shutdown_router.j2')

        rep.status = falcon.HTTP_200
        rep.content_type = "text/html"
        rep.text = template.render(page_title=f'RACK Shutdown Router - {self.hby.name}', **data)


class RouterExportResourceEnd:
    def __init__(self, hby, rt):
        self.hby = hby
        self.rt = rt

    def on_get(self, _, rep, name):
        """ Export Router configuration

        Args:
            _ (Request): Falcon HTTP request object
            rep (Response): Falcon HTTP response object
            name (str): The name of the router

        Returns:

        """
        name = falcon.uri.decode(name)
        if (route := self.rt.routers.get(keys=(name,))) is None:
            templating.error(rep, "routers/view_router.j2", dict(), f"{name} is not a valid router")
            return

        hab = self.hby.habs[route.aid]

        ims = hab.replyToOobi(aid=hab.pre, role=kering.Roles.gateway)

        for _, delegate in self.rt.dlgs.getItemIter(keys=(hab.pre,)):
            for msg in hab.db.clonePreIter(pre=delegate, fn=0):
                ims.extend(msg)

        rep.status = falcon.HTTP_200
        rep.content_type = "application/cesr"
        rep.set_header("Content-Disposition", f"attachment; filename=\"{self.hby.name}-{name}-router.cesr\"")
        rep.data = ims