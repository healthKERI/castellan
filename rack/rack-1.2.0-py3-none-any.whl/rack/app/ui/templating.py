# -*- encoding: utf-8 -*-
"""
KERI
rack.app.ui.templating package

"""
import falcon
import jinja2

PAGE_COUNT = 10
J2_ENV = jinja2.Environment()


def error(rep, template, data, msg):
    data['error'] = msg
    template = J2_ENV.get_template(template)
    rep.status = falcon.HTTP_200
    rep.content_type = "text/html"
    rep.text = template.render(page_title='RACK Administration', **data)

    return
