# -*- encoding: utf-8 -*-
"""
rack.app.ui.balancing module

"""
import json
import math
import socket
from urllib.parse import urlparse

import falcon
from keri import kering
from keri.help import helping, ogler
from keri.kering import Schemes
from keri.vdr import credentialing

from rack.app.ui import templating
from rack.app.ui.templating import J2_ENV
from rack.core import scheming
from rack.core.basing import LoadBalancer
from rack.core.scheming import Procs

logger = ogler.getLogger()


def loadEnds(app, router):
    loadBalancerCollectionEndpoint = LoadBalancerCollectionEnd(hby=router.hby, rt=router.rt)
    app.add_route("/load", loadBalancerCollectionEndpoint)

    loadBalancerFormCreateEnd = LoadBalancerFormCreateEnd(hby=router.hby, rt=router.rt)
    app.add_route("/load/forms/create", loadBalancerFormCreateEnd)

    loadBalancerFormDeleteEnd = LoadBalancerFormDeleteEnd(hby=router.hby, rt=router.rt)
    app.add_route("/load/{name}/forms/delete", loadBalancerFormDeleteEnd)

    loadBalancerFormShutdownEnd = LoadBalancerFormShutdownEnd(hby=router.hby, rt=router.rt)
    app.add_route("/load/{name}/forms/shutdown", loadBalancerFormShutdownEnd)

    loadBalancerResourceEnd = LoadBalancerResourceEnd(router=router)
    app.add_route("/load/{name}", loadBalancerResourceEnd)

    loadBalancerLaunchEnd = LoadBalancerLaunchEnd(router=router, hby=router.hby, rt=router.rt)
    app.add_route("/load/{name}/launch", loadBalancerLaunchEnd)

    loadBalancerExpResourceEnd = LoadBalancerExportResourceEnd(hby=router.hby, rt=router.rt)
    app.add_route("/load/{name}/export", loadBalancerExpResourceEnd)


class LoadBalancerCollectionEnd:
    """ Load Balancer Collection Endpoint Class """

    def __init__(self, hby, rt):
        self.hby = hby
        self.rt = rt

    def on_get(self, req, rep):
        """ Load balancer collection list endpoint

        Parameters:
            req (Request): Falcon HTTP request object
            rep (Response): Falcon HTTP response object
        """
        page = int(req.get_param("page", default=0))
        page_count = req.get_param("page_count", default=templating.PAGE_COUNT)

        start = page * page_count
        start = start + 1 if start > 0 else start

        count = 0
        routes = []
        for (name,), route in self.rt.loadBalancers.getItemIter():
            count += 1
            if count < start:
                continue

            hab = self.hby.habs[route.aid]

            r = dict(
                name=name,
                identifier=hab.name,
                tcpsrv=dict(
                    host=route.host,
                    port=route.port
                ) if route.host and route.port else None,
                hosts=route.hosts if route.hosts else [],
                saids=route.saids
            )

            if route.lastPing is not None:
                r['ping'] = helping.fromIso8601(route.lastPing).astimezone().strftime("%Y-%m-%d %H:%M:%S")

            if len(routes) == page_count:
                continue

            routes.append(r)

        data = dict(
            page=page,
            num_pages=math.ceil(count / page_count),
            count=count,
            routes=routes
        )

        template = J2_ENV.get_template('load/load_balancers.j2')

        rep.status = falcon.HTTP_200
        rep.content_type = "text/html"
        rep.text = template.render(page_title=f'RACK Administration - {self.hby.name}', tab="load_balancers", **data)

    def _parse_hosts_from_form_data(self, data):
        """Parse hosts from form data into dictionary format"""
        hosts = []

        # Check if we have nested structure (HTMX converted format)
        if "hosts" in data and isinstance(data["hosts"], list):
            # Handle nested format: {"hosts": [{"aid": "...", "host": "...", "port": "..."}]}
            for host_info in data["hosts"]:
                if isinstance(host_info, dict):
                    host_aid = host_info.get("aid")
                    host_address = host_info.get("host")
                    host_port = host_info.get("port")

                    if host_aid and host_address and host_port:
                        try:
                            host_port = int(host_port)
                            host_entry = {
                                "aid": host_aid,
                                "host": host_address,
                                "port": host_port
                            }
                            hosts.append(host_entry)
                        except (ValueError, TypeError):
                            raise ValueError(f"Invalid port number for host {host_address}")
        else:
            host_indices = set()

            for key in data.keys():
                if key.startswith("hosts[") and "][" in key:
                    index_start = key.find("[") + 1
                    index_end = key.find("]")
                    index = int(key[index_start:index_end])
                    host_indices.add(index)

            for index in sorted(host_indices):
                host_aid = data.get(f"hosts[{index}][aid]")
                host_address = data.get(f"hosts[{index}][host]")
                host_port = data.get(f"hosts[{index}][port]")

                if host_aid and host_address and host_port:
                    try:
                        host_port = int(host_port)
                        host_entry = {
                            "aid": host_aid,
                            "host": host_address,
                            "port": host_port
                        }
                        hosts.append(host_entry)
                    except (ValueError, TypeError):
                        raise ValueError(f"Invalid port number for host {host_address}")

        return hosts

    def on_post(self, req, rep):
        """ Create Load Balancer

        Parameters:
            req (Request): Falcon HTTP request object
            rep (Response): Falcon HTTP response object
        """
        data = req.media
        name = data.get("name", "")

        if not name:
            templating.error(rep, 'load/create_load_balancer.j2', data,
                             msg="Name is required")
            return

        if self.rt.loadBalancers.get(keys=(name,)) is not None:
            templating.error(rep, 'load/create_load_balancer.j2', data,
                             msg="Name is already in use as a load balancer.")
            return

        aid = data.get("aid", None)
        if not aid:
            templating.error(rep, 'load/create_load_balancer.j2', data,
                             msg="Local AID is required")
            return

        if aid not in self.hby.habs:
            templating.error(rep, 'load/create_load_balancer.j2', data,
                             msg=f"{aid} is not a valid local source")
            return

        host = data.get("host", "127.0.0.1")
        port = int(data.get("port", 8080))

        try:
            hosts = self._parse_hosts_from_form_data(data)
        except ValueError as e:
            templating.error(rep, 'load/create_load_balancer.j2', data, msg=str(e))
            return

        if not hosts:
            templating.error(rep, 'load/create_load_balancer.j2', data,
                             msg="At least one host is required")
            return

        lb = LoadBalancer(
            aid=aid,
            host=host,
            port=port,
            hosts=hosts
        )

        lb.anchoring = bool(data.get("anchoring", False))
        if lb.anchoring:
            lb.minimum = int(data.get("minimum", 0))
            lb.maximum = int(data.get("maximum", 1000))
            lb.frequency = int(data.get("frequency", 60))
            lb.interval = data.get("interval", "minutes")
            lb.interactions = int(data.get("interactions", 100))
            lb.rotations = int(data.get("rotations", 100))
        else:
            lb.minimum = 0
            lb.maximum = 0
            lb.frequency = 0
            lb.interval = "minutes"
            lb.interactions = 0
            lb.rotations = 0

        self.rt.loadBalancers.pin(keys=(name,), val=lb)
        self.rt.updateAidCounts()

        hxLocation = json.dumps({
            "path": f"/load",
            "target": "body"
        })
        rep.set_header('HX-Location', hxLocation)
        rep.status = falcon.HTTP_200
        rep.text = b'Ok'


class LoadBalancerResourceEnd:
    def __init__(self, router):
        """

        Parameters:
            router (Router): Top level route coordinator

        """
        self.hby = router.hby
        self.rt = router.rt
        self.router = router

    def on_get(self, req, rep, name):
        """ Get a display of a load balancer

        Args:
            req (Request): Falcon HTTP request object
            rep (Response): Falcon HTTP response object
            name (str): The name of the load balancer

        Returns:

        """
        name = falcon.uri.decode(name)
        if (route := self.rt.loadBalancers.get(keys=(name,))) is None:
            templating.error(rep, "load/edit_load_balancer.j2", dict(), f"{name} is not a valid load balancer")
            return

        identifiers = []
        for (aid,), identifier in self.rt.gators.getItemIter():
            d = dict(aid=aid, alias=identifier.alias)
            identifiers.append(d)

        ip_addresses = list()
        ip_addresses.append("0.0.0.0")
        hostname = socket.gethostname()

        for addr_info in socket.getaddrinfo(hostname, None):
            ip = addr_info[4][0]
            if ip not in ip_addresses:
                ip_addresses.append(ip)

        data = dict(
            name=name,
            route=route,
            identifiers=identifiers,
            ip_addresses=ip_addresses
        )

        template = J2_ENV.get_template("load/edit_load_balancer.j2")

        rep.status = falcon.HTTP_200
        rep.content_type = "text/html"
        rep.text = template.render(page_title=f'RACK Edit Load Balancer - {self.hby.name}', **data)

    def _parse_hosts_from_form_data(self, data):
        """Parse hosts from form data into dictionary format"""
        hosts = []

        # Check if we have nested structure (HTMX converted format)
        if "hosts" in data and isinstance(data["hosts"], list):
            # Handle nested format: {"hosts": [{"aid": "...", "host": "...", "port": "..."}]}
            for host_info in data["hosts"]:
                if isinstance(host_info, dict):
                    host_aid = host_info.get("aid")
                    host_address = host_info.get("host")
                    host_port = host_info.get("port")

                    if host_aid and host_address and host_port:
                        try:
                            host_port = int(host_port)
                            host_entry = {
                                "aid": host_aid,
                                "host": host_address,
                                "port": host_port
                            }
                            hosts.append(host_entry)
                        except (ValueError, TypeError):
                            raise ValueError(f"Invalid port number for host {host_address}")
        else:
            # Handle flat format: {"hosts[0][aid]": "...", "hosts[0][host]": "...", "hosts[0][port]": "..."}
            host_indices = set()

            for key in data.keys():
                if key.startswith("hosts[") and "][" in key:
                    index_start = key.find("[") + 1
                    index_end = key.find("]")
                    index = int(key[index_start:index_end])
                    host_indices.add(index)

            for index in sorted(host_indices):
                host_aid = data.get(f"hosts[{index}][aid]")
                host_address = data.get(f"hosts[{index}][host]")
                host_port = data.get(f"hosts[{index}][port]")

                if host_aid and host_address and host_port:
                    try:
                        host_port = int(host_port)
                        host_entry = {
                            "aid": host_aid,
                            "host": host_address,
                            "port": host_port
                        }
                        hosts.append(host_entry)
                    except (ValueError, TypeError):
                        raise ValueError(f"Invalid port number for host {host_address}")

        return hosts

    def on_post(self, req, rep, name):
        """ Load balancer update endpoint

        Parameters:
            req (Request): Falcon HTTP request object
            rep (Response): Falcon HTTP response object
            name (str): The name of the load balancer
        """
        name = falcon.uri.decode(name)
        data = req.media

        if (route := self.rt.loadBalancers.get(keys=(name,))) is None:
            templating.error(rep, 'load/edit_load_balancer.j2', data,
                             msg=f"{name} is not a valid load balancer.")
            return

        route.aid = data.get("aid", None)
        if not route.aid:
            templating.error(rep, 'load/edit_load_balancer.j2', data,
                             msg="Local AID is required")
            return

        if route.aid not in self.hby.habs:
            templating.error(rep, 'load/edit_load_balancer.j2', data,
                             msg=f"{route.aid} is not a valid local source")
            return

        route.host = data.get("host", "127.0.0.1")
        route.port = int(data.get("port", 8080))

        try:
            hosts = self._parse_hosts_from_form_data(data)
        except ValueError as e:
            templating.error(rep, 'load/edit_load_balancer.j2', data, msg=str(e))
            return

        if not hosts:
            templating.error(rep, 'load/edit_load_balancer.j2', data,
                             msg="At least one host is required")
            return

        route.hosts = hosts

        route.anchoring = bool(data.get("anchoring", False))
        if route.anchoring:
            route.minimum = int(data.get("minimum", 0))
            route.maximum = int(data.get("maximum", 1000))
            route.frequency = int(data.get("frequency", 60))
            route.interval = data.get("interval", "minutes")
            route.interactions = int(data.get("interactions", 100))
            route.rotations = int(data.get("rotations", 100))
        else:
            route.minimum = 0
            route.maximum = 0
            route.frequency = 0
            route.interval = "minutes"
            route.interactions = 0
            route.rotations = 0

        self.rt.loadBalancers.pin(keys=(name,), val=route)
        self.rt.updateAidCounts()

        hxLocation = json.dumps({
            "path": f"/load",
            "target": "body"
        })
        rep.set_header('HX-Location', hxLocation)
        rep.status = falcon.HTTP_200
        rep.text = b'Ok'

    def on_delete(self, _, rep, name):
        """ Load balancer delete endpoint

        Parameters:
            _ (Request): Falcon HTTP request object
            rep (Response): Falcon HTTP response object
            name (str): The name of the load balancer
        """
        name = falcon.uri.decode(name)
        route = self.rt.loadBalancers.get(keys=(name,))

        if route is None:
            templating.error(rep, 'load/edit_load_balancer.j2', dict(),
                             msg=f"Unable to delete load balancer {name}.")
            return

        if not self.rt.loadBalancers.rem(keys=(name,)):
            templating.error(rep, 'load/edit_load_balancer.j2', dict(),
                             msg=f"Unable to delete load balancer {name}.")
            return

        self.rt.updateAidCounts()

        rep.status = falcon.HTTP_200
        hxLocation = json.dumps({
            "path": f"/load",
            "target": "body"
        })
        rep.set_header('HX-Location', hxLocation)
        rep.text = b'Ok'

    def on_put(self, _, rep, name):
        """ Load balancer shutdown endpoint

        Parameters:
            _ (Request): Falcon HTTP request object
            rep (Response): Falcon HTTP response object
            name (str): The name of the load balancer
        """
        name = falcon.uri.decode(name)

        try:
            self.router.shutdownLoadBalancer(name)
        except ValueError as e:
            logger.info(e)
            templating.error(rep, 'load/shutdown_load_balancer.j2', dict(),
                             msg=f"Unable to shutdown load balancer {name}: {e}.")
            return

        rep.status = falcon.HTTP_200
        hxLocation = json.dumps({
            "path": f"/load",
            "target": "body"
        })
        rep.set_header('HX-Location', hxLocation)
        rep.text = b'Ok'


class LoadBalancerLaunchEnd:
    def __init__(self, router, hby, rt):
        self.router = router
        self.hby = hby
        self.rt = rt

    def _create_fresh_connections(self):
        """Create fresh database connections for each operation"""
        rgy = credentialing.Regery(hby=self.hby, name=self.rt.name, temp=False)
        routery = scheming.Routery(name=self.rt.name, alias="rack", rt=self.rt, hby=self.hby, rgy=rgy)
        return rgy, routery

    def on_post(self, req, rep, name):
        """ Load balancer launch endpoint

        Parameters:
            req (Request): Falcon HTTP request object
            rep (Response): Falcon HTTP response object
            name (str): The name of the load balancer
        """
        name = falcon.uri.decode(name)
        data = req.media
        if (loadBalancer := self.rt.loadBalancers.get(keys=(name,))) is None:
            templating.error(rep, 'launch_error_load_balancer.j2', data,
                             msg=f"{name} is not a valid load balancer.")
            return

        if loadBalancer.saids:
            templating.error(rep, 'launch_error_load_balancer.j2', data,
                             msg=f"{name} is already running.")
            return

        try:
            # Create fresh connections for this operation
            rgy, routery = self._create_fresh_connections()
            self.generateLoadBalancerRoutes(name, loadBalancer, routery)
        except ValueError as e:
            templating.error(rep, 'load/edit_load_balancer.j2', dict(),
                             msg=f"{e}")
            return

        hxLocation = json.dumps({
            "path": f"/load",
            "target": "body"
        })
        rep.set_header('HX-Location', hxLocation)
        rep.status = falcon.HTTP_200
        rep.text = b'Ok'

    def generateLoadBalancerRoutes(self, name, loadBalancer, routery):
        """ Generate routes for a Load Balancer

        Parameters:
            name (str): Name of the route group
            loadBalancer (LoadBalancer): The database definition of the load balancer to generate
            routery (Routery): Fresh routery instance for route creation

        """
        config = self._build_route_config(loadBalancer)
        loadBalancer.saids = list()

        routeType = "load_balancer"
        route = routery.makeRoute(name=name, route_type=routeType, config=config)

        self.router.addRoute(routery.routes[route.said])
        self.router.reload()
        loadBalancer.saids.append(route.said)
        self.rt.loadBalancers.pin(keys=(name,), val=loadBalancer)
        logger.info(f"Load balancer {name} launched: {loadBalancer}")

    def _build_route_config(self, loadBalancer):
        """Build load balancer route configuration from route data"""
        aid = loadBalancer.aid
        host = loadBalancer.host or "127.0.0.1"
        port = loadBalancer.port or 8080
        hosts = loadBalancer.hosts or []

        if not hosts:
            raise ValueError("At least one host is required")

        hosts_config = []
        for host_dict in hosts:
            host_config = {
                "aid": host_dict["aid"],
                "host": host_dict["host"],
                "port": host_dict["port"]
            }

            if host_dict.get('minimum'):
                host_config["anchor"] = {
                    "minimum": host_dict.get('minimum'),
                    "maximum": host_dict.get('maximum'),
                    "frequency": host_dict.get('frequency'),
                    "interval": host_dict.get('interval'),
                    "interactions": host_dict.get('interactions'),
                    "rotations": host_dict.get('rotations')
                }

            hosts_config.append(host_config)

        config = {
            "aid": aid,
            "tcpsrv": {
                "host": host,
                "port": port
            },
            "hosts": hosts_config
        }

        if loadBalancer.anchoring:
            config["anchor"] = {
                "minimum": loadBalancer.minimum,
                "maximum": loadBalancer.maximum,
                "frequency": loadBalancer.frequency,
                "interval": loadBalancer.interval,
                "interactions": loadBalancer.interactions,
                "rotations": loadBalancer.rotations
            }

        return config


class LoadBalancerFormCreateEnd:
    def __init__(self, hby, rt):
        self.hby = hby
        self.rt = rt

    def on_get(self, _, rep):
        """ Create Load Balancer form endpoint

        Parameters:
            _ (Request): Falcon HTTP request object
            rep (Response): Falcon HTTP response object
        """

        gateways = []
        for (aid,), destination in self.rt.dsts.getItemIter():
            d = dict(aid=aid, alias=destination.alias)
            gateways.append(d)

        identifiers = []
        for (aid,), identifier in self.rt.gators.getItemIter():
            d = dict(aid=aid, alias=identifier.alias)
            identifiers.append(d)

        ip_addresses = list()
        ip_addresses.append("0.0.0.0")
        hostname = socket.gethostname()

        for addr_info in socket.getaddrinfo(hostname, None):
            ip = addr_info[4][0]
            if ip not in ip_addresses:
                ip_addresses.append(ip)

        data = dict(
            gateways=gateways,
            identifiers=identifiers,
            ip_addresses=ip_addresses
        )

        template = J2_ENV.get_template('load/create_load_balancer.j2')

        rep.status = falcon.HTTP_200
        rep.content_type = "text/html"
        rep.text = template.render(page_title=f'RACK Create Load Balancer - {self.hby.name}', **data)


class LoadBalancerFormDeleteEnd:
    def __init__(self, hby, rt):
        self.hby = hby
        self.rt = rt

    def on_get(self, _, rep, name):
        """ Load Balancer delete form endpoint

        Parameters:
            _ (Request): Falcon HTTP request object
            rep (Response): Falcon HTTP response object
            name (str): name of load balancer

        """
        name = falcon.uri.decode(name)
        if (route := self.rt.loadBalancers.get(keys=(name,))) is None:
            templating.error(rep, "load/delete_load_balancer.j2", dict(), f"{name} is not a valid load balancer")
            return

        data = dict(
            name=name,
            route=route
        )

        template = J2_ENV.get_template('load/delete_load_balancer.j2')

        rep.status = falcon.HTTP_200
        rep.content_type = "text/html"
        rep.text = template.render(page_title=f'RACK Delete Load Balancer - {self.hby.name}', **data)


class LoadBalancerFormShutdownEnd:
    def __init__(self, hby, rt):
        self.hby = hby
        self.rt = rt

    def on_get(self, _, rep, name):
        """ Load Balancer shutdown form endpoint

        Parameters:
            _ (Request): Falcon HTTP request object
            rep (Response): Falcon HTTP response object
            name (str): name of load balancer

        """
        name = falcon.uri.decode(name)
        if (route := self.rt.loadBalancers.get(keys=(name,))) is None:
            templating.error(rep, "load/shutdown_load_balancer.j2", dict(), f"{name} is not a valid load balancer")
            return

        data = dict(
            name=name,
            route=route
        )

        template = J2_ENV.get_template('load/shutdown_load_balancer.j2')

        rep.status = falcon.HTTP_200
        rep.content_type = "text/html"
        rep.text = template.render(page_title=f'RACK Shutdown Load Balancer - {self.hby.name}', **data)


class LoadBalancerExportResourceEnd:
    def __init__(self, hby, rt):
        self.hby = hby
        self.rt = rt

    def on_get(self, _, rep, name):
        """ Export Load Balancer configuration

        Args:
            _ (Request): Falcon HTTP request object
            rep (Response): Falcon HTTP response object
            name (str): The name of the load balancer

        Returns:

        """
        name = falcon.uri.decode(name)
        if (route := self.rt.loadBalancers.get(keys=(name,))) is None:
            templating.error(rep, "load/view_load_balancer.j2", dict(), f"{name} is not a valid load balancer")
            return

        hab = self.hby.habs[route.aid]

        ims = hab.replyToOobi(aid=hab.pre, role=kering.Roles.gateway)

        for _, delegate in self.rt.dlgs.getItemIter(keys=(hab.pre,)):
            for msg in hab.db.clonePreIter(pre=delegate, fn=0):
                ims.extend(msg)

        rep.status = falcon.HTTP_200
        rep.content_type = "application/cesr"
        rep.set_header("Content-Disposition", f"attachment; filename=\"{self.hby.name}-{name}-load-balancer.cesr\"")
        rep.data = ims