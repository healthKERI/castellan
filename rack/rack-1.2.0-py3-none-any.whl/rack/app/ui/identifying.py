# -*- encoding: utf-8 -*-
"""
KERI
rack.app.ui.identifying package

"""
import json
import math

import falcon
from keri import core
from keri.app.connecting import Organizer
from keri.core import Salter, serdering, coring
from keri.core.coring import randomNonce
from keri.help import ogler
from kerkle.core import treeing

from . import templating
from .templating import J2_ENV
from .. import delegating
from ...core import basing

logger = ogler.getLogger()


def loadEnds(app, router):
    keyEventLogResourceEnd = KeyEventLogResourceEnd(hby=router.hby, rt=router.rt)
    app.add_route("/identifiers/{aid}/key_event_log", keyEventLogResourceEnd)

    anchorCollectionEnd = AnchorCollectionEnd(hby=router.hby, rt=router.rt)
    app.add_route("/delegates/{aid}/anchors", anchorCollectionEnd)

    identifierResourceEnd = IdentifierResourceEnd(hby=router.hby, rt=router.rt)
    app.add_route("/identifiers/{aid}", identifierResourceEnd)

    identifiersEnd = IdentifiersCollectionEnd(hby=router.hby, rt=router.rt)
    app.add_route("/identifiers", identifiersEnd)

    identifierFormCreateEnd = IdentifiersFormCreateEnd()
    app.add_route("/identifiers/forms/create", identifierFormCreateEnd)

    identifierFormWitnessAdd = IdentifiersFormWitnessAdd(hby=router.hby, rt=router.rt)
    app.add_route("/identifiers/forms/{aid}/witnesses", identifierFormWitnessAdd)

    delegatesCreateFormEnd = DelegatesFormCreateEnd(hby=router.hby, rt=router.rt)
    app.add_route("/delegates/forms/create", delegatesCreateFormEnd)

    activeCollectionEnd = ActiveSignerCollectionEnd(hby=router.hby, rt=router.rt)
    app.add_route("/delegates/active", activeCollectionEnd)

    retiredCollectionEnd = RetiredSignerCollectionEnd(hby=router.hby, rt=router.rt)
    app.add_route("/delegates/retired", retiredCollectionEnd)

    delegateResourceEnd = DelegateResourceEnd(hby=router.hby, rt=router.rt)
    app.add_route("/delegates/{aid}", delegateResourceEnd)

    saltResourceEnd = SaltResourceEnd()
    app.add_route("/salt", saltResourceEnd)


class IdentifierResourceEnd:
    def __init__(self, hby, rt):
        self.hby = hby
        self.rt = rt
        pass

    def on_get(self, _, rep, aid):
        """ Get a display of an identifier

        Args:
            _ (Request): Falcon HTTP request object
            rep (Response): Falcon HTTP response object
            aid (str): The aid of the Identifier requested

        Returns:

        """
        if aid not in self.hby.kevers:
            templating.error(rep, "identifiers/view_identifier.j2", dict(), f"{aid} is not a valid identifier")
            return

        data = dict()
        if aid in self.hby.habs:
            hab = self.hby.habs[aid]
            kever = hab.kever
            data['alias'] = hab.name
        else:
            kever = self.hby.kevers[aid]
            org = Organizer(hby=self.hby)
            c = org.get(aid)
            data['alias'] = c['alias']

        data['kever'] = kever

        if kever.delpre:
            delegator = self.rt.gators.get(keys=(kever.delpre,))
            data['delegator'] = delegator.alias

        template = J2_ENV.get_template("identifiers/view_identifier.j2")

        rep.status = falcon.HTTP_200
        rep.content_type = "text/html"
        rep.text = template.render(page_title=f'healthKERI Create Identifier - {self.hby.name}', **data)

    def on_delete(self, req, rep, aid):
        """ Identifier delete endpoint

        Parameters:
            req (Request): Falcon HTTP request object
            rep (Response): Falcon HTTP response object
            aid (str): The aid of the Identifier requested
        """
        account_id = req.context.account['_key']

        project = getattr(req.context, 'project', None)

        if not project:
            raise falcon.HTTPBadRequest(
                title='Missing Project',
                description='Project information is required to delete an identifier.'
            )

        rep.status = falcon.HTTP_200
        hxLocation = json.dumps({
            "path": f"/identifiers?project_id={project['_key']}",
            "target": "#project-identifier-list"
        })
        rep.set_header('HX-Location', hxLocation)


class KeyEventLogResourceEnd:
    def __init__(self, hby, rt):
        self.hby = hby
        self.rt = rt
        pass

    def on_get(self, _, rep, aid):
        """ Get a display of an identifier

        Args:
            _ (Request): Falcon HTTP request object
            rep (Response): Falcon HTTP response object
            aid (str): The aid of the Identifier requested

        Returns:

        """
        if aid not in self.hby.kevers:
            templating.error(rep, "identifiers/key_event_log.j2", dict(), f"{aid} is not a valid identifier")
            return

        cloner = self.hby.db.clonePreIter(pre=aid, fn=0)  # create iterator at 0
        events = list()
        for msg in cloner:
            srdr = serdering.SerderKERI(raw=msg)
            events.append(srdr.pretty(size=10000))

        template = J2_ENV.get_template("identifiers/key_event_log.j2")

        rep.status = falcon.HTTP_200
        rep.content_type = "text/html"
        rep.text = template.render(events=events)


class AnchorCollectionEnd:
    def __init__(self, hby, rt):
        self.hby = hby
        self.rt = rt
        pass

    def on_get(self, req, rep, aid):
        """ Get a display of an identifier

        Args:
            req (Request): Falcon HTTP request object
            rep (Response): Falcon HTTP response object
            aid (str): The aid of the Identifier requested

        Returns:

        """
        if aid not in self.hby.habs:
            templating.error(rep, "identifiers/key_event_log.j2", dict(), f"{aid} is not a valid identifier")
            return

        hab = self.hby.habs[aid]
        page = int(req.get_param("page", default=0))
        page_count = req.get_param("page_count", default=templating.PAGE_COUNT)

        start = page * page_count
        start = start + 1 if start > 0 else start

        count = 0
        anchors = []
        for (pre, snh, said), (saider, root) in self.rt.ancs.getItemIter(keys=(hab.pre,)):
            count += 1
            if count < start:
                continue

            msgcount = self.rt.encs.cnt(keys=(said,))
            sner = core.Number(numh=snh)

            tree = treeing.SparseMerkleTree()

            for s in self.rt.encs.getIter(keys=(said,)):
                tree.update(coring.Saider(qb64=s))

            croot = core.Matter(raw=tree.root_as_bytes(), code=core.MtrDex.Blake3_256)

            if croot.qb64 == root.qb64:
                verified = True
            else:
                verified = False

            if len(anchors) == page_count:
                continue

            a = dict(
                count=msgcount,
                seq_no=sner.sn,
                signing=said,
                anchoring=saider.qb64,
                root=root.qb64,
                verified=verified
            )

            anchors.append(a)

        data = dict(
            status="active",
            signer=hab.name,
            aid=hab.pre,
            delpre=hab.kever.delpre,
            page=page,
            num_pages=math.ceil(count / page_count),
            count=count,
            anchors=anchors
        )

        template = J2_ENV.get_template("identifiers/anchors.j2")

        rep.status = falcon.HTTP_200
        rep.content_type = "text/html"
        rep.text = template.render(page_title=f'healthKERI Anchors - {self.hby.name}', tab="identifiers", **data)


class IdentifiersFormWitnessAdd:
    def __init__(self, hby, rt):
        self.hby = hby
        self.rt = rt

    def on_get(self, req, rep, aid):
        """ Create Identifier form endpoint

        Parameters:
            req (Request): Falcon HTTP request object
            rep (Response): Falcon HTTP response object
            aid (str): Identifier to add witnesses to
        """
        data = dict(
            aid=aid
        )

        template = J2_ENV.get_template('identifiers/add_witnesses.j2')

        rep.status = falcon.HTTP_200
        rep.content_type = "text/html"
        rep.text = template.render(page_title=f'healthKERI Add Witnesses - {self.hby.name}', **data)


class IdentifiersFormCreateEnd:
    def __init__(self):
        pass

    def on_get(self, _, rep):
        """ Create Identifier form endpoint

        Parameters:
            _ (Request): Falcon HTTP request object
            rep (Response): Falcon HTTP response object
        """
        salt = randomNonce()[2:23]
        data = {
            'salt': salt
        }

        template = J2_ENV.get_template('identifiers/create_identifier.j2')

        rep.status = falcon.HTTP_200
        rep.content_type = "text/html"
        rep.text = template.render(**data)


class DelegatesFormCreateEnd:
    def __init__(self, hby, rt):
        self.hby = hby
        self.rt = rt

    def on_get(self, req, rep):
        """ Create Identifier form endpoint

        Parameters:
            req (Request): Falcon HTTP request object
            rep (Response): Falcon HTTP response object
        """
        salt = randomNonce()[2:23]
        data = {
            'salt': salt
        }

        if req.get_param("delpre", None) is not None:
            data['delpre'] = req.get_param("delpre")

        delegators = []
        for (aid,), delegator in self.rt.gators.getItemIter():
            d = dict(aid=aid, alias=delegator.alias)
            delegators.append(d)

        data['delegators'] = delegators

        template = J2_ENV.get_template('identifiers/create_delegates.j2')

        rep.status = falcon.HTTP_200
        rep.content_type = "text/html"
        rep.text = template.render(page_title=f'healthKERI Create Delegates - {self.hby.name}', **data)


class IdentifiersCollectionEnd:

    def __init__(self, hby, rt):
        """

        Parameters:
            hby(Habery): identifier database environment
        """
        self.hby = hby
        self.org = Organizer(hby=hby)
        self.rt = rt

    def on_get(self, req, rep):
        """ Account collection list endpoint

        Parameters:
            req (Request): Falcon HTTP request object
            rep (Response): Falcon HTTP response object
        """
        page = int(req.get_param("page", default=0))
        page_count = req.get_param("page_count", default=templating.PAGE_COUNT)

        start = page * page_count
        start = start + 1 if start > 0 else start

        count = 0
        delegators = []
        for (aid,), delegator in self.rt.gators.getItemIter():
            count += 1
            if count < start:
                continue

            active = self.rt.dlgs.cnt(keys=(aid,))
            retired = self.rt.rtrd.cnt(keys=(aid,))
            inbCnt = self.rt.inbsAidIdx.cnt(keys=(aid,))
            otbCnt = self.rt.otbsAidIdx.cnt(keys=(aid,))
            data = dict(
                aid=aid,
                alias=delegator.alias,
                resolved=delegator.local or delegator.resolved,
                active=active,
                retired=retired,
                inbCnt=inbCnt,
                otbCnt=otbCnt
            )

            if len(delegators) == page_count:
                continue

            delegators.append(data)

        data = dict(
            page=page,
            num_pages=math.ceil(count / page_count),
            count=count,
            identifiers=delegators
        )

        template = J2_ENV.get_template('identifiers/identifiers.j2')

        rep.status = falcon.HTTP_200
        rep.content_type = "text/html"
        rep.text = template.render(page_title=f'RACK Administration - {self.hby.name}', tab="identifiers", **data)

    def on_post(self, req, rep):
        """ Create Delegator endpoint, either remote or local

        Parameters:
            req (Request): Falcon HTTP request object
            rep (Response): Falcon HTTP response object
        """
        data = req.media
        alias = data.get("alias", "")
        if not alias:
            templating.error(rep, 'identifiers/create_identifier.j2', data,
                             msg="Alias is required")

            return

        if self.hby.habByName(alias) is not None:
            templating.error(rep, 'identifiers/create_identifier.j2', data,
                             msg=f"{alias} is already in use, please pick another alias")
            return

        kwargs = dict(algo=data['keyType'])
        if data.get("keyType", "") == 'salty':
            if data.get("salt", "") is None or len(data.get("salt", "")) != 21:
                logger.info('Salt is required and must be 21 characters long')
                return

            kwargs['salt'] = Salter(raw=data.get("salt", "").encode('utf-8')).qb64
            kwargs['icount'] = int(data.get("salty_signing_key_count", "1"))
            kwargs['isith'] = int(data.get("salty_signing_threshold", "1"))
            kwargs['ncount'] = int(data.get("salty_rotation_key_count", "1"))
            kwargs['nsith'] = int(data.get("salty_rotation_threshold", "1"))

        elif data.get("keyType", "") == 'randy':
            kwargs['salt'] = None
            kwargs['icount'] = int(data.get("randy_signing_key_count", "1"))
            kwargs['isith'] = int(data.get("randy_signing_threshold", "1"))
            kwargs['ncount'] = int(data.get("randy_rotation_key_count", "1"))
            kwargs['nsith'] = int(data.get("randy_rotation_threshold", "1"))

        kwargs['estOnly'] = data.get("eo", False)

        hab = self.hby.makeHab(name=alias, **kwargs)
        self.rt.gators.pin(keys=(hab.pre,), val=basing.Delegator(alias=alias, local=True))

        # Create an initial 10 signing delegates
        deli = delegating.Delegatery(hby=self.hby, rt=self.rt, hab=hab)
        delegates = deli.make(count=10)
        logger.info(f"Successfully created {len(delegates)} signing delegates")

        hxLocation = json.dumps({
            "path": f"/identifiers",
            "target": "body"
        })
        rep.set_header('HX-Location', hxLocation)
        rep.status = falcon.HTTP_200
        rep.text = b'Ok'


class ActiveSignerCollectionEnd:

    def __init__(self, hby, rt):
        self.hby = hby
        self.rt = rt
        pass

    def on_get(self, req, rep):
        """ Account collection list endpoint

        Parameters:
            req (Request): Falcon HTTP request object
            rep (Response): Falcon HTTP response object
        """
        page = int(req.get_param("page", default=0))
        page_count = req.get_param("page_count", default=templating.PAGE_COUNT)

        start = page * page_count
        start = start + 1 if start > 0 else start

        delpre = req.get_param("delpre", default="")
        keys = (delpre,) if delpre else ()

        count = 0
        delegates = []
        for (dpre,), aid in self.rt.dlgs.getItemIter(keys=keys):
            count += 1
            if count < start:
                continue

            hab = self.hby.habs.get(aid, None)
            delhab = self.hby.habs.get(dpre, None)
            cnt = 0
            for _ in self.rt.ancs.getItemIter(keys=(hab.pre,)):
                cnt += 1

            data = dict(alias=hab.name, kever=hab.kever, delpre=dpre, delegator=delhab.name, anchor_count=cnt)

            if len(delegates) == page_count:
                continue

            delegates.append(data)

        delegators = []
        for (aid,), delegator in self.rt.gators.getItemIter():
            d = dict(aid=aid, alias=delegator.alias)
            delegators.append(d)

        data = dict(
            page=page,
            num_pages=math.ceil(count / page_count),
            count=count,
            delpre=delpre,
            delegates=delegates,
            delegators=delegators
        )

        template = J2_ENV.get_template('identifiers/active_signers.j2')

        rep.status = falcon.HTTP_200
        rep.content_type = "text/html"
        rep.text = template.render(page_title=f'RACK Administration - {self.hby.name}', tab="identifiers", **data)

    def on_post(self, req, rep):
        """ Create Delegates endpoint iterating over count

        Parameters:
            req (Request): Falcon HTTP request object
            rep (Response): Falcon HTTP response object
        """
        data = req.media
        aliasPrefix = data.get("alias", "")
        if not aliasPrefix:
            templating.error(rep, 'identifiers/create_delegates.j2', data,
                             msg="Alias prefix is required")
            return

        delpre = data.get("delpre", "")
        if not delpre:
            templating.error(rep, 'identifiers/create_delegates.j2', data,
                             msg="You must select a delegator")
            return

        delegator = self.rt.gators.get(keys=(delpre,))
        if not delegator:
            templating.error(rep, 'identifiers/create_delegates.j2', data,
                             msg="You must select a valid delegator")
            return

        start = 0
        for hab in self.hby.habs.values():
            if hab.name.startswith(aliasPrefix):
                start += 1

        hxLocation = json.dumps({
            "path": f"/delegates",
            "target": "body"
        })
        rep.set_header('HX-Location', hxLocation)
        rep.status = falcon.HTTP_200
        rep.text = b'Ok'


class RetiredSignerCollectionEnd:

    def __init__(self, hby, rt):
        self.hby = hby
        self.rt = rt
        pass

    def on_get(self, req, rep):
        """ Account collection list endpoint

        Parameters:
            req (Request): Falcon HTTP request object
            rep (Response): Falcon HTTP response object
        """
        page = int(req.get_param("page", default=0))
        page_count = req.get_param("page_count", default=templating.PAGE_COUNT)

        start = page * page_count
        start = start + 1 if start > 0 else start

        delpre = req.get_param("delpre", default="")
        keys = (delpre,) if delpre else ()

        count = 0
        delegates = []
        for (dpre,), aid in self.rt.rtrd.getItemIter(keys=keys):
            count += 1
            if count < start:
                continue

            hab = self.hby.habs.get(aid, None)
            delhab = self.hby.habs.get(dpre, None)
            cnt = 0
            for _ in self.rt.ancs.getItemIter(keys=(hab.pre,)):
                cnt += 1

            data = dict(alias=hab.name, kever=hab.kever, delpre=dpre, delegator=delhab.name, message_count=cnt)

            if len(delegates) == page_count:
                continue

            delegates.append(data)

        delegators = []
        for (aid,), delegator in self.rt.gators.getItemIter():
            d = dict(aid=aid, alias=delegator.alias)
            delegators.append(d)

        data = dict(
            page=page,
            num_pages=math.ceil(count / page_count),
            count=count,
            delpre=delpre,
            delegates=delegates,
            delegators=delegators
        )

        logger.info(data)

        template = J2_ENV.get_template('identifiers/retired_signers.j2')

        rep.status = falcon.HTTP_200
        rep.content_type = "text/html"
        rep.text = template.render(page_title=f'RACK Administration - {self.hby.name}', tab="identifiers", **data)


class DelegateResourceEnd:
    def __init__(self, hby, rt):
        self.hby = hby
        self.rt = rt
        pass

    def on_get(self, _, rep, aid):
        """ Get a display of an identifier

        Args:
            _ (Request): Falcon HTTP request object
            rep (Response): Falcon HTTP response object
            aid (str): The aid of the Identifier requested

        Returns:

        """
        if aid not in self.hby.kevers:
            templating.error(rep, "identifiers/view_delegate.j2", dict(), f"{aid} is not a valid identifier")
            return

        data = dict()
        if aid in self.hby.habs:
            hab = self.hby.habs[aid]
            kever = hab.kever
            data['alias'] = hab.name
        else:
            kever = self.hby.kevers[aid]
            org = Organizer(hby=self.hby)
            c = org.get(aid)
            data['alias'] = c['alias']

        data['kever'] = kever

        if kever.delpre:
            delegator = self.rt.gators.get(keys=(kever.delpre,))
            data['delegator'] = delegator.alias

        template = J2_ENV.get_template("identifiers/view_delegate.j2")

        rep.status = falcon.HTTP_200
        rep.content_type = "text/html"
        rep.text = template.render(page_title=f'healthKERI View Signer - {self.hby.name}', **data)


class SaltResourceEnd:

    @staticmethod
    def on_get(req, rep):
        """ Get a new Salt input

        Parameters:
            req (Request): Falcon HTTP request object
            rep (Response): Falcon HTTP response object
        """
        typ = req.get_param("display_type", "hidden")
        salt = randomNonce()[2:23]

        rep.status = falcon.HTTP_200
        rep.content_type = "text/html"
        rep.text = (f'<input type="{typ}" id="salt" placeholder="" name="password" value="{salt}" class="mono'
                    f' text-base mt-1 p-2 w-full border rounded-md pr-10">')
