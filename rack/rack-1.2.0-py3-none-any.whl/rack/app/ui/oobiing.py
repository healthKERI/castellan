# -*- encoding: utf-8 -*-
"""
rack.app.oobiing module

"""
import falcon


def loadEnds(app, router):
    oobiEnd = OobiEnd(hby=router.hby, rt=router.rt)
    app.add_route("/oobi", oobiEnd)


class OobiEnd:

    def __init__(self, hby, rt):
        self.hby = hby
        self.rt = rt

    def on_get(self, req, rep, cid, role=None, eid=None):
        """ Oobi Endpoint

        Parameters:
            req (Request): Falcon HTTP request object
            rep (Response): Falcon HTTP response object
            cid (str): qb64 prefix of controller
            role (str): OOBI endpoint role
            eid (str): qb64 prefix of endpoint

        """

        if (route := self.rt.inbs.get(keys=(cid,))) is None:
            raise falcon.HTTPNotFound(f"{cid} is not a known idnetifier.")


