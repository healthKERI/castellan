# -*- encoding: utf-8 -*-
"""
rack.app.routing module

"""
import json
import math

import falcon
from keri import kering
from keri.help import helping, ogler
from keri.vdr import credentialing

from rack.app.ui import templating
from rack.app.ui.templating import J2_ENV
from rack.core import scheming
from rack.core.basing import OutboundRoute

logger = ogler.getLogger()


def loadEnds(app, router):
    outboundCollectionEndpoint = OutboundRouteCollectionEnd(hby=router.hby, rt=router.rt)
    app.add_route("/routes/outbound", outboundCollectionEndpoint)

    outboundFormCreateEnd = OutboundRouteFormCreateEnd(hby=router.hby, rt=router.rt)
    app.add_route("/routes/outbound/forms/create", outboundFormCreateEnd)

    outboundFormDeleteEnd = OutboundRouteFormDeleteEnd(hby=router.hby, rt=router.rt)
    app.add_route("/routes/outbound/{name}/forms/delete", outboundFormDeleteEnd)

    outboundFormShutdownEnd = OutboundRouteFormShutdownEnd(hby=router.hby, rt=router.rt)
    app.add_route("/routes/outbound/{name}/forms/shutdown", outboundFormShutdownEnd)

    outboundResourceEnd = OutboundRouteResourceEnd(router=router)
    app.add_route("/routes/outbound/{name}", outboundResourceEnd)

    outboundLaunchEnd = OutboundRouteLaunchEnd(router=router, hby=router.hby, rt=router.rt)
    app.add_route("/routes/outbound/{name}/launch", outboundLaunchEnd)

    outboundExpResourceEnd = OutboundRouteExportResourceEnd(hby=router.hby, rt=router.rt)
    app.add_route("/routes/outbound/{name}/export", outboundExpResourceEnd)


class OutboundRouteCollectionEnd:
    """ Outbound Route Collection Endpoint Class """

    def __init__(self, hby, rt):
        self.hby = hby
        self.rt = rt

    def on_get(self, req, rep):
        """ Outbound route collection list endpoint

        Parameters:
            req (Request): Falcon HTTP request object
            rep (Response): Falcon HTTP response object
        """

        page = int(req.get_param("page", default=0))
        page_count = req.get_param("page_count", default=templating.PAGE_COUNT)

        start = page * page_count
        start = start + 1 if start > 0 else start

        count = 0
        routes = []
        for (name,), route in self.rt.otbs.getItemIter():
            count += 1
            if count < start:
                continue

            hab = self.hby.habs[route.localAID]
            gateway = None
            if route.gateway:
                dest = self.rt.dsts.get(keys=(route.gateway,))
                if dest:
                    gateway = dest.alias

            match route.route_type:
                case "cloud":
                    route_type = "Cloud Router"
                case "peer":
                    route_type = "Peer-to-Peer"
                case _:
                    route_type = "Unknown"

            r = dict(
                name=name,
                identifier=hab.name,
                gateway=gateway,
                listen=f"{route.scheme}://0.0.0.0:{route.port}",
                saids=route.saids,
                route_type=route_type
            )

            if route.lastPing is not None:
                r['ping'] = helping.fromIso8601(route.lastPing).astimezone().strftime("%Y-%m-%d %H:%M:%S")

            if len(routes) == page_count:
                continue

            routes.append(r)

        data = dict(
            page=page,
            num_pages=math.ceil(count / page_count),
            count=count,
            routes=routes
        )

        template = J2_ENV.get_template('routes/http/outbound/outbound_routes.j2')

        rep.status = falcon.HTTP_200
        rep.content_type = "text/html"
        rep.text = template.render(page_title=f'RACK Administration - {self.hby.name}', tab="outbound", **data)

    def on_post(self, req, rep):
        """ Create Outbound Route, either remote or local

        Parameters:
            req (Request): Falcon HTTP request object
            rep (Response): Falcon HTTP response object
        """
        data = req.media
        name = data.get("name", "")
        if not name:
            templating.error(rep, 'routes/http/outbound/create_outbound.j2', data,
                             msg="Name is required")

            return

        if self.rt.otbs.get(keys=(name,)) is not None:
            templating.error(rep, 'routes/http/outbound/create_outbound.j2', data,
                             msg="Name is already in use as an outbound route.")

            return

        aid = data.get("aid", None)
        if not aid:
            templating.error(rep, 'routes/http/outbound/create_outbound.j2', data,
                             msg="Local AID is required")

            return

        if aid not in self.hby.habs:
            templating.error(rep, 'identifiers/create_outbound.j2', data,
                             msg=f"{aid} is not a valid local source")
            return

        hab = self.hby.habs[aid]

        route_type = data.get("route_type", "peer")

        match route_type:
            case "peer":
                gateway = data.get("gateway", None)
                router = None
            case "cloud":
                router = data.get("router", None)
                gateway = None
            case _:
                templating.error(rep, 'routes/http/outbound/create_outbound.j2', data,
                                 msg=f"{route_type} is not a valid route type")
                return

        scheme = data.get("scheme", "http")
        port = int(data.get("port", 7777))

        dt = helping.nowIso8601()
        msgs = bytearray()
        msgs.extend(hab.makeEndRole(eid=hab.pre,
                                    role=kering.Roles.gateway,
                                    stamp=dt))
        msgs.extend(hab.makeLocScheme(url=f"{scheme}://127.0.0.1:{port}/",
                                      scheme=scheme,
                                      stamp=dt))
        hab.psr.parse(ims=msgs)

        outb = OutboundRoute(localAID=aid, route_type=route_type, gateway=gateway, router=router,
                             scheme=scheme, port=port)

        outb.anchoring = bool(data.get("anchoring", False))
        if outb.anchoring:
            outb.maximum = int(data.get("maximum", 1000))
            outb.frequency = int(data.get("frequency", 60))
            outb.interval = data.get("interval", "minutes")
            outb.interactions = int(data.get("interactions", 100))
            outb.rotations = int(data.get("rotations", 100))
        else:
            outb.maximum = 0
            outb.frequency = 0
            outb.interval = None
            outb.interactions = 0
            outb.rotations = 0

        self.rt.otbs.pin(keys=(name,), val=outb)
        self.rt.updateAidCounts()
        self.rt.updateGtwCounts()

        hxLocation = json.dumps({
            "path": f"/routes/outbound",
            "target": "body"
        })
        rep.set_header('HX-Location', hxLocation)
        rep.status = falcon.HTTP_200
        rep.text = b'Ok'


class OutboundRouteResourceEnd:
    def __init__(self, router):
        self.router = router
        self.hby = router.hby
        self.rt = router.rt
        pass

    def on_get(self, req, rep, name):
        """ Get an edit for for an outbound route

        Args:
            req (Request): Falcon HTTP request object
            rep (Response): Falcon HTTP response object
            name (str): The name of the outbound route

        Returns:

        """
        name = falcon.uri.decode(name)
        if (route := self.rt.otbs.get(keys=(name,))) is None:
            templating.error(rep, "routes/http/outbound/edit_outbound.j2", dict(), f"{name} is not a valid outbound route")
            return

        gateways = []
        for (aid,), destination in self.rt.dsts.getItemIter():
            d = dict(aid=aid, alias=destination.alias)
            gateways.append(d)

        identifiers = []
        for (aid,), identifier in self.rt.gators.getItemIter():
            d = dict(aid=aid, alias=identifier.alias)
            identifiers.append(d)

        routers = []
        for (routerName,), router in self.rt.routers.getItemIter():  # <-- This is correct
            routers.append(dict(aid=router.aid, name=routerName))


        data = dict(
            name=name,
            route=route,
            gateways=gateways,
            routers=routers,
            identifiers=identifiers
        )

        template = J2_ENV.get_template("routes/http/outbound/edit_outbound.j2")

        rep.status = falcon.HTTP_200
        rep.content_type = "text/html"
        rep.text = template.render(page_title=f'healthKERI Edit Outbound Route - {self.hby.name}', **data)

    def on_post(self, req, rep, name):
        """ Inbound route update endpoint

        Parameters:
            req (Request): Falcon HTTP request object
            rep (Response): Falcon HTTP response object
            name (str): The aid of the Identifier requested
        """
        name = falcon.uri.decode(name)
        data = req.media
        if (route := self.rt.otbs.get(keys=(name,))) is None:
            templating.error(rep, 'routes/http/outbound/create_outbound.j2', data,
                             msg="Name is already in use as an inbound route.")

            return

        route.localAID = data.get("aid", None)
        if not route.localAID:
            templating.error(rep, 'routes/http/outbound/edit_outbound.j2', data,
                             msg="Local AID is required")

            return

        if route.localAID not in self.hby.habs:
            templating.error(rep, 'routes/http/outbound/edit_outbound.j2', data,
                             msg=f"{route.localAID} is not a valid local source")
            return

        route.scheme = data.get("scheme", "http")
        if route.scheme not in ("http", "https", "tcp"):
            templating.error(rep, 'routes/http/outbound/edit_outbound.j2', data,
                             msg=f"{route.scheme} is not a valid scheme")
            return

        route.route_type = data.get("route_type", "peer")
        route.gateway = data.get("gateway", None)
        route.router = data.get("router", None)
        route.port = int(data.get("port", 7777))

        route.anchoring = bool(data.get("anchoring", False))
        if route.anchoring:
            route.maximum = int(data.get("maximum", 1000))
            route.frequency = int(data.get("frequency", 60))
            route.interval = data.get("interval", "minutes")
            route.interactions = int(data.get("interactions", 100))
            route.rotations = int(data.get("rotations", 100))
        else:
            route.maximum = 0
            route.frequency = 0
            route.interval = None
            route.interactions = 0
            route.rotations = 0

        self.rt.otbs.pin(keys=(name,), val=route)
        self.rt.updateAidCounts()
        self.rt.updateGtwCounts()

        hxLocation = json.dumps({
            "path": f"/routes/outbound",
            "target": "body"
        })
        rep.set_header('HX-Location', hxLocation)
        rep.status = falcon.HTTP_200
        rep.text = b'Ok'

    def on_delete(self, _, rep, name):
        """ Inbound route delete endpoint

        Parameters:
            _ (Request): Falcon HTTP request object
            rep (Response): Falcon HTTP response object
            name (str): The aid of the Identifier requested
        """
        name = falcon.uri.decode(name)
        route = self.rt.otbs.get(keys=(name,))

        if route is None:
            templating.error(rep, 'routes/http/outbound/edit_outbound.j2', dict(),
                             msg=f"Unable to delete outbound route {name}.")
            return

        if not self.rt.otbs.rem(keys=(name,)):
            templating.error(rep, 'routes/http/outbound/edit_outbound.j2', dict(),
                             msg=f"Unable to delete outbound route {name}.")
            return

        self.rt.updateAidCounts()
        self.rt.updateGtwCounts()

        rep.status = falcon.HTTP_200
        hxLocation = json.dumps({
            "path": f"/routes/outbound",
            "target": "body"
        })
        rep.set_header('HX-Location', hxLocation)
        rep.text = b'Ok'

    def on_put(self, _, rep, name):
        """ Inbound route shutdown endpoint

        Parameters:
            _ (Request): Falcon HTTP request object
            rep (Response): Falcon HTTP response object
            name (str): The aid of the Identifier requested
        """
        name = falcon.uri.decode(name)

        try:
            self.router.shutdownOutboundRoute(name)
        except ValueError as e:
            logger.info(e)
            templating.error(rep, 'routes/http/outbound/shutdown_outbound.j2', dict(),
                             msg=f"Unable to shutdown outbound route {name}: {e}.")
            return

        rep.status = falcon.HTTP_200
        hxLocation = json.dumps({
            "path": f"/routes/outbound",
            "target": "body"
        })
        rep.set_header('HX-Location', hxLocation)
        rep.text = b'Ok'


class OutboundRouteExportResourceEnd:
    def __init__(self, hby, rt):
        self.hby = hby
        self.rt = rt
        pass

    def on_get(self, _, rep, name):
        """ Get a display of an identifier

        Args:
            _ (Request): Falcon HTTP request object
            rep (Response): Falcon HTTP response object
            name (str): The name of the inbound route

        Returns:

        """
        name = falcon.uri.decode(name)
        if (route := self.rt.otbs.get(keys=(name,))) is None:
            templating.error(rep, "routes/http/outbound/view_outbound_route.j2", dict(), f"{name} is not a valid outbound route")
            return

        hab = self.hby.habs[route.localAID]

        ims = hab.replyToOobi(aid=hab.pre, role=kering.Roles.gateway)
        for _, delegate in self.rt.dlgs.getItemIter(keys=(hab.pre,)):
            for msg in hab.db.clonePreIter(pre=delegate, fn=0):
                ims.extend(msg)

        rep.status = falcon.HTTP_200
        rep.content_type = "application/cesr"
        rep.set_header("Content-Disposition", f"attachment; filename=\"{self.hby.name}-{name}.cesr\"")
        rep.data = ims

class OutboundRouteLaunchEnd:
    def __init__(self, router, hby, rt):
        self.router = router
        self.hby = hby
        self.rt = rt

    def _create_fresh_connections(self):
        """Create fresh database connections for each operation"""
        rgy = credentialing.Regery(hby=self.hby, name=self.rt.name, temp=False)
        routery = scheming.Routery(name=self.rt.name, alias="rack", rt=self.rt, hby=self.hby, rgy=rgy)
        return rgy, routery

    def on_post(self, req, rep, name):
        """ Outbound route launch endpoint """
        name = falcon.uri.decode(name)
        data = req.media
        if (outbound := self.rt.otbs.get(keys=(name,))) is None:
            templating.error(rep, 'routes/launch_error_outbound.j2', data,
                             msg="Name is already in use as an outbound route.")

            return

        if outbound.saids:
            templating.error(rep, 'routes/launch_error_outbound.j2', data,
                             msg=f"{name} is already running.")

            return

        if outbound.route_type == "peer":
            gateway = self.hby.kevers[outbound.gateway]
            if gateway is None:
                templating.error(rep, 'routes/launch_error_outbound.j2', data,
                                 msg=f"{outbound.gateway} is not a valid gateway AID.")
                return

        essrParams = {"src": outbound.localAID, "dest": outbound.gateway}
        if outbound.anchoring:
            essrParams["maximum"] = outbound.maximum
            essrParams["frequency"] = outbound.frequency
            essrParams["interval"] = outbound.interval
            essrParams["interactions"] = outbound.interactions
            essrParams["rotations"] = outbound.rotations

        try:
            rgy, routery = self._create_fresh_connections()

            match outbound.route_type:
                case "peer":
                    self.generatePeerRoutes(name, outbound, routery)
                case "cloud":
                    self.generateCloudRoutes(name, outbound, routery)
        except ValueError as e:
            templating.error(rep, 'routes/http/outbound/edit_inbound.j2', dict(),
                             msg=f"{e}")
            return

        hxLocation = json.dumps({
            "path": f"/routes/outbound",
            "target": "body"
        })
        rep.set_header('HX-Location', hxLocation)
        rep.status = falcon.HTTP_200
        rep.text = b'Ok'

    def generatePeerRoutes(self, name, outbound, routery):
        end = self.hby.db.ends.get(keys=(outbound.gateway, kering.Roles.gateway, outbound.gateway))
        if not end:
            raise ValueError(f"{outbound.gateway} does not have the gateway role.")

        loc = self.hby.db.locs.get(keys=(outbound.gateway, outbound.scheme))
        if not loc:
            raise ValueError(f"{outbound.gateway} does not have a gateway endpoint.")

        config = self._build_route_config(outbound)
        outbound.saids = list()

        if outbound.scheme == "http":
            routeType = "http_outbound"
            route = routery.makeRoute(name=name, route_type=routeType, config=config)
        else:
            pass

        self.router.addRoute(routery.routes[route.said])
        self.router.reload()
        outbound.saids.append(route.said)
        self.rt.otbs.pin(keys=(name,), val=outbound)

    def _build_route_config(self, outboundRoute):
        """Build route configuration from form data"""
        aid = outboundRoute.localAID
        gateway = outboundRoute.gateway
        port = outboundRoute.port or 7777
        host = "0.0.0.0"
        protocol = outboundRoute.scheme

        if not gateway:
            raise ValueError("Gateway AID is required")

        config = {
            "aid": aid,
            "tcp": {
                "aid": gateway,
                "host": "127.0.0.1",
                "port": 7777
            }
        }

        if protocol == "http":
            config["httpsrv"] = {
                "host": host,
                "port": port
            }

        if outboundRoute.anchoring == False:
            config["anchor"] = {
                "minimum": outboundRoute.minimum if hasattr(outboundRoute, "minimum") else 0,
                "maximum": outboundRoute.maximum or 1000,
                "frequency": outboundRoute.frequency or 60,
                "interval": outboundRoute.interval or "minutes",
                "interactions": outboundRoute.interactions or 100,
                "rotations": outboundRoute.rotations or 100
            }

        return config

    def _build_cloud_route_config(self, outboundRoute):
        """Build cloud route configuration from form data"""
        aid = outboundRoute.localAID
        port = outboundRoute.port or 7777
        host = "0.0.0.0"
        protocol = outboundRoute.scheme

        router = self.rt.routers.get(keys=(outboundRoute.router,))
        if router is None:
            raise ValueError("Invalid router, no router found")

        config = {
            "aid": aid,
            "tcp": {
                "aid": router.aid,
                "host": router.host,
                "port": int(router.port)
            }
        }

        if protocol == "http":
            config["httpsrv"] = {
                "host": host,
                "port": port
            }

        if outboundRoute.anchoring:
            config["anchor"] = {
                "minimum": outboundRoute.minimum if hasattr(outboundRoute, "minimum") else 0,
                "maximum": outboundRoute.maximum or 1000,
                "frequency": outboundRoute.frequency or 60,
                "interval": outboundRoute.interval or "minutes",
                "interactions": outboundRoute.interactions or 100,
                "rotations": outboundRoute.rotations or 100
            }

        return config

    def generateCloudRoutes(self, name, outbound, routery):
        """ Generate routes for a cloud router based gateway connection

        Parameters:
            name (str): Name of the route group
            outbound (OutboundRoute): The database definition of the outbound route to generate
            routery (Routery): Fresh routery instance for route creation

        """
        config = self._build_cloud_route_config(outbound)
        outbound.saids = list()

        if outbound.scheme == "http":
            routeType = "http_outbound"
            route = routery.makeRoute(name=name, route_type=routeType, config=config)
        else:
            pass

        self.router.addRoute(routery.routes[route.said])
        self.router.reload()
        outbound.saids.append(route.said)
        self.rt.otbs.pin(keys=(name,), val=outbound)

    def on_delete(self, _, rep, name):
        """ Inbound route delete endpoint

        Parameters:
            _ (Request): Falcon HTTP request object
            rep (Response): Falcon HTTP response object
            name (str): The aid of the Identifier requested
        """
        name = falcon.uri.decode(name)

        if not self.rt.inbs.rem(keys=(name,)):
            templating.error(rep, 'routes/http/outbound/edit_inbound.j2', dict(),
                             msg=f"Unable to delete inbound route {name}.")
            return

        rep.status = falcon.HTTP_200
        hxLocation = json.dumps({
            "path": f"/routes/inbound",
            "target": "body"
        })
        rep.set_header('HX-Location', hxLocation)
        rep.text = b'Ok'


class OutboundRouteFormCreateEnd:
    def __init__(self, hby, rt):
        self.hby = hby
        self.rt = rt

    def on_get(self, _, rep):
        """ Create Identifier form endpoint

        Parameters:
            _ (Request): Falcon HTTP request object
            rep (Response): Falcon HTTP response object
        """

        gateways = []
        for (aid,), destination in self.rt.dsts.getItemIter():
            d = dict(aid=aid, alias=destination.alias)
            gateways.append(d)

        identifiers = []
        for (aid,), identifier in self.rt.gators.getItemIter():
            d = dict(aid=aid, alias=identifier.alias)
            identifiers.append(d)

        routers = []
        for (name,), router in self.rt.routers.getItemIter():
            routers.append(dict(aid=router.aid, name=name))

        data = dict(
            gateways=gateways,
            identifiers=identifiers,
            routers=routers
        )

        template = J2_ENV.get_template('routes/http/outbound/create_outbound.j2')

        rep.status = falcon.HTTP_200
        rep.content_type = "text/html"
        rep.text = template.render(page_title=f'healthKERI Create Outbound Route - {self.hby.name}', **data)


class OutboundRouteFormDeleteEnd:
    def __init__(self, hby, rt):
        self.hby = hby
        self.rt = rt

    def on_get(self, _, rep, name):
        """ Create Identifier form endpoint

        Parameters:
            _ (Request): Falcon HTTP request object
            rep (Response): Falcon HTTP response object
            name (str): name of outbound route

        """
        name = falcon.uri.decode(name)
        if (route := self.rt.otbs.get(keys=(name,))) is None:
            templating.error(rep, "routes/http/outbound/delete_outbound.j2", dict(), f"{name} is not a valid outbound route")
            return

        data = dict(
            name=name,
            route=route
        )

        template = J2_ENV.get_template('routes/http/outbound/delete_outbound.j2')

        rep.status = falcon.HTTP_200
        rep.content_type = "text/html"
        rep.text = template.render(page_title=f'healthKERI Delete Outbound Route - {self.hby.name}', **data)


class OutboundRouteFormShutdownEnd:
    def __init__(self, hby, rt):
        self.hby = hby
        self.rt = rt

    def on_get(self, _, rep, name):
        """ Create Identifier form endpoint

        Parameters:
            _ (Request): Falcon HTTP request object
            rep (Response): Falcon HTTP response object
            name (str): name of outbound route

        """
        name = falcon.uri.decode(name)
        if (route := self.rt.otbs.get(keys=(name,))) is None:
            templating.error(rep, "routes/http/outbound/shutdown_outbound.j2", dict(), f"{name} is not a valid outbound route")
            return

        data = dict(
            name=name,
            route=route
        )

        template = J2_ENV.get_template('routes/http/outbound/shutdown_outbound.j2')

        rep.status = falcon.HTTP_200
        rep.content_type = "text/html"
        rep.text = template.render(page_title=f'healthKERI Shutdown Outbound Route - {self.hby.name}', **data)
