# -*- encoding: utf-8 -*-
"""
rack.app.routing module

"""
import json
import math
import socket

import falcon
from keri import kering
from keri.help import helping, ogler
from keri.kering import Schemes
from keri.vdr import credentialing

from rack.app.ui import templating
from rack.app.ui.templating import J2_ENV
from rack.core import scheming
from rack.core.basing import InboundRoute

logger = ogler.getLogger()


def loadEnds(app, router):
    inboundCollectionEndpoint = InboundRouteCollectionEnd(hby=router.hby, rt=router.rt)
    app.add_route("/routes/inbound", inboundCollectionEndpoint)

    inboundFormCreateEnd = InboundRouteFormCreateEnd(hby=router.hby, rt=router.rt)
    app.add_route("/routes/inbound/forms/create", inboundFormCreateEnd)

    inboundFormDeleteEnd = InboundRouteFormDeleteEnd(hby=router.hby, rt=router.rt)
    app.add_route("/routes/inbound/{name}/forms/delete", inboundFormDeleteEnd)

    inboundFormShutdownEnd = InboundRouteFormShutdownEnd(hby=router.hby, rt=router.rt)
    app.add_route("/routes/inbound/{name}/forms/shutdown", inboundFormShutdownEnd)

    inboundResourceEnd = InboundRouteResourceEnd(router=router)
    app.add_route("/routes/inbound/{name}", inboundResourceEnd)

    inboundLaunchEnd = InboundRouteLaunchEnd(router=router, hby=router.hby, rt=router.rt)
    app.add_route("/routes/inbound/{name}/launch", inboundLaunchEnd)

    inboundExpResourceEnd = InboundRouteExportResourceEnd(hby=router.hby, rt=router.rt)
    app.add_route("/routes/inbound/{name}/export", inboundExpResourceEnd)


class InboundRouteCollectionEnd:
    """ Inbound Route Collection Endpoint Class """

    def __init__(self, hby, rt):
        self.hby = hby
        self.rt = rt

    def on_get(self, req, rep):
        """ Inbound route collection list endpoint

        Parameters:
            req (Request): Falcon HTTP request object
            rep (Response): Falcon HTTP response object
        """
        page = int(req.get_param("page", default=0))
        page_count = req.get_param("page_count", default=templating.PAGE_COUNT)

        start = page * page_count
        start = start + 1 if start > 0 else start

        count = 0
        routes = []
        for (name,), route in self.rt.inbs.getItemIter():
            count += 1
            if count < start:
                continue

            hab = self.hby.habs[route.localAID]
            gateway = None
            if route.gateway:
                dest = self.rt.dsts.get(keys=(route.gateway,))
                if dest:
                    gateway = dest.alias

            router = None
            if route.router:
                rtr = self.rt.routers.get(keys=(route.router,))  # route.router now contains the name
                if rtr:
                    router = route.router

            match route.route_type:
                case "cloud":
                    route_type = "Cloud Router"
                case "peer":
                    route_type = "Peer-to-Peer"
                case _:
                    route_type = "Unknown"

            r = dict(
                name=name,
                identifier=hab.name,
                local_port=route.localPort,
                route_type=route_type,
                gateway=gateway,
                router=router,
                forward=f"{route.scheme}://{route.host}:{route.port}",
                saids=route.saids
            )

            if route.lastPing is not None:
                r['ping'] = helping.fromIso8601(route.lastPing).astimezone().strftime("%Y-%m-%d %H:%M:%S")

            if len(routes) == page_count:
                continue

            routes.append(r)

        data = dict(
            page=page,
            num_pages=math.ceil(count / page_count),
            count=count,
            routes=routes
        )
        template = J2_ENV.get_template('routes/http/inbound/inbound_routes.j2')

        rep.status = falcon.HTTP_200
        rep.content_type = "text/html"
        rep.text = template.render(page_title=f'RACK Administration - {self.hby.name}', tab="inbound", **data)

    def on_post(self, req, rep):
        """ Create Inbound Route, either remote or local

        Parameters:
            req (Request): Falcon HTTP request object
            rep (Response): Falcon HTTP response object
        """
        data = req.media
        name = data.get("name", "")
        route_type = data.get("route_type", "peer")

        if not name:
            templating.error(rep, 'routes/http/inbound/create_inbound.j2', data,
                             msg="Name is required")

            return

        if self.rt.inbs.get(keys=(name,)) is not None:
            templating.error(rep, 'routes/http/inbound/create_inbound.j2', data,
                             msg="Name is already in use as an inbound route.")

            return

        aid = data.get("aid", None)
        if not aid:
            templating.error(rep, 'routes/http/inbound/create_inbound.j2', data,
                             msg="Local AID is required")
            return

        if aid not in self.hby.habs:
            templating.error(rep, 'routes/http/inbound/create_inbound.j2', data,
                             msg=f"{aid} is not a valid local source")
            return

        match route_type:
            case "peer":
                gateway = data.get("gateway", None)
                lhost = data.get("local_ip", "127.0.0.1")
                lport = data.get("local_port", None)
                router = None
                schema = ""
                if route_type == "peer" and not lport:
                    templating.error(rep, 'routes/http/inbound/create_inbound.j2', data,
                                     msg="Local Port is required for peer-to-peer inbound routes")
                    return

                hab = self.hby.habs[aid]
                dt = helping.nowIso8601()
                msgs = bytearray()
                msgs.extend(hab.makeEndRole(eid=hab.pre,
                                            role=kering.Roles.gateway,
                                            stamp=dt))
                msgs.extend(hab.makeLocScheme(url=f"{Schemes.http}://{lhost}:{lport}/",
                                              scheme=Schemes.http,
                                              stamp=dt))

                hab.psr.parse(ims=msgs)

            case "cloud":
                router = data.get("router", None)
                gateway = None
                lport = 0
                lhost = ""
                schema = ""
                if not router:
                    templating.error(rep, 'routes/http/inbound/create_inbound.j2', data,
                                     msg="Cloud Router is required for cloud routes")
                    return
            case _:
                lport = 0
                lhost = ""
                gateway = None
                router = None
                schema = ""

        scheme = data.get("scheme", "http")
        if scheme not in ("http", "https", "tcp"):
            templating.error(rep, 'routes/http/inbound/create_inbound.j2', data,
                             msg=f"{scheme} is not a valid scheme")
            return

        host = data.get("host", "127.0.0.1")
        port = int(data.get("port", 7777))

        inb = InboundRoute(
            localPort=int(lport),
            localHost=lhost,
            localAID=aid,
            route_type=route_type,
            gateway=gateway,
            router=router,
            schema=schema,
            scheme=scheme,
            host=host,
            port=port)

        inb.anchoring = bool(data.get("anchoring", False))
        if inb.anchoring:
            inb.maximum = int(data.get("maximum", 1000))
            inb.frequency = int(data.get("frequency", 60))
            inb.interval = data.get("interval", "minutes")
            inb.interactions = int(data.get("interactions", 100))
            inb.rotations = int(data.get("rotations", 100))
        else:
            inb.maximum = 0
            inb.frequency = 0
            inb.interval = None
            inb.interactions = 0
            inb.rotations = 0

        self.rt.inbs.pin(keys=(name,), val=inb)
        self.rt.updateAidCounts()
        self.rt.updateGtwCounts()

        hxLocation = json.dumps({
            "path": f"/routes/inbound",
            "target": "body"
        })
        rep.set_header('HX-Location', hxLocation)
        rep.status = falcon.HTTP_200
        rep.text = b'Ok'


class InboundRouteResourceEnd:
    def __init__(self, router):
        """

        Parameters:
            router (Router): Top level route coordinator

        """
        self.hby = router.hby
        self.rt = router.rt
        self.router = router

    def on_get(self, req, rep, name):
        """ Get a display of an identifier

        Args:
            req (Request): Falcon HTTP request object
            rep (Response): Falcon HTTP response object
            name (str): The name of the inbound route

        Returns:

        """
        name = falcon.uri.decode(name)
        if (route := self.rt.inbs.get(keys=(name,))) is None:
            templating.error(rep, "routes/http/inbound/edit_inbound.j2", dict(), f"{name} is not a valid inbound route")
            return

        gateways = []
        for (aid,), destination in self.rt.dsts.getItemIter():
            d = dict(aid=aid, alias=destination.alias)
            gateways.append(d)

        identifiers = []
        for (aid,), identifier in self.rt.gators.getItemIter():
            d = dict(aid=aid, alias=identifier.alias)
            identifiers.append(d)

        routers = []
        for (routerName,), router in self.rt.routers.getItemIter():
            routers.append(dict(aid=router.aid, name=routerName))

        ip_addresses = list()
        ip_addresses.append("0.0.0.0")
        hostname = socket.gethostname()

        for addr_info in socket.getaddrinfo(hostname, None):
            ip = addr_info[4][0]
            if ip not in ip_addresses:
                ip_addresses.append(ip)

        data = dict(
            name=name,
            route=route,
            gateways=gateways,
            routers=routers,
            identifiers=identifiers,
            ip_addresses=ip_addresses
        )

        template = J2_ENV.get_template("routes/http/inbound/edit_inbound.j2")

        rep.status = falcon.HTTP_200
        rep.content_type = "text/html"
        rep.text = template.render(page_title=f'healthKERI Edit Inbound Route - {self.hby.name}', **data)


    def on_post(self, req, rep, name):
        """ Inbound route update endpoint

        Parameters:
            req (Request): Falcon HTTP request object
            rep (Response): Falcon HTTP response object
            name (str): The aid of the Identifier requested
        """
        name = falcon.uri.decode(name)
        data = req.media
        route_type = data.get("route_type", "peer")
        route = self.rt.inbs.get(keys=(name,))

        if route is None:
            templating.error(rep, 'routes/http/inbound/edit_inbound.j2', data,
                             msg=f"Inbound route '{name}' not found")
            return

        route.localAID = data.get("aid", None)
        if not route.localAID:
            templating.error(rep, 'routes/http/inbound/edit_inbound.j2', data,
                             msg="Local AID is required")
            return

        if route.localAID not in self.hby.habs:
            templating.error(rep, 'routes/http/inbound/edit_inbound.j2', data,
                             msg=f"{route.localAID} is not a valid local source")
            return

        match route_type:
            case "peer":
                route.gateway = data.get("gateway", None)
                route.localHost = data.get("local_ip", "127.0.0.1")
                route.localPort = data.get("local_port", None)
                if not route.localPort:
                    templating.error(rep, 'routes/http/inbound/edit_inbound.j2', data,
                                     msg="Local Port is required")

                    return
                hab = self.hby.habs[route.localAID]
                dt = helping.nowIso8601()
                msgs = bytearray()
                msgs.extend(hab.makeEndRole(eid=hab.pre,
                                            role=kering.Roles.gateway,
                                            stamp=dt))
                msgs.extend(hab.makeLocScheme(url=f"{Schemes.http}://{route.localHost}:{route.localPort}/",
                                              scheme=Schemes.http,
                                              stamp=dt))
                hab.psr.parse(ims=msgs)

            case "cloud":
                route.router = data.get("router", None)
                route.gateway = data.get("cloud_gateway", None)
                route.localPort = 0
                route.localHost = ""

            case _:
                route.localPort = 0
                route.localHost = ""
                route.gateway = None
                route.router = None

        route.scheme = data.get("scheme", "http")
        if route.scheme not in ("http", "https", "tcp"):
            templating.error(rep, 'routes/http/inbound/edit_inbound.j2', data,
                             msg=f"{route.scheme} is not a valid scheme")
            return

        route.host = data.get("host", "127.0.0.1")
        route.port = int(data.get("port", 7777))

        route.anchoring = bool(data.get("anchoring", False))
        if route.anchoring:
            route.maximum = int(data.get("maximum", 1000))
            route.frequency = int(data.get("frequency", 60))
            route.interval = data.get("interval", "minutes")
            route.interactions = int(data.get("interactions", 100))
            route.rotations = int(data.get("rotations", 100))
        else:
            route.maximum = 0
            route.frequency = 0
            route.interval = None
            route.interactions = 0
            route.rotations = 0

        self.rt.inbs.pin(keys=(name,), val=route)
        self.rt.updateAidCounts()
        self.rt.updateGtwCounts()

        hxLocation = json.dumps({
            "path": f"/routes/inbound",
            "target": "body"
        })
        rep.set_header('HX-Location', hxLocation)
        rep.status = falcon.HTTP_200
        rep.text = b'Ok'

    def on_delete(self, _, rep, name):
        """ Inbound route delete endpoint

        Parameters:
            _ (Request): Falcon HTTP request object
            rep (Response): Falcon HTTP response object
            name (str): The aid of the Identifier requested
        """
        name = falcon.uri.decode(name)
        route = self.rt.inbs.get(keys=(name,))

        if route is None:
            templating.error(rep, 'routes/http/inbound/edit_inbound.j2', dict(),
                             msg=f"Unable to delete inbound route {name}.")
            return

        if not self.rt.inbs.rem(keys=(name,)):
            templating.error(rep, 'routes/http/inbound/edit_inbound.j2', dict(),
                             msg=f"Unable to delete inbound route {name}.")
            return

        self.rt.updateAidCounts()
        self.rt.updateGtwCounts()

        rep.status = falcon.HTTP_200
        hxLocation = json.dumps({
            "path": f"/routes/inbound",
            "target": "body"
        })
        rep.set_header('HX-Location', hxLocation)
        rep.text = b'Ok'

    def on_put(self, _, rep, name):
        """ Inbound route shutdown endpoint

        Parameters:
            _ (Request): Falcon HTTP request object
            rep (Response): Falcon HTTP response object
            name (str): The aid of the Identifier requested
        """
        name = falcon.uri.decode(name)

        try:
            self.router.shutdownInboundRoute(name)
        except ValueError as e:
            logger.info(e)
            templating.error(rep, 'routes/http/inbound/shutdown_inbound.j2', dict(),
                             msg=f"Unable to shutdown inbound route {name}: {e}.")
            return

        rep.status = falcon.HTTP_200
        hxLocation = json.dumps({
            "path": f"/routes/inbound",
            "target": "body"
        })
        rep.set_header('HX-Location', hxLocation)
        rep.text = b'Ok'


class InboundRouteLaunchEnd:
    def __init__(self, router, hby, rt):
        self.router = router
        self.hby = hby
        self.rt = rt

    def _create_fresh_connections(self):
        """Create fresh database connections for each operation"""
        rgy = credentialing.Regery(hby=self.hby, name=self.rt.name, temp=False)
        routery = scheming.Routery(name=self.rt.name, alias="rack", rt=self.rt, hby=self.hby, rgy=rgy)
        return rgy, routery

    def on_post(self, req, rep, name):
        """ Inbound route launch endpoint

        Parameters:
            req (Request): Falcon HTTP request object
            rep (Response): Falcon HTTP response object
            name (str): The aid of the Identifier requested
        """
        name = falcon.uri.decode(name)
        data = req.media
        if (inbound := self.rt.inbs.get(keys=(name,))) is None:
            templating.error(rep, 'routes/launch_error_inbound.j2', data,
                             msg="Name is already in use as an inbound route.")

            return

        if inbound.saids:
            templating.error(rep, 'routes/launch_error_inbound.j2', data,
                             msg=f"{name} is already running.")

            return

        essrParams = {"src": inbound.localAID, "dest": inbound.gateway}
        if inbound.anchoring:
            essrParams["maximum"] = inbound.maximum
            essrParams["frequency"] = inbound.frequency
            essrParams["interval"] = inbound.interval
            essrParams["interactions"] = inbound.interactions
            essrParams["rotations"] = inbound.rotations

        try:
            rgy, routery = self._create_fresh_connections()
            
            match inbound.route_type:
                case "peer":
                    self.generatePeerRoutes(name, inbound, routery)
                case "cloud":
                    self.generateCloudRoutes(name, inbound, essrParams, routery)
        except ValueError as e:
            templating.error(rep, 'routes/http/inbound/edit_inbound.j2', dict(),
                             msg=f"{e}")
            return

        hxLocation = json.dumps({
            "path": f"/routes/inbound",
            "target": "body"
        })
        rep.set_header('HX-Location', hxLocation)
        rep.status = falcon.HTTP_200
        rep.text = b'Ok'

    def on_delete(self, _, rep, name):
        """ Inbound route delete endpoint

        Parameters:
            _ (Request): Falcon HTTP request object
            rep (Response): Falcon HTTP response object
            name (str): The aid of the Identifier requested
        """
        name = falcon.uri.decode(name)

        if not self.rt.inbs.rem(keys=(name,)):
            templating.error(rep, 'routes/http/inbound/edit_inbound.j2', dict(),
                             msg=f"Unable to delete inbound route {name}.")
            return

        rep.status = falcon.HTTP_200
        hxLocation = json.dumps({
            "path": f"/routes/inbound",
            "target": "body"
        })
        rep.set_header('HX-Location', hxLocation)
        rep.text = b'Ok'

    def generatePeerRoutes(self, name, inbound, routery):
        """ Generate routes for a Peer-to-Peer gateway connection

        Parameters:
            name (str): Name of the route group
            inbound (InboundRoute): The database definition of the inbound route to generate
            essrParams (dict): Parameters for anchroing and rotating.
            routery (Routery): Fresh routery instance for route creation

        """
        config = self._build_route_config(inbound)
        inbound.saids = list()

        if inbound.scheme == "http":
            routeType = "http_inbound"
            route = routery.makeRoute(name=name, route_type=routeType, config=config)
        else:
            pass

        self.router.addRoute(routery.routes[route.said])
        self.router.reload()
        inbound.saids.append(route.said)
        self.rt.inbs.pin(keys=(name,), val=inbound)

    def _build_route_config(self, inboundRoute):
        """Build route configuration from form data"""
        aid = inboundRoute.localAID
        gateway = inboundRoute.gateway
        forward_port = inboundRoute.port or 7777
        forward_host = inboundRoute.host or "127.0.0.1"
        local_port = inboundRoute.localPort
        local_host = inboundRoute.localHost or "0.0.0.0"
        protocol = inboundRoute.scheme

        if not gateway:
            raise ValueError("Gateway AID is required")

        config = {
            "aid": aid,
            "tcpsrv": {
                "host": local_host,
                "port": local_port
            }
        }

        if protocol == "http":
            config["http"] = {
                "host": forward_host,
                "port": forward_port
            }

        if inboundRoute.anchoring == False:
            config["anchor"] = {
                "minimum": inboundRoute.minimum if hasattr(inboundRoute, "minimum") else 0,
                "maximum": inboundRoute.maximum or 1000,
                "frequency": inboundRoute.frequency or 60,
                "interval": inboundRoute.interval or "minutes",
                "interactions": inboundRoute.interactions or 100,
                "rotations": inboundRoute.rotations or 100
            }

        return config

    def _build_cloud_route_config(self, inboundRoute):
        """Build cloud route configuration from form data"""
        aid = inboundRoute.localAID
        forward_port = inboundRoute.port or 7777
        forward_host = inboundRoute.host or "127.0.0.1"
        protocol = inboundRoute.scheme

        router = self.rt.routers.get(keys=(inboundRoute.router,))

        if router is None:
            raise ValueError("Invalid router, no router found")

        config = {
            "aid": aid,
            "tcprmt": {
                "host": router.host,
                "port": int(router.port),
                "aid": router.aid
            }
        }

        if protocol == "http":
            config["http"] = {
                "host": forward_host,
                "port": forward_port
            }

        if inboundRoute.anchoring:
            config["anchor"] = {
                "minimum": inboundRoute.minimum if hasattr(inboundRoute, "minimum") else 0,
                "maximum": inboundRoute.maximum or 1000,
                "frequency": inboundRoute.frequency or 60,
                "interval": inboundRoute.interval or "minutes",
                "interactions": inboundRoute.interactions or 100,
                "rotations": inboundRoute.rotations or 100
            }

        return config

    def generateCloudRoutes(self, name, inbound, essrParams, routery):
        """ Generate routes for a cloud router based gateway connection

        Parameters:
            name (str): Name of the route group
            inbound (InboundRoute): The database definition of the inbound route to generate
            essrParams (dict): Parameters for anchroing and rotating.
            routery (Routery): Fresh routery instance for route creation

        """
        config = self._build_cloud_route_config(inbound)
        inbound.saids = list()

        if inbound.scheme == "http":
            routeType = "http_inbound"
            route = routery.makeRoute(name=name, route_type=routeType, config=config)
        else:
            pass

        self.router.addRoute(routery.routes[route.said])
        self.router.reload()
        inbound.saids.append(route.said)
        self.rt.inbs.pin(keys=(name,), val=inbound)

class InboundRouteFormCreateEnd:
    def __init__(self, hby, rt):
        self.hby = hby
        self.rt = rt

    def on_get(self, _, rep):
        """ Create Identifier form endpoint

        Parameters:
            _ (Request): Falcon HTTP request object
            rep (Response): Falcon HTTP response object
        """

        gateways = []
        for (aid,), destination in self.rt.dsts.getItemIter():
            d = dict(aid=aid, alias=destination.alias)
            gateways.append(d)

        identifiers = []
        for (aid,), identifier in self.rt.gators.getItemIter():
            d = dict(aid=aid, alias=identifier.alias)
            identifiers.append(d)

        routers = []
        for (name,), router in self.rt.routers.getItemIter():
            routers.append(dict(aid=router.aid, name=name))

        ip_addresses = list()
        ip_addresses.append("0.0.0.0")
        hostname = socket.gethostname()
        # Get all resolved addresses for the hostname
        for addr_info in socket.getaddrinfo(hostname, None):
            ip = addr_info[4][0]
            if ip not in ip_addresses:
                ip_addresses.append(ip)

        data = dict(
            gateways=gateways,
            routers=routers,
            identifiers=identifiers,
            ip_addresses=ip_addresses
        )

        template = J2_ENV.get_template('routes/http/inbound/create_inbound.j2')

        rep.status = falcon.HTTP_200
        rep.content_type = "text/html"
        rep.text = template.render(page_title=f'healthKERI Create Route - {self.hby.name}', **data)


class InboundRouteFormDeleteEnd:
    def __init__(self, hby, rt):
        self.hby = hby
        self.rt = rt

    def on_get(self, _, rep, name):
        """ Create Identifier form endpoint

        Parameters:
            _ (Request): Falcon HTTP request object
            rep (Response): Falcon HTTP response object
            name (str): name of outbound route

        """
        name = falcon.uri.decode(name)
        if (route := self.rt.inbs.get(keys=(name,))) is None:
            templating.error(rep, "routes/http/inbound/delete_inbound.j2", dict(), f"{name} is not a valid inbound route")
            return

        data = dict(
            name=name,
            route=route
        )

        template = J2_ENV.get_template('routes/http/inbound/delete_inbound.j2')

        rep.status = falcon.HTTP_200
        rep.content_type = "text/html"
        rep.text = template.render(page_title=f'healthKERI Delete Inbound Route - {self.hby.name}', **data)


class InboundRouteFormShutdownEnd:
    def __init__(self, hby, rt):
        self.hby = hby
        self.rt = rt

    def on_get(self, _, rep, name):
        """ Create Identifier form endpoint

        Parameters:
            _ (Request): Falcon HTTP request object
            rep (Response): Falcon HTTP response object
            name (str): name of outbound route

        """
        name = falcon.uri.decode(name)
        if (route := self.rt.inbs.get(keys=(name,))) is None:
            templating.error(rep, "routes/http/inbound/shutdown_inbound.j2", dict(), f"{name} is not a valid inbound route")
            return

        data = dict(
            name=name,
            route=route
        )

        template = J2_ENV.get_template('routes/http/inbound/shutdown_inbound.j2')

        rep.status = falcon.HTTP_200
        rep.content_type = "text/html"
        rep.text = template.render(page_title=f'healthKERI Shutdown Inbound Route - {self.hby.name}', **data)


class InboundRouteExportResourceEnd:
    def __init__(self, hby, rt):
        self.hby = hby
        self.rt = rt
        pass

    def on_get(self, _, rep, name):
        """ Get a display of an identifier

        Args:
            _ (Request): Falcon HTTP request object
            rep (Response): Falcon HTTP response object
            name (str): The name of the inbound route

        Returns:

        """
        name = falcon.uri.decode(name)
        if (route := self.rt.inbs.get(keys=(name,))) is None:
            templating.error(rep, "routes/http/inbound/view_inbound_route.j2", dict(), f"{name} is not a valid inbound route")
            return

        hab = self.hby.habs[route.localAID]

        ims = hab.replyToOobi(aid=hab.pre, role=kering.Roles.gateway)

        for _, delegate in self.rt.dlgs.getItemIter(keys=(hab.pre,)):
            for msg in hab.db.clonePreIter(pre=delegate, fn=0):
                ims.extend(msg)

        rep.status = falcon.HTTP_200
        rep.content_type = "application/cesr"
        rep.set_header("Content-Disposition", f"attachment; filename=\"{self.hby.name}-{name}.cesr\"")
        rep.data = ims
