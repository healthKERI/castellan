# -*- encoding: utf-8 -*-
"""
rack.app.ui.routes.sftp.outbounding module

"""
import json
import math
import socket
from urllib.parse import urlparse

import falcon
from keri import kering
from keri.help import helping, ogler
from keri.kering import Schemes
from keri.vdr import credentialing

from rack.app.ui import templating
from rack.app.ui.templating import J2_ENV
from rack.core import scheming
from rack.core.basing import SftpOutboundRoute
from rack.core.scheming import Procs

logger = ogler.getLogger()


def loadEnds(app, router):
    outboundCollectionEndpoint = OutboundRouteCollectionEnd(hby=router.hby, rt=router.rt)
    app.add_route("/routes/sftp/outbound", outboundCollectionEndpoint)

    outboundFormCreateEnd = OutboundRouteFormCreateEnd(hby=router.hby, rt=router.rt)
    app.add_route("/routes/sftp/outbound/forms/create", outboundFormCreateEnd)

    outboundFormDeleteEnd = OutboundRouteFormDeleteEnd(hby=router.hby, rt=router.rt)
    app.add_route("/routes/sftp/outbound/{name}/forms/delete", outboundFormDeleteEnd)

    outboundFormShutdownEnd = OutboundRouteFormShutdownEnd(hby=router.hby, rt=router.rt)
    app.add_route("/routes/sftp/outbound/{name}/forms/shutdown", outboundFormShutdownEnd)

    outboundResourceEnd = OutboundRouteResourceEnd(router=router)
    app.add_route("/routes/sftp/outbound/{name}", outboundResourceEnd)

    outboundLaunchEnd = OutboundRouteLaunchEnd(router=router, hby=router.hby, rt=router.rt)
    app.add_route("/routes/sftp/outbound/{name}/launch", outboundLaunchEnd)

    outboundExpResourceEnd = OutboundRouteExportResourceEnd(hby=router.hby, rt=router.rt)
    app.add_route("/routes/sftp/outbound/{name}/export", outboundExpResourceEnd)


class OutboundRouteCollectionEnd:
    """ SFTP Outbound Route Collection Endpoint Class """

    def __init__(self, hby, rt):
        self.hby = hby
        self.rt = rt

    def on_get(self, req, rep):
        """ SFTP outbound route collection list endpoint

        Parameters:
            req (Request): Falcon HTTP request object
            rep (Response): Falcon HTTP response object
        """
        page = int(req.get_param("page", default=0))
        page_count = req.get_param("page_count", default=templating.PAGE_COUNT)

        start = page * page_count
        start = start + 1 if start > 0 else start

        count = 0
        routes = []
        for (name,), route in self.rt.otbSftps.getItemIter():
            count += 1
            if count < start:
                continue

            hab = self.hby.habs[route.localAID]
            gateway = None
            if route.gateway:
                dest = self.rt.dsts.get(keys=(route.gateway,))
                if dest:
                    gateway = dest.alias

            router = None
            if route.router:
                rtr = self.rt.routers.get(keys=(route.router,))
                if rtr:
                    router = route.router

            match route.route_type:
                case "cloud":
                    route_type = "Cloud Router"
                case "peer":
                    route_type = "Peer-to-Peer"
                case _:
                    route_type = "Unknown"

            r = dict(
                name=name,
                identifier=hab.name,
                route_type=route_type,
                gateway=gateway,
                router=router,
                tcp=dict(
                    host=route.host,
                    port=route.port
                ) if route.host and route.port else None,
                sftpsrv=dict(
                    root=route.root
                ) if route.root else None,
                saids=route.saids
            )

            if route.lastPing is not None:
                r['ping'] = helping.fromIso8601(route.lastPing).astimezone().strftime("%Y-%m-%d %H:%M:%S")

            if len(routes) == page_count:
                continue

            routes.append(r)

        data = dict(
            page=page,
            num_pages=math.ceil(count / page_count),
            count=count,
            routes=routes
        )

        template = J2_ENV.get_template('routes/sftp/outbound/sftp_outbound_routes.j2')

        rep.status = falcon.HTTP_200
        rep.content_type = "text/html"
        rep.text = template.render(page_title=f'RACK Administration - {self.hby.name}', tab="sftp_outbound", **data)
    def on_post(self, req, rep):
        """ Create SFTP Outbound Route

        Parameters:
            req (Request): Falcon HTTP request object
            rep (Response): Falcon HTTP response object
        """
        data = req.media
        name = data.get("name", "")
        route_type = data.get("route_type", "peer")

        if not name:
            templating.error(rep, 'routes/sftp/outbound/create_sftp_outbound.j2', data,
                             msg="Name is required")
            return

        if self.rt.otbSftps.get(keys=(name,)) is not None:
            templating.error(rep, 'routes/sftp/outbound/create_sftp_outbound.j2', data,
                             msg="Name is already in use as an SFTP outbound route.")
            return

        aid = data.get("aid", None)
        if not aid:
            templating.error(rep, 'routes/sftp/outbound/create_sftp_outbound.j2', data,
                             msg="Local AID is required")
            return

        if aid not in self.hby.habs:
            templating.error(rep, 'routes/sftp/outbound/create_sftp_outbound.j2', data,
                             msg=f"{aid} is not a valid local source")
            return

        host = data.get("host", "127.0.0.1")
        port = int(data.get("port", 22))
        root = data.get("root", "")
        delete_original = bool(data.get("delete_original", False))

        if not root:
            templating.error(rep, 'routes/sftp/outbound/create_sftp_outbound.j2', data,
                             msg="SFTP root directory is required")
            return

        match route_type:
            case "peer":
                gateway = data.get("gateway", None)
                router = None
                schema = ""
                tcp_aid = gateway

            case "cloud":
                router = data.get("router", None)
                gateway = None
                schema = ""
                tcp_aid = router

            case "schema":
                schema = data.get("schema", None)
                gateway = None
                router = None
                tcp_aid = None

            case _:
                gateway = None
                router = None
                schema = ""
                tcp_aid = None

        outb = SftpOutboundRoute(
            localAID=aid,
            route_type=route_type,
            scheme="sftp",
            host=host,
            port=port,
            root=root,
            tcpAID=tcp_aid,
            delete_original=delete_original,
            gateway=gateway,
            router=router,
        )

        # Handle anchoring configuration
        outb.anchoring = bool(data.get("anchoring", False))
        if outb.anchoring:
            outb.minimum = int(data.get("minimum", 0))
            outb.maximum = int(data.get("maximum", 1000))
            outb.frequency = int(data.get("frequency", 60))
            outb.interval = data.get("interval", "minutes")
            outb.interactions = int(data.get("interactions", 100))
            outb.rotations = int(data.get("rotations", 100))
        else:
            outb.minimum = 0
            outb.maximum = 0
            outb.frequency = 0
            outb.interval = None
            outb.interactions = 0
            outb.rotations = 0

        self.rt.otbSftps.pin(keys=(name,), val=outb)
        self.rt.updateAidCounts()
        self.rt.updateGtwCounts()

        hxLocation = json.dumps({
            "path": f"/routes/sftp/outbound",
            "target": "body"
        })
        rep.set_header('HX-Location', hxLocation)
        rep.status = falcon.HTTP_200
        rep.text = b'Ok'

class OutboundRouteResourceEnd:
    def __init__(self, router):
        """

        Parameters:
            router (Router): Top level route coordinator

        """
        self.hby = router.hby
        self.rt = router.rt
        self.router = router

    def on_get(self, req, rep, name):
        """ Get a display of an SFTP outbound route

        Args:
            req (Request): Falcon HTTP request object
            rep (Response): Falcon HTTP response object
            name (str): The name of the outbound route

        Returns:

        """
        name = falcon.uri.decode(name)
        if (route := self.rt.otbSftps.get(keys=(name,))) is None:
            templating.error(rep, "routes/sftp/outbound/edit_sftp_outbound.j2", dict(), f"{name} is not a valid SFTP outbound route")
            return

        gateways = []
        for (aid,), destination in self.rt.dsts.getItemIter():
            d = dict(aid=aid, alias=destination.alias)
            gateways.append(d)

        identifiers = []
        for (aid,), identifier in self.rt.gators.getItemIter():
            d = dict(aid=aid, alias=identifier.alias)
            identifiers.append(d)

        routers = []
        for (routerName,), router in self.rt.routers.getItemIter():
            routers.append(dict(aid=router.aid, name=routerName))

        ip_addresses = list()
        ip_addresses.append("0.0.0.0")
        hostname = socket.gethostname()

        for addr_info in socket.getaddrinfo(hostname, None):
            ip = addr_info[4][0]
            if ip not in ip_addresses:
                ip_addresses.append(ip)

        data = dict(
            name=name,
            route=route,
            gateways=gateways,
            routers=routers,
            identifiers=identifiers,
            ip_addresses=ip_addresses
        )

        template = J2_ENV.get_template("routes/sftp/outbound/edit_sftp_outbound.j2")

        rep.status = falcon.HTTP_200
        rep.content_type = "text/html"
        rep.text = template.render(page_title=f'RACK Edit SFTP Outbound Route - {self.hby.name}', **data)
    def on_post(self, req, rep, name):
        """ SFTP outbound route update endpoint

        Parameters:
            req (Request): Falcon HTTP request object
            rep (Response): Falcon HTTP response object
            name (str): The name of the SFTP outbound route
        """
        name = falcon.uri.decode(name)
        data = req.media
        route_type = data.get("route_type", "peer")

        if (route := self.rt.otbSftps.get(keys=(name,))) is None:
            templating.error(rep, 'routes/sftp/outbound/edit_sftp_outbound.j2',
                             {'name': name, 'route': None},
                             msg=f"{name} is not a valid SFTP outbound route.")
            return

        route.localAID = data.get("aid", None)
        if not route.localAID:
            templating.error(rep, 'routes/sftp/outbound/edit_sftp_outbound.j2',
                             {'name': name, 'route': route},
                             msg="Local AID is required")
            return

        if route.localAID not in self.hby.habs:
            templating.error(rep, 'routes/sftp/outbound/edit_sftp_outbound.j2',
                             {'name': name, 'route': route},
                             msg=f"{route.localAID} is not a valid local source")
            return

        route.host = data.get("host", "127.0.0.1")
        route.port = int(data.get("port", 22))
        route.root = data.get("root", "")
        route.delete_original = bool(data.get("delete_original", False))

        if not route.root:
            templating.error(rep, 'routes/sftp/outbound/edit_sftp_outbound.j2',
                             {'name': name, 'route': route},
                             msg="SFTP root directory is required")
            return

        match route_type:
            case "peer":
                route.gateway = data.get("gateway", None)
                route.router = None
                route.tcpAID = route.gateway

            case "cloud":
                route.router = data.get("router", None)
                route.gateway = data.get("cloud_gateway", None)
                route.tcpAID = route.router

            case "schema":
                route.schema = data.get("schema", None)
                route.gateway = None
                route.router = None
                route.tcpAID = None

            case _:
                route.gateway = None
                route.router = None
                route.tcpAID = None

        route.route_type = route_type
        route.scheme = "sftp"

        route.anchoring = bool(data.get("anchoring", False))
        if route.anchoring:
            route.minimum = int(data.get("minimum", 0))
            route.maximum = int(data.get("maximum", 1000))
            route.frequency = int(data.get("frequency", 60))
            route.interval = data.get("interval", "minutes")
            route.interactions = int(data.get("interactions", 100))
            route.rotations = int(data.get("rotations", 100))
        else:
            route.minimum = 0
            route.maximum = 0
            route.frequency = 0
            route.interval = None
            route.interactions = 0
            route.rotations = 0

        self.rt.otbSftps.pin(keys=(name,), val=route)
        self.rt.updateAidCounts()
        self.rt.updateGtwCounts()

        hxLocation = json.dumps({
            "path": f"/routes/sftp/outbound",
            "target": "body"
        })
        rep.set_header('HX-Location', hxLocation)
        rep.status = falcon.HTTP_200
        rep.text = b'Ok'


    def on_delete(self, _, rep, name):
        """ SFTP outbound route delete endpoint

        Parameters:
            _ (Request): Falcon HTTP request object
            rep (Response): Falcon HTTP response object
            name (str): The name of the SFTP outbound route
        """
        name = falcon.uri.decode(name)
        route = self.rt.otbSftps.get(keys=(name,))

        if route is None:
            templating.error(rep, 'routes/sftp/outbound/edit_sftp_outbound.j2', dict(),
                             msg=f"Unable to delete SFTP outbound route {name}.")
            return

        if not self.rt.otbSftps.rem(keys=(name,)):
            templating.error(rep, 'routes/sftp/outbound/edit_sftp_outbound.j2', dict(),
                             msg=f"Unable to delete SFTP outbound route {name}.")
            return

        self.rt.updateAidCounts()
        self.rt.updateGtwCounts()

        rep.status = falcon.HTTP_200
        hxLocation = json.dumps({
            "path": f"/routes/sftp/outbound",
            "target": "body"
        })
        rep.set_header('HX-Location', hxLocation)
        rep.text = b'Ok'

    def on_put(self, _, rep, name):
        """ SFTP outbound route shutdown endpoint

        Parameters:
            _ (Request): Falcon HTTP request object
            rep (Response): Falcon HTTP response object
            name (str): The name of the SFTP outbound route
        """
        name = falcon.uri.decode(name)

        try:
            self.router.shutdownOutboundSftpRoute(name)
        except ValueError as e:
            logger.info(e)
            templating.error(rep, 'routes/sftp/outbound/shutdown_sftp_outbound.j2', dict(),
                             msg=f"Unable to shutdown SFTP outbound route {name}: {e}.")
            return

        rep.status = falcon.HTTP_200
        hxLocation = json.dumps({
            "path": f"/routes/sftp/outbound",
            "target": "body"
        })
        rep.set_header('HX-Location', hxLocation)
        rep.text = b'Ok'


class OutboundRouteLaunchEnd:
    def __init__(self, router, hby, rt):
        self.router = router
        self.hby = hby
        self.rt = rt

    def _create_fresh_connections(self):
        """Create fresh database connections for each operation"""
        rgy = credentialing.Regery(hby=self.hby, name=self.rt.name, temp=False)
        routery = scheming.Routery(name=self.rt.name, alias="rack", rt=self.rt, hby=self.hby, rgy=rgy)
        return rgy, routery

    def on_post(self, req, rep, name):
        """ SFTP outbound route launch endpoint

        Parameters:
            req (Request): Falcon HTTP request object
            rep (Response): Falcon HTTP response object
            name (str): The name of the SFTP outbound route
        """
        name = falcon.uri.decode(name)
        data = req.media
        if (outbound := self.rt.otbSftps.get(keys=(name,))) is None:
            templating.error(rep, 'routes/launch_error_outbound.j2', data,
                             msg=f"{name} is not a valid SFTP outbound route.")
            return

        if outbound.saids:
            templating.error(rep, 'routes/launch_error_outbound.j2', data,
                             msg=f"{name} is already running.")
            return

        essrParams = {"src": outbound.localAID, "dest": outbound.gateway}
        if outbound.anchoring:
            essrParams["minimum"] = outbound.minimum
            essrParams["maximum"] = outbound.maximum
            essrParams["frequency"] = outbound.frequency
            essrParams["interval"] = outbound.interval
            essrParams["interactions"] = outbound.interactions
            essrParams["rotations"] = outbound.rotations

        try:
            # Create fresh connections for this operation
            rgy, routery = self._create_fresh_connections()

            match outbound.route_type:
                case "peer":
                    self.generatePeerRoutes(name, outbound, routery)
                case "cloud":
                    self.generateCloudRoutes(name, outbound, essrParams, routery)
        except ValueError as e:
            templating.error(rep, 'routes/sftp/outbound/edit_sftp_outbound.j2', dict(),
                             msg=f"{e}")
            return

        hxLocation = json.dumps({
            "path": f"/routes/sftp/outbound",
            "target": "body"
        })
        rep.set_header('HX-Location', hxLocation)
        rep.status = falcon.HTTP_200
        rep.text = b'Ok'

    def on_delete(self, _, rep, name):
        """ SFTP outbound route delete endpoint

        Parameters:
            _ (Request): Falcon HTTP request object
            rep (Response): Falcon HTTP response object
            name (str): The name of the SFTP outbound route
        """
        name = falcon.uri.decode(name)

        if not self.rt.otbSftps.rem(keys=(name,)):
            templating.error(rep, 'routes/sftp/outbound/edit_sftp_outbound.j2', dict(),
                             msg=f"Unable to delete SFTP outbound route {name}.")
            return

        rep.status = falcon.HTTP_200
        hxLocation = json.dumps({
            "path": f"/routes/sftp/outbound",
            "target": "body"
        })
        rep.set_header('HX-Location', hxLocation)
        rep.text = b'Ok'

    def generatePeerRoutes(self, name, outbound, routery):
        """ Generate routes for a Peer-to-Peer SFTP gateway connection

        Parameters:
            name (str): Name of the route group
            outbound (SftpOutboundRoute): The database definition of the SFTP outbound route to generate
            routery (Routery): Fresh routery instance for route creation

        """
        config = self._build_route_config(outbound)
        outbound.saids = list()

        if outbound.scheme == "sftp":
            routeType = "sftp_outbound"
            route = routery.makeRoute(name=name, route_type=routeType, config=config)
        else:
            logger.error(f"Unsupported scheme for SFTP route: {outbound.scheme}")
            raise ValueError(f"Unsupported scheme: {outbound.scheme}")

        self.router.addRoute(routery.routes[route.said])
        self.router.reload()
        outbound.saids.append(route.said)
        self.rt.otbSftps.pin(keys=(name,), val=outbound)
        logger.info(f"SFTP outbound route {name} launched: {outbound}")

    def generateCloudRoutes(self, name, outbound, essrParams, routery):
        """ Generate routes for a Cloud Router SFTP connection

        Parameters:
            name (str): Name of the route group
            outbound (SftpOutboundRoute): The database definition of the SFTP outbound route
            essrParams (dict): Parameters for anchoring and rotating
            routery (Routery): Fresh routery instance for route creation

        """
        config = self._build_cloud_route_config(outbound)
        outbound.saids = list()

        # Handle cloud router SFTP route creation
        if outbound.scheme == "sftp":
            routeType = "sftp_outbound"
            route = routery.makeRoute(name=name, route_type=routeType, config=config)
        else:
            logger.error(f"Unsupported scheme for SFTP cloud route: {outbound.scheme}")
            raise ValueError(f"Unsupported scheme: {outbound.scheme}")

        self.router.addRoute(routery.routes[route.said])
        self.router.reload()
        outbound.saids.append(route.said)
        self.rt.otbSftps.pin(keys=(name,), val=outbound)
        logger.info(f"SFTP cloud outbound route {name} launched: {outbound}")

    def _build_route_config(self, outboundRoute):
        """Build SFTP route configuration from route data"""
        aid = outboundRoute.localAID
        gateway = outboundRoute.gateway
        host = outboundRoute.host or "127.0.0.1"
        port = outboundRoute.port or 22
        tcp_aid = outboundRoute.tcpAID
        root = outboundRoute.root
        delete_original = outboundRoute.delete_original

        if not gateway:
            raise ValueError("Gateway AID is required")

        if not root:
            raise ValueError("SFTP root directory is required")

        if not tcp_aid:
            raise ValueError("TCP Agent Identifier is required")

        config = {
            "aid": aid,
            "tcp": {
                "aid": tcp_aid,
                "host": host,
                "port": port
            },
            "sftpsrv": {
                "root": root,
                "delete_original": delete_original
            }
        }

        if outboundRoute.anchoring:
            config["anchor"] = {
                "minimum": getattr(outboundRoute, "minimum", 0),
                "maximum": outboundRoute.maximum or 1000,
                "frequency": outboundRoute.frequency or 60,
                "interval": outboundRoute.interval or "minutes",
                "interactions": outboundRoute.interactions or 100,
                "rotations": outboundRoute.rotations or 100
            }

        return config

    def _build_cloud_route_config(self, outboundRoute):
        """Build SFTP cloud route configuration from route data"""
        aid = outboundRoute.localAID
        router = outboundRoute.router
        root = outboundRoute.root
        delete_original = outboundRoute.delete_original

        if not router:
            raise ValueError("Router AID is required for cloud routes")

        if not root:
            raise ValueError("SFTP root directory is required")

        rtr = self.rt.routers.get(keys=(router,))
        if not rtr:
            raise ValueError(f"Router {router} not found")

        config = {
            "aid": aid,
            "tcp": {
                "host": rtr.host,
                "port": rtr.port,
                "aid": rtr.aid,
            },
            "sftpsrv": {
                "root": root,
                "delete_original": delete_original
            },
        }

        if outboundRoute.anchoring:
            config["anchor"] = {
                "minimum": getattr(outboundRoute, "minimum", 0),
                "maximum": outboundRoute.maximum or 1000,
                "frequency": outboundRoute.frequency or 60,
                "interval": outboundRoute.interval or "minutes",
                "interactions": outboundRoute.interactions or 100,
                "rotations": outboundRoute.rotations or 100
            }

        return config

class OutboundRouteFormCreateEnd:
    def __init__(self, hby, rt):
        self.hby = hby
        self.rt = rt

    def on_get(self, _, rep):
        """ Create SFTP Outbound Route form endpoint

        Parameters:
            _ (Request): Falcon HTTP request object
            rep (Response): Falcon HTTP response object
        """

        gateways = []
        for (aid,), destination in self.rt.dsts.getItemIter():
            d = dict(aid=aid, alias=destination.alias)
            gateways.append(d)

        identifiers = []
        for (aid,), identifier in self.rt.gators.getItemIter():
            d = dict(aid=aid, alias=identifier.alias)
            identifiers.append(d)

        routers = []
        for (name,), router in self.rt.routers.getItemIter():
            routers.append(dict(aid=router.aid, name=name))

        ip_addresses = list()
        ip_addresses.append("0.0.0.0")
        hostname = socket.gethostname()

        for addr_info in socket.getaddrinfo(hostname, None):
            ip = addr_info[4][0]
            if ip not in ip_addresses:
                ip_addresses.append(ip)

        data = dict(
            gateways=gateways,
            routers=routers,
            identifiers=identifiers,
            ip_addresses=ip_addresses
        )

        template = J2_ENV.get_template('routes/sftp/outbound/create_sftp_outbound.j2')

        rep.status = falcon.HTTP_200
        rep.content_type = "text/html"
        rep.text = template.render(page_title=f'RACK Create SFTP Outbound Route - {self.hby.name}', **data)


class OutboundRouteFormDeleteEnd:
    def __init__(self, hby, rt):
        self.hby = hby
        self.rt = rt

    def on_get(self, _, rep, name):
        """ SFTP Outbound Route delete form endpoint

        Parameters:
            _ (Request): Falcon HTTP request object
            rep (Response): Falcon HTTP response object
            name (str): name of SFTP outbound route

        """
        name = falcon.uri.decode(name)
        if (route := self.rt.otbSftps.get(keys=(name,))) is None:
            templating.error(rep, "routes/sftp/outbound/delete_sftp_outbound.j2", dict(), f"{name} is not a valid SFTP outbound route")
            return

        data = dict(
            name=name,
            route=route
        )

        template = J2_ENV.get_template('routes/sftp/outbound/delete_sftp_outbound.j2')

        rep.status = falcon.HTTP_200
        rep.content_type = "text/html"
        rep.text = template.render(page_title=f'RACK Delete SFTP Outbound Route - {self.hby.name}', **data)


class OutboundRouteFormShutdownEnd:
    def __init__(self, hby, rt):
        self.hby = hby
        self.rt = rt

    def on_get(self, _, rep, name):
        """ SFTP Outbound Route shutdown form endpoint

        Parameters:
            _ (Request): Falcon HTTP request object
            rep (Response): Falcon HTTP response object
            name (str): name of SFTP outbound route

        """
        name = falcon.uri.decode(name)
        if (route := self.rt.otbSftps.get(keys=(name,))) is None:
            templating.error(rep, "routes/sftp/outbound/shutdown_sftp_outbound.j2", dict(), f"{name} is not a valid SFTP outbound route")
            return

        data = dict(
            name=name,
            route=route
        )

        template = J2_ENV.get_template('routes/sftp/outbound/shutdown_sftp_outbound.j2')

        rep.status = falcon.HTTP_200
        rep.content_type = "text/html"
        rep.text = template.render(page_title=f'RACK Shutdown SFTP Outbound Route - {self.hby.name}', **data)


class OutboundRouteExportResourceEnd:
    def __init__(self, hby, rt):
        self.hby = hby
        self.rt = rt

    def on_get(self, _, rep, name):
        """ Export SFTP Outbound Route configuration

        Args:
            _ (Request): Falcon HTTP request object
            rep (Response): Falcon HTTP response object
            name (str): The name of the SFTP outbound route

        Returns:

        """
        name = falcon.uri.decode(name)
        if (route := self.rt.otbSftps.get(keys=(name,))) is None:
            templating.error(rep, "routes/sftp/outbound/view_sftp_outbound_route.j2", dict(), f"{name} is not a valid SFTP outbound route")
            return

        hab = self.hby.habs[route.localAID]

        ims = hab.replyToOobi(aid=hab.pre, role=kering.Roles.gateway)

        for _, delegate in self.rt.dlgs.getItemIter(keys=(hab.pre,)):
            for msg in hab.db.clonePreIter(pre=delegate, fn=0):
                ims.extend(msg)

        rep.status = falcon.HTTP_200
        rep.content_type = "application/cesr"
        rep.set_header("Content-Disposition", f"attachment; filename=\"{self.hby.name}-{name}-sftp.cesr\"")
        rep.data = ims