# -*- encoding: utf-8 -*-
"""
rack.app.ui.routes.mllp.inbounding module

"""
import json
import math
import socket
from urllib.parse import urlparse

import falcon
from keri import kering
from keri.help import helping, ogler
from keri.kering import Schemes
from keri.vdr import credentialing

from rack.app.ui import templating
from rack.app.ui.templating import J2_ENV
from rack.core import scheming
from rack.core.basing import MllpInboundRoute
from rack.core.scheming import Procs

logger = ogler.getLogger()


def loadEnds(app, router):
    inboundCollectionEndpoint = InboundRouteCollectionEnd(hby=router.hby, rt=router.rt)
    app.add_route("/routes/mllp/inbound", inboundCollectionEndpoint)

    inboundFormCreateEnd = InboundRouteFormCreateEnd(hby=router.hby, rt=router.rt)
    app.add_route("/routes/mllp/inbound/forms/create", inboundFormCreateEnd)

    inboundFormDeleteEnd = InboundRouteFormDeleteEnd(hby=router.hby, rt=router.rt)
    app.add_route("/routes/mllp/inbound/{name}/forms/delete", inboundFormDeleteEnd)

    inboundFormShutdownEnd = InboundRouteFormShutdownEnd(hby=router.hby, rt=router.rt)
    app.add_route("/routes/mllp/inbound/{name}/forms/shutdown", inboundFormShutdownEnd)

    inboundResourceEnd = InboundRouteResourceEnd(router=router)
    app.add_route("/routes/mllp/inbound/{name}", inboundResourceEnd)

    inboundLaunchEnd = InboundRouteLaunchEnd(router=router, hby=router.hby, rt=router.rt)
    app.add_route("/routes/mllp/inbound/{name}/launch", inboundLaunchEnd)

    inboundExpResourceEnd = InboundRouteExportResourceEnd(hby=router.hby, rt=router.rt)
    app.add_route("/routes/mllp/inbound/{name}/export", inboundExpResourceEnd)


class InboundRouteCollectionEnd:
    """ MLLP Inbound Route Collection Endpoint Class """

    def __init__(self, hby, rt):
        self.hby = hby
        self.rt = rt

    def on_get(self, req, rep):
        """ MLLP inbound route collection list endpoint

        Parameters:
            req (Request): Falcon HTTP request object
            rep (Response): Falcon HTTP response object
        """
        page = int(req.get_param("page", default=0))
        page_count = req.get_param("page_count", default=templating.PAGE_COUNT)

        start = page * page_count
        start = start + 1 if start > 0 else start

        count = 0
        routes = []
        for (name,), route in self.rt.inbMllps.getItemIter():
            count += 1
            if count < start:
                continue

            hab = self.hby.habs[route.localAID]
            gateway = None
            if route.gateway:
                dest = self.rt.dsts.get(keys=(route.gateway,))
                if dest:
                    gateway = dest.alias

            router = None
            if route.router:
                rtr = self.rt.routers.get(keys=(route.router,))
                if rtr:
                    router = route.router

            match route.route_type:
                case "cloud":
                    route_type = "Cloud Router"
                case "peer":
                    route_type = "Peer-to-Peer"
                case _:
                    route_type = "Unknown"

            r = dict(
                name=name,
                identifier=hab.name,
                route_type=route_type,
                gateway=gateway,
                router=router,
                tcpsrv=dict(
                    host=route.host,
                    port=route.port
                ) if route.host and route.port else None,
                mllp=dict(
                    host=route.mllp_host,
                    port=route.mllp_port
                ) if route.mllp_host and route.mllp_port else None,
                saids=route.saids
            )

            if route.lastPing is not None:
                r['ping'] = helping.fromIso8601(route.lastPing).astimezone().strftime("%Y-%m-%d %H:%M:%S")

            if len(routes) == page_count:
                continue

            routes.append(r)

        data = dict(
            page=page,
            num_pages=math.ceil(count / page_count),
            count=count,
            routes=routes
        )

        template = J2_ENV.get_template('routes/mllp/inbound/mllp_inbound_routes.j2')

        rep.status = falcon.HTTP_200
        rep.content_type = "text/html"
        rep.text = template.render(page_title=f'RACK Administration - {self.hby.name}', tab="mllp_inbound", **data)

    def on_post(self, req, rep):
        """ Create MLLP Inbound Route

        Parameters:
            req (Request): Falcon HTTP request object
            rep (Response): Falcon HTTP response object
        """
        data = req.media
        name = data.get("name", "")
        route_type = data.get("route_type", "peer")

        if not name:
            templating.error(rep, 'routes/mllp/inbound/create_mllp_inbound.j2', data,
                             msg="Name is required")
            return

        if self.rt.inbMllps.get(keys=(name,)) is not None:
            templating.error(rep, 'routes/mllp/inbound/create_mllp_inbound.j2', data,
                             msg="Name is already in use as an MLLP inbound route.")
            return

        aid = data.get("aid", None)
        if not aid:
            templating.error(rep, 'routes/mllp/inbound/create_mllp_inbound.j2', data,
                             msg="Local AID is required")
            return

        if aid not in self.hby.habs:
            templating.error(rep, 'routes/mllp/inbound/create_mllp_inbound.j2', data,
                             msg=f"{aid} is not a valid local source")
            return

        host = data.get("host", "127.0.0.1")
        port = int(data.get("port", 8080))

        mllp_host = data.get("mllp_host", "127.0.0.1")
        mllp_port = int(data.get("mllp_port", 2575))

        match route_type:
            case "peer":
                gateway = data.get("gateway", None)
                router = None

            case "cloud":
                router = data.get("router", None)
                gateway = data.get("cloud_router", None)

            case _:
                gateway = None
                router = None

        if route_type == "peer":
            if not gateway:
                templating.error(rep, 'routes/mllp/inbound/create_mllp_inbound.j2', data,
                                 msg="Remote gateway is required for peer-to-peer routes")
                return
        elif route_type == "cloud":
            if not router:
                templating.error(rep, 'routes/mllp/inbound/create_mllp_inbound.j2', data,
                                 msg="Cloud router is required for cloud routes")
                return

        inb = MllpInboundRoute(
            localAID=aid,
            route_type=route_type,
            scheme="mllp",
            host=host,
            port=port,
            mllp_host=mllp_host,
            mllp_port=mllp_port,
            gateway=gateway,
            router=router,
        )

        inb.anchoring = bool(data.get("anchoring", False))
        if inb.anchoring:
            inb.minimum = int(data.get("minimum", 0))
            inb.maximum = int(data.get("maximum", 1000))
            inb.frequency = int(data.get("frequency", 60))
            inb.interval = data.get("interval", "minutes")
            inb.interactions = int(data.get("interactions", 100))
            inb.rotations = int(data.get("rotations", 100))
        else:
            inb.minimum = 0
            inb.maximum = 0
            inb.frequency = 0
            inb.interval = None
            inb.interactions = 0
            inb.rotations = 0

        self.rt.inbMllps.pin(keys=(name,), val=inb)
        self.rt.updateAidCounts()
        self.rt.updateGtwCounts()

        hxLocation = json.dumps({
            "path": f"/routes/mllp/inbound",
            "target": "body"
        })
        rep.set_header('HX-Location', hxLocation)
        rep.status = falcon.HTTP_200
        rep.text = b'Ok'


class InboundRouteResourceEnd:
    def __init__(self, router):
        """

        Parameters:
            router (Router): Top level route coordinator

        """
        self.hby = router.hby
        self.rt = router.rt
        self.router = router

    def on_get(self, req, rep, name):
        """ Get a display of an MLLP inbound route

        Args:
            req (Request): Falcon HTTP request object
            rep (Response): Falcon HTTP response object
            name (str): The name of the inbound route

        Returns:

        """
        name = falcon.uri.decode(name)
        if (route := self.rt.inbMllps.get(keys=(name,))) is None:
            templating.error(rep, "routes/mllp/inbound/edit_mllp_inbound.j2", dict(), f"{name} is not a valid MLLP inbound route")
            return

        gateways = []
        for (aid,), destination in self.rt.dsts.getItemIter():
            d = dict(aid=aid, alias=destination.alias)
            gateways.append(d)

        identifiers = []
        for (aid,), identifier in self.rt.gators.getItemIter():
            d = dict(aid=aid, alias=identifier.alias)
            identifiers.append(d)

        routers = []
        for (routerName,), router in self.rt.routers.getItemIter():
            routers.append(dict(aid=router.aid, name=routerName))

        ip_addresses = list()
        ip_addresses.append("0.0.0.0")
        hostname = socket.gethostname()

        for addr_info in socket.getaddrinfo(hostname, None):
            ip = addr_info[4][0]
            if ip not in ip_addresses:
                ip_addresses.append(ip)

        data = dict(
            name=name,
            route=route,
            gateways=gateways,
            routers=routers,
            identifiers=identifiers,
            ip_addresses=ip_addresses
        )

        template = J2_ENV.get_template("routes/mllp/inbound/edit_mllp_inbound.j2")

        rep.status = falcon.HTTP_200
        rep.content_type = "text/html"
        rep.text = template.render(page_title=f'RACK Edit MLLP Inbound Route - {self.hby.name}', **data)

    def on_post(self, req, rep, name):
        """ MLLP inbound route update endpoint

        Parameters:
            req (Request): Falcon HTTP request object
            rep (Response): Falcon HTTP response object
            name (str): The name of the MLLP inbound route
        """
        name = falcon.uri.decode(name)
        data = req.media
        route_type = data.get("route_type", "peer")

        if (route := self.rt.inbMllps.get(keys=(name,))) is None:
            templating.error(rep, 'routes/mllp/inbound/edit_mllp_inbound.j2',
                             {'name': name, 'route': None},
                             msg=f"{name} is not a valid MLLP inbound route.")
            return

        route.localAID = data.get("aid", None)
        if not route.localAID:
            templating.error(rep, 'routes/mllp/inbound/edit_mllp_inbound.j2',
                             {'name': name, 'route': route},
                             msg="Local AID is required")
            return

        if route.localAID not in self.hby.habs:
            templating.error(rep, 'routes/mllp/inbound/edit_mllp_inbound.j2',
                             {'name': name, 'route': route},
                             msg=f"{route.localAID} is not a valid local source")
            return

        route.host = data.get("host", "127.0.0.1")
        route.port = int(data.get("port", 8080))

        route.mllp_host = data.get("mllp_host", "127.0.0.1")
        route.mllp_port = int(data.get("mllp_port", 2575))

        match route_type:
            case "peer":
                route.gateway = data.get("gateway", None)
                route.router = None

            case "cloud":
                route.router = data.get("router", None)
                route.gateway = data.get("cloud_gateway", None)

            case _:
                route.gateway = None
                route.router = None

        if route_type == "peer":
            if not route.gateway:
                templating.error(rep, 'routes/mllp/inbound/edit_mllp_inbound.j2',
                                 {'name': name, 'route': route},
                                 msg="Remote gateway is required for peer-to-peer routes")
                return
        elif route_type == "cloud":
            if not route.router:
                templating.error(rep, 'routes/mllp/inbound/edit_mllp_inbound.j2',
                                 {'name': name, 'route': route},
                                 msg="Cloud router is required for cloud routes")
                return

        route.route_type = route_type
        route.scheme = "mllp"

        route.anchoring = bool(data.get("anchoring", False))
        if route.anchoring:
            route.minimum = int(data.get("minimum", 0))
            route.maximum = int(data.get("maximum", 1000))
            route.frequency = int(data.get("frequency", 60))
            route.interval = data.get("interval", "minutes")
            route.interactions = int(data.get("interactions", 100))
            route.rotations = int(data.get("rotations", 100))
        else:
            route.minimum = 0
            route.maximum = 0
            route.frequency = 0
            route.interval = None
            route.interactions = 0
            route.rotations = 0

        self.rt.inbMllps.pin(keys=(name,), val=route)
        self.rt.updateAidCounts()
        self.rt.updateGtwCounts()

        hxLocation = json.dumps({
            "path": f"/routes/mllp/inbound",
            "target": "body"
        })
        rep.set_header('HX-Location', hxLocation)
        rep.status = falcon.HTTP_200
        rep.text = b'Ok'

    def on_delete(self, _, rep, name):
        """ MLLP inbound route delete endpoint

        Parameters:
            _ (Request): Falcon HTTP request object
            rep (Response): Falcon HTTP response object
            name (str): The name of the MLLP inbound route
        """
        name = falcon.uri.decode(name)
        route = self.rt.inbMllps.get(keys=(name,))

        if route is None:
            templating.error(rep, 'routes/mllp/inbound/edit_mllp_inbound.j2', dict(),
                             msg=f"Unable to delete MLLP inbound route {name}.")
            return

        if not self.rt.inbMllps.rem(keys=(name,)):
            templating.error(rep, 'routes/mllp/inbound/edit_mllp_inbound.j2', dict(),
                             msg=f"Unable to delete MLLP inbound route {name}.")
            return

        self.rt.updateAidCounts()
        self.rt.updateGtwCounts()

        rep.status = falcon.HTTP_200
        hxLocation = json.dumps({
            "path": f"/routes/mllp/inbound",
            "target": "body"
        })
        rep.set_header('HX-Location', hxLocation)
        rep.text = b'Ok'

    def on_put(self, _, rep, name):
        """ MLLP inbound route shutdown endpoint

        Parameters:
            _ (Request): Falcon HTTP request object
            rep (Response): Falcon HTTP response object
            name (str): The name of the MLLP inbound route
        """
        name = falcon.uri.decode(name)

        try:
            self.router.shutdownInboundMllpRoute(name)
        except ValueError as e:
            logger.info(e)
            templating.error(rep, 'routes/mllp/inbound/shutdown_mllp_inbound.j2', dict(),
                             msg=f"Unable to shutdown MLLP inbound route {name}: {e}.")
            return

        rep.status = falcon.HTTP_200
        hxLocation = json.dumps({
            "path": f"/routes/mllp/inbound",
            "target": "body"
        })
        rep.set_header('HX-Location', hxLocation)
        rep.text = b'Ok'


class InboundRouteLaunchEnd:
    def __init__(self, router, hby, rt):
        self.router = router
        self.hby = hby
        self.rt = rt

    def _create_fresh_connections(self):
        """Create fresh database connections for each operation"""
        rgy = credentialing.Regery(hby=self.hby, name=self.rt.name, temp=False)
        routery = scheming.Routery(name=self.rt.name, alias="rack", rt=self.rt, hby=self.hby, rgy=rgy)
        return rgy, routery

    def on_post(self, req, rep, name):
        """ MLLP inbound route launch endpoint

        Parameters:
            req (Request): Falcon HTTP request object
            rep (Response): Falcon HTTP response object
            name (str): The name of the MLLP inbound route
        """
        name = falcon.uri.decode(name)
        data = req.media
        if (inbound := self.rt.inbMllps.get(keys=(name,))) is None:
            templating.error(rep, 'routes/launch_error_inbound.j2', data,
                             msg=f"{name} is not a valid MLLP inbound route.")
            return

        if inbound.saids:
            templating.error(rep, 'routes/launch_error_inbound.j2', data,
                             msg=f"{name} is already running.")
            return

        essrParams = {"src": inbound.localAID, "dest": inbound.gateway}
        if inbound.anchoring:
            essrParams["minimum"] = inbound.minimum
            essrParams["maximum"] = inbound.maximum
            essrParams["frequency"] = inbound.frequency
            essrParams["interval"] = inbound.interval
            essrParams["interactions"] = inbound.interactions
            essrParams["rotations"] = inbound.rotations

        try:
            # Create fresh connections for this operation
            rgy, routery = self._create_fresh_connections()

            match inbound.route_type:
                case "peer":
                    self.generatePeerRoutes(name, inbound, routery)
                case "cloud":
                    self.generateCloudRoutes(name, inbound, essrParams, routery)
        except ValueError as e:
            templating.error(rep, 'routes/mllp/inbound/edit_mllp_inbound.j2', dict(),
                             msg=f"{e}")
            return

        hxLocation = json.dumps({
            "path": f"/routes/mllp/inbound",
            "target": "body"
        })
        rep.set_header('HX-Location', hxLocation)
        rep.status = falcon.HTTP_200
        rep.text = b'Ok'

    def generatePeerRoutes(self, name, inbound, routery):
        """ Generate routes for a Peer-to-Peer MLLP gateway connection

        Parameters:
            name (str): Name of the route group
            inbound (MllpInboundRoute): The database definition of the MLLP inbound route to generate
            routery (Routery): Fresh routery instance for route creation

        """
        config = self._build_route_config(inbound)
        inbound.saids = list()

        if inbound.scheme == "mllp":
            routeType = "mllp_inbound"
            route = routery.makeRoute(name=name, route_type=routeType, config=config)
        else:
            logger.error(f"Unsupported scheme for MLLP route: {inbound.scheme}")
            raise ValueError(f"Unsupported scheme: {inbound.scheme}")

        self.router.addRoute(routery.routes[route.said])
        self.router.reload()
        inbound.saids.append(route.said)
        self.rt.inbMllps.pin(keys=(name,), val=inbound)
        logger.info(f"MLLP inbound route {name} launched: {inbound}")

    def generateCloudRoutes(self, name, inbound, essrParams, routery):
        """ Generate routes for a Cloud Router MLLP connection

        Parameters:
            name (str): Name of the route group
            inbound (MllpInboundRoute): The database definition of the MLLP inbound route
            essrParams (dict): Parameters for anchoring and rotating
            routery (Routery): Fresh routery instance for route creation

        """
        config = self._build_cloud_route_config(inbound)
        inbound.saids = list()

        # Handle cloud router MLLP route creation
        if inbound.scheme == "mllp":
            routeType = "mllp_inbound"
            route = routery.makeRoute(name=name, route_type=routeType, config=config)
        else:
            logger.error(f"Unsupported scheme for MLLP cloud route: {inbound.scheme}")
            raise ValueError(f"Unsupported scheme: {inbound.scheme}")

        self.router.addRoute(routery.routes[route.said])
        self.router.reload()  # Add the new doers to the running router
        inbound.saids.append(route.said)
        self.rt.inbMllps.pin(keys=(name,), val=inbound)
        logger.info(f"MLLP cloud inbound route {name} launched: {inbound}")

    def _build_route_config(self, inboundRoute):
        """Build MLLP route configuration from route data for peer routes"""
        aid = inboundRoute.localAID
        gateway = inboundRoute.gateway
        host = inboundRoute.host or "127.0.0.1"
        port = inboundRoute.port or 8080
        mllp_host = inboundRoute.mllp_host or "127.0.0.1"
        mllp_port = inboundRoute.mllp_port or 2575

        if not gateway:
            raise ValueError("Gateway AID is required")

        config = {
            "aid": aid,
            "tcpsrv": {
                "host": host,
                "port": port
            },
            "mllp": {
                "host": mllp_host,
                "port": mllp_port
            }
        }

        if inboundRoute.anchoring:
            config["anchor"] = {
                "minimum": getattr(inboundRoute, "minimum", 0),
                "maximum": inboundRoute.maximum or 1000,
                "frequency": inboundRoute.frequency or 60,
                "interval": inboundRoute.interval or "minutes",
                "interactions": inboundRoute.interactions or 100,
                "rotations": inboundRoute.rotations or 100
            }

        return config

    def _build_cloud_route_config(self, inboundRoute):
        """Build MLLP cloud route configuration from route data"""
        aid = inboundRoute.localAID
        router = inboundRoute.router
        mllp_host = inboundRoute.mllp_host or "127.0.0.1"
        mllp_port = inboundRoute.mllp_port or 2575

        if not router:
            raise ValueError("Router AID is required for cloud routes")

        rtr = self.rt.routers.get(keys=(router,))
        if not rtr:
            raise ValueError(f"Router {router} not found")

        config = {
            "aid": aid,
            "tcprmt": {
                "host": rtr.host,
                "port": rtr.port
            },
            "mllp": {
                "host": mllp_host,
                "port": mllp_port
            }
        }

        if inboundRoute.anchoring:
            config["anchor"] = {
                "minimum": getattr(inboundRoute, "minimum", 0),
                "maximum": inboundRoute.maximum or 1000,
                "frequency": inboundRoute.frequency or 60,
                "interval": inboundRoute.interval or "minutes",
                "interactions": inboundRoute.interactions or 100,
                "rotations": inboundRoute.rotations or 100
            }

        return config


class InboundRouteFormCreateEnd:
    def __init__(self, hby, rt):
        self.hby = hby
        self.rt = rt

    def on_get(self, _, rep):
        """ Create MLLP Inbound Route form endpoint

        Parameters:
            _ (Request): Falcon HTTP request object
            rep (Response): Falcon HTTP response object
        """

        gateways = []
        for (aid,), destination in self.rt.dsts.getItemIter():
            d = dict(aid=aid, alias=destination.alias)
            gateways.append(d)

        identifiers = []
        for (aid,), identifier in self.rt.gators.getItemIter():
            d = dict(aid=aid, alias=identifier.alias)
            identifiers.append(d)

        routers = []
        for (name,), router in self.rt.routers.getItemIter():
            routers.append(dict(aid=router.aid, name=name))

        ip_addresses = list()
        ip_addresses.append("0.0.0.0")
        hostname = socket.gethostname()
        # Get all resolved addresses for the hostname
        for addr_info in socket.getaddrinfo(hostname, None):
            ip = addr_info[4][0]
            if ip not in ip_addresses:
                ip_addresses.append(ip)

        data = dict(
            gateways=gateways,
            routers=routers,
            identifiers=identifiers,
            ip_addresses=ip_addresses
        )

        template = J2_ENV.get_template('routes/mllp/inbound/create_mllp_inbound.j2')

        rep.status = falcon.HTTP_200
        rep.content_type = "text/html"
        rep.text = template.render(page_title=f'RACK Create MLLP Inbound Route - {self.hby.name}', **data)


class InboundRouteFormDeleteEnd:
    def __init__(self, hby, rt):
        self.hby = hby
        self.rt = rt

    def on_get(self, _, rep, name):
        """ MLLP Inbound Route delete form endpoint

        Parameters:
            _ (Request): Falcon HTTP request object
            rep (Response): Falcon HTTP response object
            name (str): name of MLLP inbound route

        """
        name = falcon.uri.decode(name)
        if (route := self.rt.inbMllps.get(keys=(name,))) is None:
            templating.error(rep, "routes/mllp/inbound/delete_mllp_inbound.j2", dict(), f"{name} is not a valid MLLP inbound route")
            return

        data = dict(
            name=name,
            route=route
        )

        template = J2_ENV.get_template('routes/mllp/inbound/delete_mllp_inbound.j2')

        rep.status = falcon.HTTP_200
        rep.content_type = "text/html"
        rep.text = template.render(page_title=f'RACK Delete MLLP Inbound Route - {self.hby.name}', **data)


class InboundRouteFormShutdownEnd:
    def __init__(self, hby, rt):
        self.hby = hby
        self.rt = rt

    def on_get(self, _, rep, name):
        """ MLLP Inbound Route shutdown form endpoint

        Parameters:
            _ (Request): Falcon HTTP request object
            rep (Response): Falcon HTTP response object
            name (str): name of MLLP inbound route

        """
        name = falcon.uri.decode(name)
        if (route := self.rt.inbMllps.get(keys=(name,))) is None:
            templating.error(rep, "routes/mllp/inbound/shutdown_mllp_inbound.j2", dict(), f"{name} is not a valid MLLP inbound route")
            return

        data = dict(
            name=name,
            route=route
        )

        template = J2_ENV.get_template('routes/mllp/inbound/shutdown_mllp_inbound.j2')

        rep.status = falcon.HTTP_200
        rep.content_type = "text/html"
        rep.text = template.render(page_title=f'RACK Shutdown MLLP Inbound Route - {self.hby.name}', **data)


class InboundRouteExportResourceEnd:
    def __init__(self, hby, rt):
        self.hby = hby
        self.rt = rt

    def on_get(self, _, rep, name):
        """ Export MLLP Inbound Route configuration

        Args:
            _ (Request): Falcon HTTP request object
            rep (Response): Falcon HTTP response object
            name (str): The name of the MLLP inbound route

        Returns:

        """
        name = falcon.uri.decode(name)
        if (route := self.rt.inbMllps.get(keys=(name,))) is None:
            templating.error(rep, "routes/mllp/inbound/view_mllp_inbound_route.j2", dict(), f"{name} is not a valid MLLP inbound route")
            return

        hab = self.hby.habs[route.localAID]

        ims = hab.replyToOobi(aid=hab.pre, role=kering.Roles.gateway)

        for _, delegate in self.rt.dlgs.getItemIter(keys=(hab.pre,)):
            for msg in hab.db.clonePreIter(pre=delegate, fn=0):
                ims.extend(msg)

        rep.status = falcon.HTTP_200
        rep.content_type = "application/cesr"
        rep.set_header("Content-Disposition", f"attachment; filename=\"{self.hby.name}-{name}-mllp.cesr\"")
        rep.data = ims