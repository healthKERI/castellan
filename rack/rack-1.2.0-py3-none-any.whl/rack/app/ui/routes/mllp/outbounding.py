# -*- encoding: utf-8 -*-
"""
rack.app.ui.routes.mllp.outbounding module

"""
import json
import math
import socket
from urllib.parse import urlparse

import falcon
from keri import kering
from keri.help import helping, ogler
from keri.kering import Schemes
from keri.vdr import credentialing

from rack.app.ui import templating
from rack.app.ui.templating import J2_ENV
from rack.core import scheming
from rack.core.basing import MllpOutboundRoute
from rack.core.scheming import Procs

logger = ogler.getLogger()


def loadEnds(app, router):
    outboundCollectionEndpoint = OutboundRouteCollectionEnd(hby=router.hby, rt=router.rt)
    app.add_route("/routes/mllp/outbound", outboundCollectionEndpoint)

    outboundFormCreateEnd = OutboundRouteFormCreateEnd(hby=router.hby, rt=router.rt)
    app.add_route("/routes/mllp/outbound/forms/create", outboundFormCreateEnd)

    outboundFormDeleteEnd = OutboundRouteFormDeleteEnd(hby=router.hby, rt=router.rt)
    app.add_route("/routes/mllp/outbound/{name}/forms/delete", outboundFormDeleteEnd)

    outboundFormShutdownEnd = OutboundRouteFormShutdownEnd(hby=router.hby, rt=router.rt)
    app.add_route("/routes/mllp/outbound/{name}/forms/shutdown", outboundFormShutdownEnd)

    outboundResourceEnd = OutboundRouteResourceEnd(router=router)
    app.add_route("/routes/mllp/outbound/{name}", outboundResourceEnd)

    outboundLaunchEnd = OutboundRouteLaunchEnd(router=router, hby=router.hby, rt=router.rt)
    app.add_route("/routes/mllp/outbound/{name}/launch", outboundLaunchEnd)

    outboundExpResourceEnd = OutboundRouteExportResourceEnd(hby=router.hby, rt=router.rt)
    app.add_route("/routes/mllp/outbound/{name}/export", outboundExpResourceEnd)


class OutboundRouteCollectionEnd:
    """ MLLP Outbound Route Collection Endpoint Class """

    def __init__(self, hby, rt):
        self.hby = hby
        self.rt = rt

    def on_get(self, req, rep):
        """ MLLP outbound route collection list endpoint

        Parameters:
            req (Request): Falcon HTTP request object
            rep (Response): Falcon HTTP response object
        """
        page = int(req.get_param("page", default=0))
        page_count = req.get_param("page_count", default=templating.PAGE_COUNT)

        start = page * page_count
        start = start + 1 if start > 0 else start

        count = 0
        routes = []
        for (name,), route in self.rt.otbMllps.getItemIter():
            count += 1
            if count < start:
                continue

            hab = self.hby.habs[route.localAID]
            gateway = None
            if route.gateway:
                dest = self.rt.dsts.get(keys=(route.gateway,))
                if dest:
                    gateway = dest.alias

            router = None
            if route.router:
                rtr = self.rt.routers.get(keys=(route.router,))
                if rtr:
                    router = route.router

            match route.route_type:
                case "cloud":
                    route_type = "Cloud Router"
                case "peer":
                    route_type = "Peer-to-Peer"
                case _:
                    route_type = "Unknown"

            r = dict(
                name=name,
                identifier=hab.name,
                route_type=route_type,
                gateway=gateway,
                router=router,
                mllpsrv=dict(
                    host=route.mllp_host,
                    port=route.mllp_port
                ) if route.mllp_host and route.mllp_port else None,
                tcp=dict(
                    host=route.tcp_host,
                    port=route.tcp_port
                ) if route.tcp_host and route.tcp_port else None,
                saids=route.saids
            )

            if route.lastPing is not None:
                r['ping'] = helping.fromIso8601(route.lastPing).astimezone().strftime("%Y-%m-%d %H:%M:%S")

            if len(routes) == page_count:
                continue

            routes.append(r)

        data = dict(
            page=page,
            num_pages=math.ceil(count / page_count),
            count=count,
            routes=routes
        )

        template = J2_ENV.get_template('routes/mllp/outbound/mllp_outbound_routes.j2')

        rep.status = falcon.HTTP_200
        rep.content_type = "text/html"
        rep.text = template.render(page_title=f'RACK Administration - {self.hby.name}', tab="mllp_outbound", **data)
    
    def on_post(self, req, rep):
        """ Create MLLP Outbound Route

        Parameters:
            req (Request): Falcon HTTP request object
            rep (Response): Falcon HTTP response object
        """
        data = req.media
        name = data.get("name", "")
        route_type = data.get("route_type", "peer")

        if not name:
            templating.error(rep, 'routes/mllp/outbound/create_mllp_outbound.j2', data,
                             msg="Name is required")
            return

        if self.rt.otbMllps.get(keys=(name,)) is not None:
            templating.error(rep, 'routes/mllp/outbound/create_mllp_outbound.j2', data,
                             msg="Name is already in use as an MLLP outbound route.")
            return

        aid = data.get("aid", None)
        if not aid:
            templating.error(rep, 'routes/mllp/outbound/create_mllp_outbound.j2', data,
                             msg="Local AID is required")
            return

        if aid not in self.hby.habs:
            templating.error(rep, 'routes/mllp/outbound/create_mllp_outbound.j2', data,
                             msg=f"{aid} is not a valid local source")
            return

        mllp_host = data.get("mllp_host", "127.0.0.1")
        mllp_port = int(data.get("mllp_port", 2575))
        tcp_aid = data.get("tcp_aid", None)
        tcp_host = data.get("tcp_host", "127.0.0.1")
        tcp_port = int(data.get("tcp_port", 8080))

        if not tcp_aid:
            templating.error(rep, 'routes/mllp/outbound/create_mllp_outbound.j2', data,
                             msg="TCP identifier is required")
            return

        if tcp_aid not in self.hby.habs:
            templating.error(rep, 'routes/mllp/outbound/create_mllp_outbound.j2', data,
                             msg=f"{tcp_aid} is not a valid TCP identifier")
            return

        match route_type:
            case "peer":
                gateway = data.get("gateway", None)
                router = None

            case "cloud":
                router = data.get("router", None)
                gateway = data.get("cloud_router", None)

            case _:
                gateway = None
                router = None

        if route_type == "peer":
            if not gateway:
                templating.error(rep, 'routes/mllp/outbound/create_mllp_outbound.j2', data,
                                 msg="Remote gateway is required for peer-to-peer routes")
                return
        elif route_type == "cloud":
            if not router:
                templating.error(rep, 'routes/mllp/outbound/create_mllp_outbound.j2', data,
                                 msg="Cloud router is required for cloud routes")
                return

        outb = MllpOutboundRoute(
            localAID=aid,
            route_type=route_type,
            scheme="mllp",
            mllp_host=mllp_host,
            mllp_port=mllp_port,
            tcp_aid=tcp_aid,
            tcp_host=tcp_host,
            tcp_port=tcp_port,
            gateway=gateway,
            router=router,
        )

        outb.anchoring = bool(data.get("anchoring", False))
        if outb.anchoring:
            outb.minimum = int(data.get("minimum", 0))
            outb.maximum = int(data.get("maximum", 1000))
            outb.frequency = int(data.get("frequency", 60))
            outb.interval = data.get("interval", "minutes")
            outb.interactions = int(data.get("interactions", 100))
            outb.rotations = int(data.get("rotations", 100))
        else:
            outb.minimum = 0
            outb.maximum = 0
            outb.frequency = 0
            outb.interval = None
            outb.interactions = 0
            outb.rotations = 0

        self.rt.otbMllps.pin(keys=(name,), val=outb)
        self.rt.updateAidCounts()
        self.rt.updateGtwCounts()

        hxLocation = json.dumps({
            "path": f"/routes/mllp/outbound",
            "target": "body"
        })
        rep.set_header('HX-Location', hxLocation)
        rep.status = falcon.HTTP_200
        rep.text = b'Ok'


class OutboundRouteResourceEnd:
    def __init__(self, router):
        """

        Parameters:
            router (Router): Top level route coordinator

        """
        self.hby = router.hby
        self.rt = router.rt
        self.router = router

    def on_get(self, req, rep, name):
        """ Get a display of an MLLP outbound route

        Args:
            req (Request): Falcon HTTP request object
            rep (Response): Falcon HTTP response object
            name (str): The name of the outbound route

        Returns:

        """
        name = falcon.uri.decode(name)
        if (route := self.rt.otbMllps.get(keys=(name,))) is None:
            templating.error(rep, "routes/mllp/outbound/edit_mllp_outbound.j2", dict(), f"{name} is not a valid MLLP outbound route")
            return

        gateways = []
        for (aid,), destination in self.rt.dsts.getItemIter():
            d = dict(aid=aid, alias=destination.alias)
            gateways.append(d)

        identifiers = []
        for (aid,), identifier in self.rt.gators.getItemIter():
            d = dict(aid=aid, alias=identifier.alias)
            identifiers.append(d)

        routers = []
        for (routerName,), router in self.rt.routers.getItemIter():
            routers.append(dict(aid=router.aid, name=routerName))

        ip_addresses = list()
        ip_addresses.append("0.0.0.0")
        hostname = socket.gethostname()

        for addr_info in socket.getaddrinfo(hostname, None):
            ip = addr_info[4][0]
            if ip not in ip_addresses:
                ip_addresses.append(ip)

        data = dict(
            name=name,
            route=route,
            gateways=gateways,
            routers=routers,
            identifiers=identifiers,
            ip_addresses=ip_addresses
        )

        template = J2_ENV.get_template("routes/mllp/outbound/edit_mllp_outbound.j2")

        rep.status = falcon.HTTP_200
        rep.content_type = "text/html"
        rep.text = template.render(page_title=f'RACK Edit MLLP Outbound Route - {self.hby.name}', **data)
    
    def on_post(self, req, rep, name):
        """ MLLP outbound route update endpoint

        Parameters:
            req (Request): Falcon HTTP request object
            rep (Response): Falcon HTTP response object
            name (str): The name of the MLLP outbound route
        """
        name = falcon.uri.decode(name)
        data = req.media
        route_type = data.get("route_type", "peer")

        if (route := self.rt.otbMllps.get(keys=(name,))) is None:
            templating.error(rep, 'routes/mllp/outbound/edit_mllp_outbound.j2',
                             {'name': name, 'route': None},
                             msg=f"{name} is not a valid MLLP outbound route.")
            return

        route.localAID = data.get("aid", None)
        if not route.localAID:
            templating.error(rep, 'routes/mllp/outbound/edit_mllp_outbound.j2',
                             {'name': name, 'route': route},
                             msg="Local AID is required")
            return

        if route.localAID not in self.hby.habs:
            templating.error(rep, 'routes/mllp/outbound/edit_mllp_outbound.j2',
                             {'name': name, 'route': route},
                             msg=f"{route.localAID} is not a valid local source")
            return

        route.mllp_host = data.get("mllp_host", "127.0.0.1")
        route.mllp_port = int(data.get("mllp_port", 2575))
        route.tcp_aid = data.get("tcp_aid", None)
        route.tcp_host = data.get("tcp_host", "127.0.0.1")
        route.tcp_port = int(data.get("tcp_port", 8080))

        if not route.tcp_aid:
            templating.error(rep, 'routes/mllp/outbound/edit_mllp_outbound.j2',
                             {'name': name, 'route': route},
                             msg="TCP identifier is required")
            return

        if route.tcp_aid not in self.hby.habs:
            templating.error(rep, 'routes/mllp/outbound/edit_mllp_outbound.j2',
                             {'name': name, 'route': route},
                             msg=f"{route.tcp_aid} is not a valid TCP identifier")
            return

        match route_type:
            case "peer":
                route.gateway = data.get("gateway", None)
                route.router = None

            case "cloud":
                route.router = data.get("router", None)
                route.gateway = data.get("cloud_gateway", None)

            case _:
                route.gateway = None
                route.router = None

        if route_type == "peer":
            if not route.gateway:
                templating.error(rep, 'routes/mllp/outbound/edit_mllp_outbound.j2',
                                 {'name': name, 'route': route},
                                 msg="Remote gateway is required for peer-to-peer routes")
                return
        elif route_type == "cloud":
            if not route.router:
                templating.error(rep, 'routes/mllp/outbound/edit_mllp_outbound.j2',
                                 {'name': name, 'route': route},
                                 msg="Cloud router is required for cloud routes")
                return

        route.route_type = route_type
        route.scheme = "mllp"

        route.anchoring = bool(data.get("anchoring", False))
        if route.anchoring:
            route.minimum = int(data.get("minimum", 0))
            route.maximum = int(data.get("maximum", 1000))
            route.frequency = int(data.get("frequency", 60))
            route.interval = data.get("interval", "minutes")
            route.interactions = int(data.get("interactions", 100))
            route.rotations = int(data.get("rotations", 100))
        else:
            route.minimum = 0
            route.maximum = 0
            route.frequency = 0
            route.interval = None
            route.interactions = 0
            route.rotations = 0

        self.rt.otbMllps.pin(keys=(name,), val=route)
        self.rt.updateAidCounts()
        self.rt.updateGtwCounts()

        hxLocation = json.dumps({
            "path": f"/routes/mllp/outbound",
            "target": "body"
        })
        rep.set_header('HX-Location', hxLocation)
        rep.status = falcon.HTTP_200
        rep.text = b'Ok'

    def on_delete(self, _, rep, name):
        """ MLLP outbound route delete endpoint

        Parameters:
            _ (Request): Falcon HTTP request object
            rep (Response): Falcon HTTP response object
            name (str): The name of the MLLP outbound route
        """
        name = falcon.uri.decode(name)
        route = self.rt.otbMllps.get(keys=(name,))

        if route is None:
            templating.error(rep, 'routes/mllp/outbound/edit_mllp_outbound.j2', dict(),
                             msg=f"Unable to delete MLLP outbound route {name}.")
            return

        if not self.rt.otbMllps.rem(keys=(name,)):
            templating.error(rep, 'routes/mllp/outbound/edit_mllp_outbound.j2', dict(),
                             msg=f"Unable to delete MLLP outbound route {name}.")
            return

        self.rt.updateAidCounts()
        self.rt.updateGtwCounts()

        rep.status = falcon.HTTP_200
        hxLocation = json.dumps({
            "path": f"/routes/mllp/outbound",
            "target": "body"
        })
        rep.set_header('HX-Location', hxLocation)
        rep.text = b'Ok'

    def on_put(self, _, rep, name):
        """ MLLP outbound route shutdown endpoint

        Parameters:
            _ (Request): Falcon HTTP request object
            rep (Response): Falcon HTTP response object
            name (str): The name of the MLLP outbound route
        """
        name = falcon.uri.decode(name)

        try:
            self.router.shutdownOutboundMllpRoute(name)
        except ValueError as e:
            logger.info(e)
            templating.error(rep, 'routes/mllp/outbound/shutdown_mllp_outbound.j2', dict(),
                             msg=f"Unable to shutdown MLLP outbound route {name}: {e}.")
            return

        rep.status = falcon.HTTP_200
        hxLocation = json.dumps({
            "path": f"/routes/mllp/outbound",
            "target": "body"
        })
        rep.set_header('HX-Location', hxLocation)
        rep.text = b'Ok'


class OutboundRouteLaunchEnd:
    def __init__(self, router, hby, rt):
        self.router = router
        self.hby = hby
        self.rt = rt

    def _create_fresh_connections(self):
        """Create fresh database connections for each operation"""
        rgy = credentialing.Regery(hby=self.hby, name=self.rt.name, temp=False)
        routery = scheming.Routery(name=self.rt.name, alias="rack", rt=self.rt, hby=self.hby, rgy=rgy)
        return rgy, routery

    def on_post(self, req, rep, name):
        """ MLLP outbound route launch endpoint

        Parameters:
            req (Request): Falcon HTTP request object
            rep (Response): Falcon HTTP response object
            name (str): The name of the MLLP outbound route
        """
        name = falcon.uri.decode(name)
        data = req.media
        if (outbound := self.rt.otbMllps.get(keys=(name,))) is None:
            templating.error(rep, 'routes/launch_error_outbound.j2', data,
                             msg=f"{name} is not a valid MLLP outbound route.")
            return

        if outbound.saids:
            templating.error(rep, 'routes/launch_error_outbound.j2', data,
                             msg=f"{name} is already running.")
            return

        essrParams = {"src": outbound.localAID, "dest": outbound.gateway}
        if outbound.anchoring:
            essrParams["minimum"] = outbound.minimum
            essrParams["maximum"] = outbound.maximum
            essrParams["frequency"] = outbound.frequency
            essrParams["interval"] = outbound.interval
            essrParams["interactions"] = outbound.interactions
            essrParams["rotations"] = outbound.rotations

        try:
            rgy, routery = self._create_fresh_connections()

            match outbound.route_type:
                case "peer":
                    self.generatePeerRoutes(name, outbound, routery)
                case "cloud":
                    self.generateCloudRoutes(name, outbound, essrParams, routery)
        except ValueError as e:
            templating.error(rep, 'routes/mllp/outbound/edit_mllp_outbound.j2', dict(),
                             msg=f"{e}")
            return

        hxLocation = json.dumps({
            "path": f"/routes/mllp/outbound",
            "target": "body"
        })
        rep.set_header('HX-Location', hxLocation)
        rep.status = falcon.HTTP_200
        rep.text = b'Ok'

    def generatePeerRoutes(self, name, outbound, routery):
        """ Generate routes for a Peer-to-Peer MLLP gateway connection

        Parameters:
            name (str): Name of the route group
            outbound (MllpOutboundRoute): The database definition of the MLLP outbound route to generate
            routery (Routery): Fresh routery instance for route creation

        """
        config = self._build_route_config(outbound)
        outbound.saids = list()

        if outbound.scheme == "mllp":
            routeType = "mllp_outbound"
            route = routery.makeRoute(name=name, route_type=routeType, config=config)
        else:
            logger.error(f"Unsupported scheme for MLLP route: {outbound.scheme}")
            raise ValueError(f"Unsupported scheme: {outbound.scheme}")

        self.router.addRoute(routery.routes[route.said])
        self.router.reload()
        outbound.saids.append(route.said)
        self.rt.otbMllps.pin(keys=(name,), val=outbound)
        logger.info(f"MLLP outbound route {name} launched: {outbound}")

    def generateCloudRoutes(self, name, outbound, essrParams, routery):
        """ Generate routes for a Cloud Router MLLP connection

        Parameters:
            name (str): Name of the route group
            outbound (MllpOutboundRoute): The database definition of the MLLP outbound route
            essrParams (dict): Parameters for anchoring and rotating
            routery (Routery): Fresh routery instance for route creation

        """
        config = self._build_cloud_route_config(outbound)
        outbound.saids = list()

        if outbound.scheme == "mllp":
            routeType = "mllp_outbound"
            route = routery.makeRoute(name=name, route_type=routeType, config=config)
        else:
            logger.error(f"Unsupported scheme for MLLP cloud route: {outbound.scheme}")
            raise ValueError(f"Unsupported scheme: {outbound.scheme}")

        self.router.addRoute(routery.routes[route.said])
        self.router.reload()
        outbound.saids.append(route.said)
        self.rt.otbMllps.pin(keys=(name,), val=outbound)
        logger.info(f"MLLP cloud outbound route {name} launched: {outbound}")

    def _build_route_config(self, outboundRoute):
        """Build MLLP route configuration from route data"""
        aid = outboundRoute.localAID
        gateway = outboundRoute.gateway
        mllp_host = outboundRoute.mllp_host or "127.0.0.1"
        mllp_port = outboundRoute.mllp_port or 2575
        tcp_aid = outboundRoute.tcp_aid
        tcp_host = outboundRoute.tcp_host or "127.0.0.1"
        tcp_port = outboundRoute.tcp_port or 8080

        if not gateway:
            raise ValueError("Gateway AID is required")

        if not tcp_aid:
            raise ValueError("TCP Agent Identifier is required")

        config = {
            "aid": aid,
            "mllpsrv": {
                "host": mllp_host,
                "port": mllp_port
            },
            "tcp": {
                "aid": tcp_aid,
                "host": tcp_host,
                "port": tcp_port
            }
        }

        if outboundRoute.anchoring:
            config["anchor"] = {
                "minimum": getattr(outboundRoute, "minimum", 0),
                "maximum": outboundRoute.maximum or 1000,
                "frequency": outboundRoute.frequency or 60,
                "interval": outboundRoute.interval or "minutes",
                "interactions": outboundRoute.interactions or 100,
                "rotations": outboundRoute.rotations or 100
            }

        return config

    def _build_cloud_route_config(self, outboundRoute):
        """Build MLLP cloud route configuration from route data"""
        aid = outboundRoute.localAID
        router = outboundRoute.router
        mllp_host = outboundRoute.mllp_host or "127.0.0.1"
        mllp_port = outboundRoute.mllp_port or 2575
        tcp_aid = outboundRoute.tcp_aid

        if not router:
            raise ValueError("Router AID is required for cloud routes")

        if not tcp_aid:
            raise ValueError("TCP Agent Identifier is required")

        rtr = self.rt.routers.get(keys=(router,))
        if not rtr:
            raise ValueError(f"Router {router} not found")

        config = {
            "aid": aid,
            "mllpsrv": {
                "host": mllp_host,
                "port": mllp_port
            },
            "tcp": {
                "aid": tcp_aid,
                "host": rtr.host,
                "port": rtr.port
            }
        }

        if outboundRoute.anchoring:
            config["anchor"] = {
                "minimum": getattr(outboundRoute, "minimum", 0),
                "maximum": outboundRoute.maximum or 1000,
                "frequency": outboundRoute.frequency or 60,
                "interval": outboundRoute.interval or "minutes",
                "interactions": outboundRoute.interactions or 100,
                "rotations": outboundRoute.rotations or 100
            }

        return config


class OutboundRouteFormCreateEnd:
    def __init__(self, hby, rt):
        self.hby = hby
        self.rt = rt

    def on_get(self, _, rep):
        """ Create MLLP Outbound Route form endpoint

        Parameters:
            _ (Request): Falcon HTTP request object
            rep (Response): Falcon HTTP response object
        """

        gateways = []
        for (aid,), destination in self.rt.dsts.getItemIter():
            d = dict(aid=aid, alias=destination.alias)
            gateways.append(d)

        identifiers = []
        for (aid,), identifier in self.rt.gators.getItemIter():
            d = dict(aid=aid, alias=identifier.alias)
            identifiers.append(d)

        routers = []
        for (name,), router in self.rt.routers.getItemIter():
            routers.append(dict(aid=router.aid, name=name))

        ip_addresses = list()
        ip_addresses.append("0.0.0.0")
        hostname = socket.gethostname()

        for addr_info in socket.getaddrinfo(hostname, None):
            ip = addr_info[4][0]
            if ip not in ip_addresses:
                ip_addresses.append(ip)

        data = dict(
            gateways=gateways,
            routers=routers,
            identifiers=identifiers,
            ip_addresses=ip_addresses
        )

        template = J2_ENV.get_template('routes/mllp/outbound/create_mllp_outbound.j2')

        rep.status = falcon.HTTP_200
        rep.content_type = "text/html"
        rep.text = template.render(page_title=f'RACK Create MLLP Outbound Route - {self.hby.name}', **data)


class OutboundRouteFormDeleteEnd:
    def __init__(self, hby, rt):
        self.hby = hby
        self.rt = rt

    def on_get(self, _, rep, name):
        """ MLLP Outbound Route delete form endpoint

        Parameters:
            _ (Request): Falcon HTTP request object
            rep (Response): Falcon HTTP response object
            name (str): name of MLLP outbound route

        """
        name = falcon.uri.decode(name)
        if (route := self.rt.otbMllps.get(keys=(name,))) is None:
            templating.error(rep, "routes/mllp/outbound/delete_mllp_outbound.j2", dict(), f"{name} is not a valid MLLP outbound route")
            return

        data = dict(
            name=name,
            route=route
        )

        template = J2_ENV.get_template('routes/mllp/outbound/delete_mllp_outbound.j2')

        rep.status = falcon.HTTP_200
        rep.content_type = "text/html"
        rep.text = template.render(page_title=f'RACK Delete MLLP Outbound Route - {self.hby.name}', **data)


class OutboundRouteFormShutdownEnd:
    def __init__(self, hby, rt):
        self.hby = hby
        self.rt = rt

    def on_get(self, _, rep, name):
        """ MLLP Outbound Route shutdown form endpoint

        Parameters:
            _ (Request): Falcon HTTP request object
            rep (Response): Falcon HTTP response object
            name (str): name of MLLP outbound route

        """
        name = falcon.uri.decode(name)
        if (route := self.rt.otbMllps.get(keys=(name,))) is None:
            templating.error(rep, "routes/mllp/outbound/shutdown_mllp_outbound.j2", dict(), f"{name} is not a valid MLLP outbound route")
            return

        data = dict(
            name=name,
            route=route
        )

        template = J2_ENV.get_template('routes/mllp/outbound/shutdown_mllp_outbound.j2')

        rep.status = falcon.HTTP_200
        rep.content_type = "text/html"
        rep.text = template.render(page_title=f'RACK Shutdown MLLP Outbound Route - {self.hby.name}', **data)


class OutboundRouteExportResourceEnd:
    def __init__(self, hby, rt):
        self.hby = hby
        self.rt = rt

    def on_get(self, _, rep, name):
        """ Export MLLP Outbound Route configuration

        Args:
            _ (Request): Falcon HTTP request object
            rep (Response): Falcon HTTP response object
            name (str): The name of the MLLP outbound route

        Returns:

        """
        name = falcon.uri.decode(name)
        if (route := self.rt.otbMllps.get(keys=(name,))) is None:
            templating.error(rep, "routes/mllp/outbound/view_mllp_outbound_route.j2", dict(), f"{name} is not a valid MLLP outbound route")
            return

        hab = self.hby.habs[route.localAID]

        ims = hab.replyToOobi(aid=hab.pre, role=kering.Roles.gateway)

        for _, delegate in self.rt.dlgs.getItemIter(keys=(hab.pre,)):
            for msg in hab.db.clonePreIter(pre=delegate, fn=0):
                ims.extend(msg)

        rep.status = falcon.HTTP_200
        rep.content_type = "application/cesr"
        rep.set_header("Content-Disposition", f"attachment; filename=\"{self.hby.name}-{name}-mllp.cesr\"")
        rep.data = ims