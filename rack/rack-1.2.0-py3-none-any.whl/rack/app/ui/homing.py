# -*- encoding: utf-8 -*-
"""
KERI
rack.app.ui.homing package

"""
import falcon

from .templating import J2_ENV


def loadEnds(app, router):
    homeEnd = HomeResourceEnd(router=router)
    app.add_route("/", homeEnd)


class HomeResourceEnd:

    def __init__(self, router):
        self.rt = router.rt
        self.hby = router.hby

    def on_get(self, _, rep):
        """ Account collection list endpoint

        Parameters:
            _ (Request): Falcon HTTP request object
            rep (Response): Falcon HTTP response object
        """
        template = J2_ENV.get_template('status/index.j2')

        count = active = retired = inbound = outbound = 0
        for (aid,), delegator in self.rt.gators.getItemIter():
            count += 1
            active += self.rt.dlgs.cnt(keys=(aid,))
            retired += self.rt.rtrd.cnt(keys=(aid,))
            inbound += self.rt.inbsAidIdx.cnt(keys=(aid,))
            outbound += self.rt.otbsAidIdx.cnt(keys=(aid,))

        gateway_count = gateway_inbound = gateway_outbound = 0
        for (aid,), gateway in self.rt.dsts.getItemIter(keys=()):
            gateway_count += 1
            gateway_inbound += self.rt.inbsGtwIdx.cnt(keys=(aid,))
            gateway_outbound += self.rt.otbsGtwIdx.cnt(keys=(aid,))

        http_inbound_count = http_in_running_count = http_in_cloud_count = 0
        for (_,), route in self.rt.inbs.getItemIter():
            http_inbound_count += 1
            if route.saids:
                http_in_running_count += 1
            if route.route_type == "cloud":
                http_in_cloud_count += 1

        http_outbound_count = http_out_running_count = http_out_cloud_count = 0
        for (_,), route in self.rt.otbs.getItemIter():
            http_outbound_count += 1
            if route.saids:
                http_out_running_count += 1
            if route.route_type == "cloud":
                http_out_cloud_count += 1

        sftp_inbound_count = sftp_in_running_count = sftp_in_cloud_count = 0
        for (_,), route in self.rt.inbSftps.getItemIter():
            sftp_inbound_count += 1
            if route.saids:
                sftp_in_running_count += 1
            if route.route_type == "cloud":
                sftp_in_cloud_count += 1

        sftp_outbound_count = sftp_out_running_count = sftp_out_cloud_count = 0
        for (_,), route in self.rt.otbSftps.getItemIter():
            sftp_outbound_count += 1
            if route.saids:
                sftp_out_running_count += 1
            if route.route_type == "cloud":
                sftp_out_cloud_count += 1

        mllp_inbound_count = mllp_in_running_count = mllp_in_cloud_count = 0
        for (_,), route in self.rt.inbMllps.getItemIter():
            mllp_inbound_count += 1
            if route.saids:
                mllp_in_running_count += 1
            if route.route_type == "cloud":
                mllp_in_cloud_count += 1

        mllp_outbound_count = mllp_out_running_count = mllp_out_cloud_count = 0
        for (_,), route in self.rt.otbMllps.getItemIter():
            mllp_outbound_count += 1
            if route.saids:
                mllp_out_running_count += 1
            if route.route_type == "cloud":
                mllp_out_cloud_count += 1

        load_balancer_count = load_balancer_running = 0
        for (_,), route in self.rt.loadBalancers.getItemIter():
            load_balancer_count += 1
            if route.saids:
                load_balancer_running += 1

        router_count = router_running = 0
        for (_,), route in self.rt.routers.getItemIter():
            router_count += 1
            if route.saids:
                router_running += 1

        total_inbound_count = http_inbound_count + sftp_inbound_count + mllp_inbound_count
        total_inbound_running = http_in_running_count + sftp_in_running_count + mllp_in_running_count
        total_inbound_cloud = http_in_cloud_count + sftp_in_cloud_count + mllp_in_cloud_count

        total_outbound_count = http_outbound_count + sftp_outbound_count + mllp_outbound_count
        total_outbound_running = http_out_running_count + sftp_out_running_count + mllp_out_running_count
        total_outbound_cloud = http_out_cloud_count + sftp_out_cloud_count + mllp_out_cloud_count

        data = dict(
            identifiers=dict(
                count=count,
                active=active,
                retired=retired,
                inbound=inbound,
                outbound=outbound,
            ),
            gateways=dict(
                count=gateway_count,
                inbound=gateway_inbound,
                outbound=gateway_outbound,
            ),
            inbound=dict(
                count=total_inbound_count,
                running=total_inbound_running,
                not_running=total_inbound_count - total_inbound_running,
                cloud=total_inbound_cloud,
            ),
            outbound=dict(
                count=total_outbound_count,
                running=total_outbound_running,
                not_running=total_outbound_count - total_outbound_running,
                cloud=total_outbound_cloud,
            ),
            http_inbound=dict(
                count=http_inbound_count,
                running=http_in_running_count,
                not_running=http_inbound_count - http_in_running_count,
                cloud=http_in_cloud_count,
            ),
            http_outbound=dict(
                count=http_outbound_count,
                running=http_out_running_count,
                not_running=http_outbound_count - http_out_running_count,
                cloud=http_out_cloud_count,
            ),
            sftp_inbound=dict(
                count=sftp_inbound_count,
                running=sftp_in_running_count,
                not_running=sftp_inbound_count - sftp_in_running_count,
                cloud=sftp_in_cloud_count,
            ),
            sftp_outbound=dict(
                count=sftp_outbound_count,
                running=sftp_out_running_count,
                not_running=sftp_outbound_count - sftp_out_running_count,
                cloud=sftp_out_cloud_count,
            ),
            mllp_inbound=dict(
                count=mllp_inbound_count,
                running=mllp_in_running_count,
                not_running=mllp_inbound_count - mllp_in_running_count,
                cloud=mllp_in_cloud_count,
            ),
            mllp_outbound=dict(
                count=mllp_outbound_count,
                running=mllp_out_running_count,
                not_running=mllp_outbound_count - mllp_out_running_count,
                cloud=mllp_out_cloud_count,
            ),
            load_balancers=dict(
                count=load_balancer_count,
                running=load_balancer_running,
                not_running=load_balancer_count - load_balancer_running,
            ),
            routers=dict(
                count=router_count,
                running=router_running,
                not_running=router_count - router_running,
            )
        )

        rep.status = falcon.HTTP_200
        rep.content_type = "text/html"
        rep.text = template.render(page_title=f'RACK Administration - {self.hby.name}', tab="status", **data)