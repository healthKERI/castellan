# -*- encoding: utf-8 -*-
"""
KERI
rack.app.ui.gatewaying package

"""
import json
import math

import falcon
from falcon.media.multipart import MultipartParseError
from keri.core import serdering, parsing
from keri.help import ogler

from rack.app.ui import templating
from rack.app.ui.templating import J2_ENV
from rack.core.basing import Gateway

logger = ogler.getLogger()

OOBI_REGEX = r'/oobi/([A-Za-z0-9_\-]+)(?:/[A-Za-z])?'


def loadEnds(app, router):
    gatewaysCollectionEnd = GatewaysCollectionEnd(hby=router.hby, rt=router.rt)
    app.add_route("/gateways", gatewaysCollectionEnd)

    gatewayResourceEnd = GatewayResourceEnd(hby=router.hby, rt=router.rt)
    app.add_route("/gateways/{aid}", gatewayResourceEnd)

    gatewayFormCreateEnd = GatewaysFormCreateEnd()
    app.add_route("/gateways/forms/create", gatewayFormCreateEnd)

    gatewayFormDeleteEnd = GatewaysFormDeleteEnd(hby=router.hby, rt=router.rt)
    app.add_route("/gateways/{aid}/forms/delete", gatewayFormDeleteEnd)


class GatewayResourceEnd:

    def __init__(self, hby, rt):
        self.hby = hby
        self.rt = rt

    def on_get(self, req, rep, aid):
        """ Delete gateway endpoint

        Parameters:
            req (Request): Falcon HTTP request object
            rep (Response): Falcon HTTP response object
            aid (str): qb64 aid of gateway to delete

        """
        gateway = self.rt.dsts.get(keys=(aid, ))
        if not gateway:
            raise falcon.HTTPNotFound(f"{aid} is not a valid gateway to delete")

        kever = self.hby.kevers[aid]

        data = dict(
            gateway=gateway,
            aid=aid,
            kever=kever
        )

        if req.get_param("readonly", default=None):
            template = J2_ENV.get_template("gateways/view_gateway.j2")
        else:
            template = J2_ENV.get_template("gateways/edit_gateway.j2")

        rep.status = falcon.HTTP_200
        rep.content_type = "text/html"
        rep.text = template.render(page_title=f'healthKERI Edit Remote Gateway - {self.hby.name}', **data)

    def on_delete(self, _, rep, aid):
        """ Delete gateway endpoint

        Parameters:
            _ (Request): Falcon HTTP request object
            rep (Response): Falcon HTTP response object
            aid (str): qb64 aid of gateway to delete

        """
        gateway = self.rt.dsts.get(keys=(aid, ))
        if not gateway:
            raise falcon.HTTPNotFound(f"{aid} is not a valid gateway to delete")

        # TODO: Check for usages of the remote gateway and error

        if not self.rt.dsts.rem(keys=(aid,)):
            raise falcon.HTTPBadRequest(f"unable to delete gateway {aid}")

        hxLocation = json.dumps({
            "path": f"/gateways",
            "target": "body"
        })
        rep.set_header('HX-Location', hxLocation)
        rep.status = falcon.HTTP_200
        rep.text = b'Ok'


class GatewaysCollectionEnd:

    def __init__(self, hby, rt):
        self.hby = hby
        self.rt = rt
        pass

    def on_get(self, req, rep):
        """ Account collection list endpoint

        Parameters:
            req (Request): Falcon HTTP request object
            rep (Response): Falcon HTTP response object
        """
        page = int(req.get_param("page", default=0))
        page_count = req.get_param("page_count", default=templating.PAGE_COUNT)

        start = page * page_count
        start = start + 1 if start > 0 else start

        count = 0
        gateways = []
        for (aid,), gateway in self.rt.dsts.getItemIter(keys=()):
            count += 1
            if count < start:
                continue
            kever = self.hby.kevers[aid]
            inbCnt = self.rt.inbsGtwIdx.cnt(keys=(aid,))
            otbCnt = self.rt.otbsGtwIdx.cnt(keys=(aid,))

            data = dict(
                alias=gateway.alias,
                kever=kever,
                resolved=gateway.resolved,
                inbCnt=inbCnt,
                otbCnt=otbCnt,
            )

            if len(gateways) == page_count:
                continue

            gateways.append(data)

        data = dict(
            gateways=gateways,
            page=page,
            num_pages=math.ceil(count / page_count),
            count=count,
        )

        template = J2_ENV.get_template('gateways/gateways.j2')

        rep.status = falcon.HTTP_200
        rep.content_type = "text/html"
        rep.text = template.render(page_title=f'RACK Administration - {self.hby.name}', tab="gateways", **data)

    def on_post(self, req, rep):
        """ Create Desitnation

        Parameters:
            req (Request): Falcon HTTP request object
            rep (Response): Falcon HTTP response object
        """
        logger.info(req.content_type)
        if not req.content_type.startswith("multipart/form-data"):
            raise falcon.HTTPUnsupportedMediaType(
                description=f"{req.content_type} not accepted, must be multipart/form-data"
            )

        form = req.get_media()

        alias = None
        ims = None
        try:
            for part in form:
                if part.name == "alias":
                    # We are expecting a CESR stream of an inception event
                    alias = part.stream.read().decode("utf-8")

                elif part.name == "oobi":
                    # We are expecting a CESR stream of a KEL event
                    ims = part.stream.read()

        except MultipartParseError:  # The form works but still raises this exception so ignore for now...
            pass

        if not alias:
            templating.error(rep, 'gateways/create_gateway.j2', {},
                             msg="Alias is required")

            return

        if not ims:
            templating.error(rep, 'gateways/create_gateway.j2', dict(alias=alias),
                             msg="OOBI is required")

            return
        serder = serdering.SerderKERI(raw=ims)
        parsing.Parser(kvy=self.hby.kvy, rvy=self.hby.rvy, local=False).parse(ims)
        self.hby.kvy.processEscrows()

        resolved = serder.pre in self.hby.kevers
        self.rt.dsts.pin(keys=(serder.pre,), val=Gateway(alias=alias, resolved=resolved))

        hxLocation = json.dumps({
            "path": f"/gateways",
            "target": "body"
        })
        rep.set_header('HX-Location', hxLocation)
        rep.status = falcon.HTTP_200
        rep.text = b'Ok'


class GatewaysFormCreateEnd:
    def __init__(self):
        pass

    @staticmethod
    def on_get(_, rep):
        """ Create Identifier form endpoint

        Parameters:
            _ (Request): Falcon HTTP request object
            rep (Response): Falcon HTTP response object
        """
        template = J2_ENV.get_template('gateways/create_gateway.j2')

        rep.status = falcon.HTTP_200
        rep.content_type = "text/html"
        rep.text = template.render(page_title='healthKERI Create Gateway')


class GatewaysFormDeleteEnd:
    def __init__(self, hby, rt):
        self.hby = hby
        self.rt = rt

    def on_get(self, _, rep, aid):
        """ Get Delete gateway confirmation form endpoint

        Parameters:
            _ (Request): Falcon HTTP request object
            rep (Response): Falcon HTTP response object
            aid (str): qb64 aid of gateway to delete

        """
        gateway = self.rt.dsts.get(keys=(aid, ))
        if not gateway:
            raise falcon.HTTPNotFound(f"{aid} is not a valid gateway to delete")

        logger.info(gateway)

        data = dict(aid=aid, gateway=gateway)
        template = J2_ENV.get_template('gateways/delete_gateway.j2')

        rep.status = falcon.HTTP_200
        rep.content_type = "text/html"
        rep.text = template.render(page_title='healthKERI Delete Gateway', **data)
