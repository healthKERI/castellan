# -*- encoding: utf-8 -*-
"""
KERI
rack.app.ui.homing package

"""
import json
import math

import falcon
from keri.help import ogler

from . import templating
from .templating import J2_ENV

logger = ogler.getLogger()


def loadEnds(app, router):
    accountCollectionEnd = AccountsCollectionEnd(hby=router.hby, rt=router.rt)
    app.add_route("/accounts", accountCollectionEnd)

    accountFormCreateEnd = AccountFormCreateEnd(hby=router.hby, rt=router.rt)
    app.add_route("/accounts/forms/create", accountFormCreateEnd)


class AccountsCollectionEnd:

    def __init__(self, hby, rt):
        self.hby = hby
        self.rt = rt

    def on_get(self, req, rep):
        """ Setting collection GET endpoint

        Parameters:
            req (Request): Falcon HTTP request object
            rep (Response): Falcon HTTP response object

        """

        """ Inbound route collection list endpoint

        Parameters:
            req (Request): Falcon HTTP request object
            rep (Response): Falcon HTTP response object
        """
        page = int(req.get_param("page", default=0))
        page_count = req.get_param("page_count", default=templating.PAGE_COUNT)

        start = page * page_count
        start = start + 1 if start > 0 else start

        count = 0
        accounts = []
        for (url,), acct in self.rt.accts.getItemIter():
            count += 1
            if count < start:
                continue

            hab = self.hby.habs[acct.aid]
            r = dict(
                url=url,
                name=hab.name,
                aid=hab.pre,
                username=acct.username
            )

            if len(accounts) == page_count:
                continue

            accounts.append(r)

        data = dict(
            page=page,
            num_pages=math.ceil(count / page_count),
            count=count,
            accounts=accounts
        )

        template = J2_ENV.get_template('settings/accounts.j2')

        rep.status = falcon.HTTP_200
        rep.content_type = "text/html"
        rep.text = template.render(page_title=f'RACK Administration - {self.hby.name}', tab="settings", **data)

    def on_post(self, req, rep):
        """ Create Desitnation

        Parameters:
            req (Request): Falcon HTTP request object
            rep (Response): Falcon HTTP response object
        """
        data = req.media

        url = data.get("url", None)
        if url is None:
            templating.error(rep, 'settings/create_account.j2', data,
                             msg="URL is required")

            return

        aid = data.get("account_aid", None)
        if aid is None:
            templating.error(rep, 'settings/create_account.j2', data,
                             msg="AID is required")

            return

        # TODO: Replace settings with something else.
        # self.rt.accts.pin(keys=(url,), val=CloudAccount(username=aid, aid=aid))

        hxLocation = json.dumps({
            "path": f"/accounts",
            "target": "body"
        })
        rep.set_header('HX-Location', hxLocation)
        rep.status = falcon.HTTP_200
        rep.text = b'Ok'


class AccountFormCreateEnd:
    def __init__(self, hby, rt):
        self.hby = hby
        self.rt = rt

    def on_get(self, _, rep):
        """ Create Identifier form endpoint

        Parameters:
            _ (Request): Falcon HTTP request object
            rep (Response): Falcon HTTP response object
        """

        delegators = []
        for (aid,), delegator in self.rt.gators.getItemIter():
            d = dict(aid=aid, alias=delegator.alias)
            delegators.append(d)

        data = dict(
            delegators=delegators
        )

        template = J2_ENV.get_template('settings/create_account.j2')

        rep.status = falcon.HTTP_200
        rep.content_type = "text/html"
        rep.text = template.render(page_title=f'healthKERI Create Account - {self.hby.name}', **data)
