# -*- encoding: utf-8 -*-
"""
KERI
rack.app.ui.admining package

"""
import os

import falcon
import jinja2
from hio.core.http import ServerDoer
from hio.core.http.serving import StaticSink
from keri.help import ogler
from keri.app import indirecting

from . import identifying, gatewaying, setting, routes
from ..ui import homing, templating, balancing, routering

logger = ogler.getLogger()


def setup_app(router):
    # Configure out ADMIN User Interface
    app = falcon.App(middleware=falcon.CORSMiddleware(
        allow_origins='*', allow_credentials='*',
        expose_headers=['cesr-attachment', 'cesr-date', 'content-type', 'signature', 'signature-input',
                        'signify-resource', 'signify-timestamp']))

    current_dir_path = os.path.dirname(os.path.abspath(__file__))
    swagsink = StaticSink(staticDirPath=f"{current_dir_path}/static")
    app.add_sink(swagsink, prefix="/static")

    # Configure templates
    templating.J2_ENV.loader = jinja2.PackageLoader("rack.app.ui", "templates")

    homing.loadEnds(app, router)
    setting.loadEnds(app, router)
    identifying.loadEnds(app, router)
    gatewaying.loadEnds(app, router)
    routes.http.inbounding.loadEnds(app, router)
    routes.http.outbounding.loadEnds(app, router)
    routes.sftp.inbounding.loadEnds(app, router)
    routes.sftp.outbounding.loadEnds(app, router)
    routes.mllp.inbounding.loadEnds(app, router)
    routes.mllp.outbounding.loadEnds(app, router)
    balancing.loadEnds(app, router)
    routering.loadEnds(app, router)


    return app


def setup(router, admin_host="127.0.0.1", admin_port=15632, keypath=None, certpath=None, cafilepath=None):

    app = setup_app(router=router)
    server = indirecting.createHttpServer(host=admin_host, port=admin_port, app=app, keypath=keypath,
                                          certpath=certpath, cafilepath=cafilepath)
    serverDoer = ServerDoer(server=server)

    return [serverDoer]
