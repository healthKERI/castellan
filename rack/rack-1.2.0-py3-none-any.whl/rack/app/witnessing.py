# -*- encoding: utf-8 -*-
"""
rack.app.witnessing module

"""
from pathlib import Path

import pyotp
from keri import help
from hio.base import doing
from hio.help import decking
from keri.app import delegating, agenting
from keri.core import serdering
from keri.help import helping

logger = help.ogler.getLogger()


def codes(hab):
    cdes = dict()

    try:
        with open(Path.home() / ".rack" / hab.pre, "r") as f:
            lines = f.readlines()
            for line in lines:
                splits = line.split(':')
                if len(splits) != 2:
                    continue
                (aid, code) = splits
                cdes[aid] = code.rstrip()
    except OSError:
        pass

    return cdes


class Eventer(doing.DoDoer):
    """ Message processor of Hab events to handle delegating and / or witness receipting """

    def __init__(self, hby, hab, msgs=None, **kwa):
        """ Create Eventer for processing event requests

        Args:
            hby (Habery):  identifier database environment
            msgs (Deck): message cue of requests to process event delegation and witnessing
            **kwa:
        """
        self.hby = hby
        self.hab = hab
        self.msgs = msgs if msgs is not None else decking.Deck()

        self.swain = delegating.Anchorer(hby=self.hby, proxy=self.hab)
        self.receiptor = agenting.Receiptor(hby=self.hby)

        super(Eventer, self).__init__(doers=[self.swain, self.receiptor], always=True, **kwa)

    def recur(self, tyme, deeds=None):
        """ Process messages of Hab events to handle delegating and / or witness receipting

        Parameters:
            tyme (float): relative cycle time of associated Tymist, obtained
            deeds (deque):  tuples of form (dog, retyme, doer).

        """
        if self.msgs:
            msg = self.msgs.pull()

            ked = msg['ked']
            serder = serdering.SerderKERI(sad=ked)
            pre = serder.pre
            hab = self.hby.habs[pre]

            c = codes(hab=hab)
            auths = dict()
            time = helping.nowIso8601()
            for wit, code in c.items():
                otp = pyotp.TOTP(s=c[wit])
                auths[wit] = f"{otp.at(helping.fromIso8601(time))}#{time}"

            if hab.kever.delpre and serder.estive:
                logger.info(f"Processing delegation approval for {hab.pre} from {hab.kever.delpre}")
                self.swain.delegation(pre=hab.pre, sn=hab.kever.sn, auths=auths)

            elif hab.kever.wits:
                logger.info(f"Processing witness receipts for {hab.pre}")
                cue = dict(pre=pre, sn=serder.sn, auths=auths)
                self.receiptor.msgs.append(cue)

        return super(Eventer, self).recur(tyme, deeds)