# -*- encoding: utf-8 -*-
"""
rack.app.routing module

"""
import os
from pathlib import Path

from hio.core.http import ServerDoer
from keri import help
from keri.app import habbing, indirecting
from keri.app.oobiing import Oobiery
from keri.vdr import credentialing
from prometheus_client import make_wsgi_app

from . import witnessing, delegating
from .racking import Router
from .watching import Watchmen, KeyStateVarianceAuthority
from ..core import basing, scheming

logger = help.ogler.getLogger()
WINGMAN_HAB_NAME = "wingman"


def setup(name, metricsHost="127.0.0.1", metricsPort=9001, base=None, bran=None):
    path = Path.home() / ".rack" / name
    if bran is None and os.path.exists(path):
        try:
            with open(path, "rt") as f:
                bran = f.read().rstrip("\n")
        except OSError:
            pass

    hby = habbing.Habery(name=name, base=base, bran=bran, temp=False)
    hbyDoer = habbing.HaberyDoer(habery=hby)

    hab = hby.habByName(WINGMAN_HAB_NAME)
    rt = basing.RouteTable(name=name, base=base, reopen=True, temp=False)
    eventer = witnessing.Eventer(hby=hby, hab=hab)
    rgy = credentialing.Regery(hby=hby, name=name, temp=False)
    routery = scheming.Routery(name=name, alias="wingman", rt=rt, hby=hby, rgy=rgy)
    router = Router(hby=hby, rt=rt, routery=routery, cues=eventer.msgs)

    # Start Prometheus metrics endpoint
    app = make_wsgi_app()
    server = indirecting.createHttpServer(host=metricsHost, port=metricsPort, app=app)
    srvrDoer = ServerDoer(server=server)

    # Configure our mailbox director to read any rotation or delegated inception events
    oobiery = Oobiery(hby)
    mbd = indirecting.MailboxDirector(hby=hby, witnesses=False,
                                      topics=["/delegate", "/challenge"])

    watchmen = Watchmen(hby=hby, hab=hab, tock=60.0)
    kva = KeyStateVarianceAuthority(hby=hby, cues=watchmen.cues)
    resolver = delegating.ResolveDoer(rt=rt, hby=hby)

    doers = [hbyDoer, router, eventer, srvrDoer, mbd, watchmen, kva, *oobiery.doers, resolver]

    return doers
