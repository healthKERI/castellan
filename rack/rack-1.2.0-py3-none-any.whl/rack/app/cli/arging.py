# -*- encoding: utf-8 -*-
"""
gator.app.cli.arging module

"""

from dataclasses import asdict

from keri.app.cli.common import config

from rack.app import delegating


def addInceptArguments(parser):
    parser.add_argument('--name', '-n', help='keystore name and file location of KERI keystore', required=True)
    parser.add_argument('--base', '-b', help='additional optional prefix to file location of KERI keystore',
                        required=False, default="")
    parser.add_argument('--alias', '-a', help='human readable alias for the new identifier prefix', required=True)
    parser.add_argument("--config-dir", "-c", dest="configDir", help="directory override for configuration data")
    parser.add_argument('--config-file',
                        dest="configFile",
                        action='store',
                        default=None,
                        help="configuration filename override")
    parser.add_argument("--proxy", help="alias for delegation communication proxy", default="")
    parser.add_argument('--temp', '-t', help='create a temporary keystore, used for testing', default=False)

    parser.add_argument('--file', '-f', help='Filename to use to create the identifier', default="", required=True)

    # Authentication for keystore
    parser.add_argument('--passcode', '-p', help='21 character encryption passcode for keystore (is not saved)',
                        dest="bran", default=None)  # passcode => bran
    parser.add_argument('--nopasscode', help='create an unencrypted keystore', action='store_true')
    parser.add_argument('--aeid', help='qualified base64 of non-transferable identifier prefix for  authentication '
                                       'and encryption of secrets in keystore', default=None)
    parser.add_argument('--salt', '-s', help='qualified base64 salt for creating key pairs', required=False)
    parser.add_argument('--seed', '-e', help='qualified base64 private-signing key (seed) for the aeid from which the '
                                             'private decryption key may be derived', default=None)

    parser.add_argument("--witness-count", "-w", dest="wcount", help="Number of witnesses to provision", default=5)
    parser.add_argument("--witopnet", "-wurl", help="Witopnet URL", default="http://localhost:5631/witnesses")
    parser.add_argument("--watopnet", help="Watopnet URL", default="http://localhost:7631/watchers")


def loadInceptOpts(args):
    required_args = ['transferable', 'wits', 'icount', 'isith', 'ncount', 'nsith', 'toad']
    if args.file is None or args.file == '':
        config.checkRequiredArgs(args, required_args)

    incept_opts = config.loadFileOptions(args.file, delegating.InceptOptions)
    return asdict(incept_opts)



