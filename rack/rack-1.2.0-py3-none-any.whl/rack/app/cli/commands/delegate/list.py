# -*- encoding: utf-8 -*-
"""
KERI
rack.app.cli.commands module

RACK Time-based One Time Password Utility
"""
import argparse

from hio import help
from hio.base import doing
from keri import kering
from keri.app import connecting
from keri.app.cli.common import existing

from rack.core import basing

logger = help.ogler.getLogger()

parser = argparse.ArgumentParser(description='List signing delegates for a delegator signing root.')
parser.set_defaults(handler=lambda args: handle(args),
                    transferable=True)
parser.add_argument('--name', '-n', help='keystore name and file location of KERI keystore', required=True)
parser.add_argument('--base', '-b', help='additional optional prefix to file location of KERI keystore',
                    required=False, default="")
parser.add_argument('--delegator', '-d', help='alias or aid of delegator', default=None,
                    required=True)
parser.add_argument('--passcode', '-p', help='21 character encryption passcode for keystore (is not saved)',
                    dest="bran", default=None)  # passcode => bran


def handle(args):
    kwa = dict(args=args)
    return [doing.doify(listDelegates, **kwa)]


def listDelegates(tymth, tock=0.0, **opts):
    """ Command line status handler

    """
    _ = (yield tock)

    args = opts["args"]
    name = args.name
    base = args.base
    bran = args.bran

    with existing.existingHby(name=name, base=base, bran=bran) as hby:
        org = connecting.Organizer(hby=hby)
        rt = basing.RouteTable(name=hby.name, reopen=True)

        delegator = None
        if args.delegator in hby.habs:
            delegator = args.delegator
        else:
            contacts = org.find("alias", args.delegator)
            for contact in contacts:
                if contact["alias"] == args.delegator:
                    delegator = contact['id']

        if not delegator:
            raise kering.ConfigurationError(f"unknown delegator AID or alias {args.delegator}")

        print(delegator)

        for tup, aid in rt.dlgs.getItemIter():
            print(tup, aid)


