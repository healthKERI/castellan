# -*- encoding: utf-8 -*-
"""
rack.app.cli.delegate.commands module

"""
import argparse

import requests
from hio import help
from hio.base import doing
from hio.core.tcp import Client as TcpClient, ClientDoer as TcpClientDoer
from keri.app import habbing, agenting, indirecting, forwarding
from keri.core import coring
from keri.db import dbing
from keri.vdr import credentialing

from rack.app import delegating
from rack.app.cli import arging
from rack.core.tcp import clienting

logger = help.ogler.getLogger()

parser = argparse.ArgumentParser(description='Initialize a series of delegate prefixes')
parser.set_defaults(handler=lambda args: handler(args))
arging.addInceptArguments(parser)
parser.add_argument("--delegate-count", "-d", dest="dcount", help="Number of signing delegates to provision",
                    default=12)
parser.add_argument('--delname', '-dn', default=None, required=False, action="store",
                    help='Delegator Name for delegated identfiers', )
parser.add_argument('--delpre', '-di', default=None, required=False, action="store",
                    help='Delegator AID for delegated identfiers', )
parser.add_argument('--deloobi', '-do', default=None, required=False, action="store",
                    help='Delegator OOBI for delegated identfiers', )


def handler(args):
    """
    Create Signing delegates with indexed aliases

    Args:
        args(Namespace): arguments object from command line
    """

    alias = args.alias
    proxy = args.proxy

    hby, rgy = delegating.init(args)
    kwa = arging.loadInceptOpts(args)
    kwa["delpre"] = args.delpre
    icpDoer = InceptDoer(hby=hby, rgy=rgy, alias=alias, delname=args.delname, deloobi=args.deloobi, proxy=proxy,
                         dcount=args.dcount, witopnet=args.witopnet, wcount=args.wcount, watopnet=args.watopnet, **kwa)

    doers = [icpDoer]
    return doers


class InceptDoer(doing.DoDoer):
    """ DoDoer for creating a new identifier prefix and Hab with an alias.
    """

    def __init__(self, hby, rgy, alias, delname, deloobi, dcount, witopnet, wcount, watopnet, proxy=None, **kwa):

        self.hby = hby
        self.rgy = rgy
        self.proxy = self.hby.habByName(proxy) if proxy is not None else None
        self.delname = delname
        self.deloobi = deloobi

        self.dcount = int(dcount)
        self.witopnet = witopnet
        self.wcount = int(wcount)
        self.watopnet = watopnet

        self.hbyDoer = habbing.HaberyDoer(habery=self.hby)  # setup doer
        self.witq = agenting.WitnessInquisitor(hby=self.hby)
        self.postman = forwarding.Poster(hby=self.hby)
        self.mbx = indirecting.MailboxDirector(hby=self.hby, topics=['/receipt', "/replay", "/reply"])
        self.receiptor = agenting.Receiptor(hby=self.hby)

        self.oobier = delegating.Oobier(hby=hby)

        self.client = TcpClient(host="127.0.0.1", port=13633, reconnectable=True)
        self.director = clienting.Director(hby=self.hby, client=self.client)
        self.reactor = clienting.Reactor(hby=self.hby, client=self.client)
        self.registrar = credentialing.Registrar(hby=self.hby, rgy=self.rgy, counselor=None)

        doers = [self.hbyDoer, self.oobier, self.postman, self.mbx, self.witq, self.receiptor,
                 TcpClientDoer(client=self.client), self.director, self.reactor, self.registrar]
        self.toRemove = list(doers)

        doers.append(doing.doify(self.inceptDo))
        self.inits = kwa
        self.alias = alias
        super(InceptDoer, self).__init__(doers=doers)

    def inceptDo(self, tymth, tock=0.0, **kwa):
        """
        Parameters:
            tymth (function): injected function wrapper closure returned by .tymen() of
                Tymist instance. Calling tymth() returns associated Tymist .tyme.
            tock (float): injected initial tock value

        Returns:  doifiable Doist compatible generator method
        """
        # enter context
        self.wind(tymth)
        self.tock = tock
        _ = (yield self.tock)

        delpre = self.inits["delpre"]

        yield from self.oobier.oobi(self.delname, self.deloobi)

        while delpre not in self.hby.kevers:
            yield self.tock

        rack = self.hby.makeHab(name="rack", transferable=True, icount=1, isith="1", ncount=1, nsith="1", toad=0)
        print(f"Created rack Hab ({rack.pre}")

        yield from delegating.makeRegistry(hab=rack, rgy=self.rgy, registrar=self.registrar, registryName="rack")
        print(f"Created rack Credential Registry")

        rep = requests.post(url=self.watopnet, json=dict(aid=rack.pre, oobi=""))
        watData = rep.json()
        print(watData)
        yield from self.oobier.oobi("watcher0", watData["oobis"][0])

        habs = list()
        for idx in range(self.dcount):
            hab = self.hby.makeHab(name=f"{self.alias}-{idx}", **self.inits)
            print(f"Created {hab.name} ({hab.pre}), sending to delegator")
            self.director.sendOwnEvent(hab)
            habs.append(hab)

        yield from self.waitForApproval(habs, delpre)

        for hab in habs:
            witnesser = delegating.Witnesser(self.hby, hab)
            self.extend([witnesser])

            wits = []
            for idx in range(self.wcount):
                rep = requests.post(url=self.witopnet, json=dict(aid=hab.pre))
                witData = rep.json()
                wits.append((idx, witData["eid"], witData["oobis"][0]))

            for (idx, eid, oobi) in wits:
                name = f"{hab.name}-witness{idx}"
                witnesser.msgs.append((name, eid, oobi))
                while name not in witnesser.wits:
                    yield self.tock

            hab.rotate(toad=self.wcount - 1, adds=list([wit.eid for wit in witnesser.wits.values()]))

            yield from self.receiptor.receipt(hab.pre, sn=hab.kever.sn, auths=witnesser.auths)

            self.director.sendOwnEvent(hab)
            self.remove([witnesser])

        yield from self.waitForApproval(habs, delpre)

        self.remove(self.toRemove)

        return True

    def waitForApproval(self, habs, delpre):
        for hab in habs:
            seal = dict(i=hab.pre, s=hab.kever.serder.snh, d=hab.kever.serder.said)
            while True:
                if dserder := self.hby.db.findAnchoringSealEvent(delpre, seal=seal):
                    seqner = coring.Seqner(sn=dserder.sn)
                    couple = seqner.qb64b + dserder.saidb
                    dgkey = dbing.dgKey(hab.kever.prefixer.qb64b, hab.kever.serder.saidb)
                    self.hby.db.setAes(dgkey, couple)  # authorizer event seal (delegator/issuer)

                    print(f"{hab.name} inception anchored successfully.")
                    break
                yield self.tock
