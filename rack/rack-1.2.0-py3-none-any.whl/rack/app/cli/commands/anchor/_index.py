import argparse


def create_parser() -> argparse.ArgumentParser:
    prsr = argparse.ArgumentParser(description='Commands for viewing merkle tree anchors in KELs')
    prsr.set_defaults(handler=lambda args: None)
    return prsr


parser = create_parser()
