# -*- encoding: utf-8 -*-
"""
KERI
rack.app.cli.commands module

RACK Time-based One Time Password Utility
"""
import argparse

from hio import help
from hio.base import doing
from keri import core
from keri.app.cli.common import existing, terming
from keri.core import coring
from kerkle.core import treeing

from rack.core import basing

logger = help.ogler.getLogger()

parser = argparse.ArgumentParser(description='List and verify anchors created against'
                                             ' the contents of their Merkle Tree.')
parser.set_defaults(handler=lambda args: handle(args),
                    transferable=True)
parser.add_argument('--name', '-n', help='keystore name and file location of KERI keystore', required=True)
parser.add_argument('--base', '-b', help='additional optional prefix to file location of KERI keystore',
                    required=False, default="")
parser.add_argument('--alias', '-a', help='human readable alias for the new identifier prefix', default=None,
                    required=True)
parser.add_argument('--passcode', '-p', help='21 character encryption passcode for keystore (is not saved)',
                    dest="bran", default=None)  # passcode => bran


def handle(args):
    kwa = dict(args=args)
    return [doing.doify(listAnchors, **kwa)]


def listAnchors(tymth, tock=0.0, **opts):
    """ Command line status handler

    """
    _ = (yield tock)

    args = opts["args"]
    name = args.name
    base = args.base
    alias = args.alias
    bran = args.bran

    with existing.existingHab(name=name, base=base, alias=alias, bran=bran) as (hby, hab):
        rt = basing.RouteTable(name=hby.name, reopen=True)

        print(f"Signer: {hab.name} ({hab.pre})")
        print(f"Current Seq No. {hab.kever.sn}")
        print("")
        print("Anchors:")

        for (pre, snh, said), (saider, root) in rt.ancs.getItemIter(keys=(hab.pre,)):
            count = rt.encs.cnt(keys=(said,))
            sner = core.Number(numh=snh)

            tree = treeing.SparseMerkleTree()

            for s in rt.encs.getIter(keys=(said,)):
                tree.update(coring.Saider(qb64=s))

            croot = core.Matter(raw=tree.root_as_bytes(), code=core.MtrDex.Blake3_256)

            print(f"\tMessages: {count}")
            print(f"\tSigning Event: {sner.sn - 1} ({said})")
            print(f"\tAnchoring Event: {sner.sn} ({saider.qb64})")

            if croot.qb64 == root.qb64:
                print(f"\tAnchored Merkle Root {root.qb64}: {terming.Colors.OKGREEN}{terming.Symbols.CHECKMARK} Verified{terming.Colors.ENDC}")
            else:
                print(f"\tAnchored Merkle Root {root.qb64}: {terming.Colors.FAIL}{terming.Symbols.FAILED} Invalid{terming.Colors.ENDC}")

            print()



