# -*- encoding: utf-8 -*-
"""
KERI
rack.app.cli.commands module

Create an ACDC data attestation that defines a RACK Route.
"""
import argparse

from hio import help
from hio.base import doing
from keri.app import habbing, grouping, connecting
from keri.app.cli.common import existing
from keri.vdr import credentialing

from rack.core import basing, scheming

logger = help.ogler.getLogger()

parser = argparse.ArgumentParser(description='Create a route.')
parser.set_defaults(handler=lambda args: handle(args),
                    transferable=True)
parser.add_argument('--name', '-n', help='Name of the database environment', required=True)
parser.add_argument('--base', '-b', help='additional optional prefix to file location of KERI keystore',
                    required=False, default="")
parser.add_argument('--alias', '-a', help='human readable alias for the new identifier prefix', required=True)
parser.add_argument('--passcode', '-p', help='21 character encryption passcode for keystore (is not saved)',
                    dest="bran", default=None)  # passcode => bran
parser.add_argument('--said', '-s', help='SAID of the credential of the route to delete', default=None, required=True)


def handle(args):
    deleter = RouteDeleter(name=args.name,
                           alias=args.alias,
                           base=args.base,
                           bran=args.bran,
                           said=args.said
                           )

    doers = [deleter]
    return doers


class RouteDeleter(doing.DoDoer):
    """
    Credential issuer DoDoer

    """

    def __init__(self, name, alias, base, bran, said):
        """ Doer that creates a route credential

        Args:
            name:
            alias:
            base:
            bran:
        """
        self.name = name
        self.alias = alias
        self.said = said

        self.hby = existing.setupHby(name=name, base=base, bran=bran)
        self.hab = self.hby.habByName(alias)
        if self.hab is None:
            raise ValueError(f"invalid alias {alias}")

        self.rt = basing.RouteTable(name=self.hby.name, reopen=True)
        self.rgy = credentialing.Regery(hby=self.hby, name=name, base=base)
        self.hbyDoer = habbing.HaberyDoer(habery=self.hby)  # setup doer
        self.counselor = grouping.Counselor(hby=self.hby)
        self.registrar = credentialing.Registrar(hby=self.hby, rgy=self.rgy, counselor=self.counselor)
        self.org = connecting.Organizer(hby=self.hby)

        doers = [self.hbyDoer, self.counselor, self.registrar]
        self.toRemove = list(doers)
        doers.extend([doing.doify(self.deleteDo)])

        super(RouteDeleter, self).__init__(doers=doers)

    def deleteDo(self, tymth, tock=0.0, **kwa):
        """  Issue Credential doer method


        Parameters:
             tymth (function): injected function wrapper closure returned by .tymen() of
                 Tymist instance. Calling tymth() returns associated Tymist .tyme.
             tock (float): injected initial tock value
        """
        self.wind(tymth)
        self.tock = tock
        _ = (yield self.tock)

        routery = scheming.Routery(name=self.hby.name, alias=self.alias, rt=self.rt, hby=self.hby, rgy=self.rgy)
        routery.deleteRoute(self.said)

        print(f"Route with SAID {self.said} has been deleted")
        self.remove(self.toRemove)
