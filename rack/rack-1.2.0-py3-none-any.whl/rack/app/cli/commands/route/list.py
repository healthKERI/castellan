# -*- encoding: utf-8 -*-
"""
KERI
rack.app.cli.commands module

Create an ACDC data attestation that defines a RACK Route.
"""
import argparse

from hio import help
from hio.base import doing
from keri.app import habbing, grouping, connecting
from keri.app.cli.common import existing

from rack.core import basing
from rack.core.scheming import Procs

logger = help.ogler.getLogger()

parser = argparse.ArgumentParser(description='Create a route.')
parser.set_defaults(handler=lambda args: handle(args),
                    transferable=True)
parser.add_argument('--name', '-n', help='Name of the database environment', required=True)
parser.add_argument('--base', '-b', help='additional optional prefix to file location of KERI keystore',
                    required=False, default="")
parser.add_argument('--alias', '-a', help='human readable alias for the new identifier prefix', required=True)
parser.add_argument('--passcode', '-p', help='21 character encryption passcode for keystore (is not saved)',
                    dest="bran", default=None)  # passcode => bran


PROC_NAMES = {
    Procs.tcpsrv: "TCP Server",
    Procs.tcp: "TCP Client",
    Procs.httpsrv: "HTTP Server",
    Procs.http: "HTTP Client",
    Procs.httpcall: "HTTP Internal Router",
    Procs.essr: "Encrypter/Signer",
    Procs.dessr: "Decrypter/Verifier",
}


def handle(args):
    lister = RouteLister(name=args.name,
                         alias=args.alias,
                         base=args.base,
                         bran=args.bran)

    doers = [lister]
    return doers


class RouteLister(doing.DoDoer):
    """
    Credential issuer DoDoer

    """

    def __init__(self, name, alias, base, bran):
        """ Doer that creates a route credential

        Args:
            name:
            alias:
            base:
            bran:

        """
        self.name = name
        self.alias = alias
        self.hby = existing.setupHby(name=name, base=base, bran=bran)
        self.hab = self.hby.habByName(alias)
        if self.hab is None:
            raise ValueError(f"invalid alias {alias}")

        self.rt = basing.RouteTable(name=self.hby.name, reopen=True)
        self.hbyDoer = habbing.HaberyDoer(habery=self.hby)  # setup doer
        self.counselor = grouping.Counselor(hby=self.hby)
        self.org = connecting.Organizer(hby=self.hby)

        doers = [self.hbyDoer, self.counselor]
        self.toRemove = list(doers)
        doers.extend([doing.doify(self.listDo)])

        super(RouteLister, self).__init__(doers=doers)

    def listDo(self, tymth, tock=0.0, **kwa):
        """  Issue Credential doer method


        Parameters:
             tymth (function): injected function wrapper closure returned by .tymen() of
                 Tymist instance. Calling tymth() returns associated Tymist .tyme.
             tock (float): injected initial tock value
        """
        self.wind(tymth)
        self.tock = tock
        _ = (yield self.tock)

        for (said,), rout in self.rt.rts.getItemIter():
            print(f"Route {said}:")
            print(f"   {PROC_NAMES[rout.inp]} -> ({rout.dest}) -> {PROC_NAMES[rout.out]}")
            print(f"\t{PROC_NAMES[rout.inp]} Configuration:")
            for key, val in rout.iparams.items():
                print(f"\t\t{key}: {val}")
            print(f"\t{PROC_NAMES[rout.out]} Configuration:")
            for key, val in rout.oparams.items():
                print(f"\t\t{key}: {val}")
            print()

        self.remove(self.toRemove)
