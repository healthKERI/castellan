# -*- encoding: utf-8 -*-
"""
KERI
rack.app.cli.commands module

Create an ACDC data attestation that defines a RACK Route.
"""
import argparse
import json

from hio import help
from hio.base import doing
from keri import kering
from keri.app import habbing, grouping, connecting
from keri.app.cli.common import existing
from keri.vdr import credentialing

from rack.core import basing, scheming

logger = help.ogler.getLogger()

parser = argparse.ArgumentParser(description='Create a route.')
parser.set_defaults(handler=lambda args: createRoute(args),
                    transferable=True)
parser.add_argument('--name', '-n', help='Name of the database environment', required=True)
parser.add_argument('--base', '-b', help='additional optional prefix to file location of KERI keystore',
                    required=False, default="")
parser.add_argument('--alias', '-a', help='human readable alias for the new identifier prefix', required=True)
parser.add_argument('--passcode', '-p', help='21 character encryption passcode for keystore (is not saved)',
                    dest="bran", default=None)  # passcode => bran
parser.add_argument('--group', '-g', help='Group name for this route relative to other routes', required=False,
                    default="")
parser.add_argument('--type', '-i', help='Route type used to determine the schema for the route credential', default=None, required=True)
parser.add_argument('--config', '-ip', help='Route configuration parameters  \'@\' allowed for file reference', default=None,
                    required=True)


def createRoute(args):

    try:
        if args.config.startswith("@"):
            f = open(args.config[1:], "r")
            config = json.load(f)
        else:
            config = json.loads(args.config)
    except json.JSONDecodeError:
        raise kering.ConfigurationError("edges supplied must be value JSON to issue in a credential")

    issueDoer = RouteCreator(name=args.name,
                             alias=args.alias,
                             base=args.base,
                             bran=args.bran,
                             group=args.group,
                             route_type=args.type,
                             config=config)

    doers = [issueDoer]
    return doers


class RouteCreator(doing.DoDoer):
    """
    Credential issuer DoDoer

    """

    def __init__(self, name, alias, base, bran, group, route_type, config):
        """
        Initializes a `RouteCreator` instance to manage the creation and configuration
        of routes for a given habitat. It sets up various components such as habitats,
        credential registries, and route organizers. The initialization process validates
        the provided input parameters and establishes the necessary dependencies for
        further operations.

        Args:
            name: Unique identifier for the routing instance.
            alias: Alias used for identifying the habitat.
            base: Path or base location for data storage.
            bran: Secret material or passcode for initialization.
            group: Group or category associated with this routing instance.
            route_type: Type of route to be created or managed.
            config: Configuration details for setting up the route.
        """
        self.name = name
        self.alias = alias
        self.group = group
        self.route_type = route_type
        self.config = config

        self.hby = existing.setupHby(name=name, base=base, bran=bran)
        self.hab = self.hby.habByName(alias)
        if self.hab is None:
            raise ValueError(f"invalid alias {alias}")

        self.rt = basing.RouteTable(name=self.hby.name, reopen=True)
        self.rgy = credentialing.Regery(hby=self.hby, name=name, base=base)
        self.hbyDoer = habbing.HaberyDoer(habery=self.hby)  # setup doer
        self.counselor = grouping.Counselor(hby=self.hby)
        self.registrar = credentialing.Registrar(hby=self.hby, rgy=self.rgy, counselor=self.counselor)
        self.org = connecting.Organizer(hby=self.hby)

        doers = [self.hbyDoer, self.counselor, self.registrar]
        self.toRemove = list(doers)
        doers.extend([doing.doify(self.createDo)])

        super(RouteCreator, self).__init__(doers=doers)

    def createDo(self, tymth, tock=0.0, **kwa):
        """  Issue Credential doer method


        Parameters:
             tymth (function): injected function wrapper closure returned by .tymen() of
                 Tymist instance. Calling tymth() returns associated Tymist .tyme.
             tock (float): injected initial tock value
        """
        self.wind(tymth)
        self.tock = tock
        _ = (yield self.tock)

        routery = scheming.Routery(name=self.hby.name, alias=self.alias, rt=self.rt, hby=self.hby, rgy=self.rgy)
        route = routery.makeRoute(name=self.group, route_type=self.route_type, config=self.config)
        print(route.said)
        self.remove(self.toRemove)
