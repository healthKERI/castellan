# -*- encoding: utf-8 -*-
"""
KERI
hkapi.app.cli.commands module

Routing, Authentication and Confidentiality with KERI Server
"""

import argparse

from keri import __version__

from rack.core import installing

parser = argparse.ArgumentParser(description="Install HKAPI Instance")
parser.set_defaults(handler=lambda args: launch(args))
parser.add_argument('--name', '-n', help='HKWEB Database name', required=True)
parser.add_argument('-V', '--version',
                    action='version',
                    version=__version__,
                    help="Prints out version of script runner.")
parser.add_argument('--base', '-b', help='additional optional prefix to file location of RACK database',
                    required=False, default="")
parser.add_argument('--passcode', '-p', help='21 character encryption passcode for keystore (is not saved)',
                    dest="bran", default=None)
parser.add_argument('--salt', '-s', help='qualified base64 salt for creating key pairs', required=False,
                    default=None)
parser.add_argument('-H', '--essr-host',
                    dest="host",
                    action='store',
                    default="127.0.0.1",
                    help="Local host IP address ESSR server listens on. Default is 127.0.0.1.")
parser.add_argument('-P', '--essr-port',
                    dest="port",
                    action='store',
                    default=8990,
                    help="Local port number the ESSR server listens on. Default is 5632.")
parser.add_argument('-T', '--target-host',
                    action='store',
                    default="127.0.0.1",
                    help="IP address HTTP server is listening on. Default is 127.0.0.1.")
parser.add_argument('-Z', '--target-port',
                    action='store',
                    default=8000,
                    help="Local port number the HTTP server is listening on. Default is 5632.")


def launch(args):
    installer = installing.WingmanInstaller(name=args.name,
                                            base=args.base,
                                            bran=args.bran,
                                            salt=args.salt,
                                            host=args.host,
                                            port=int(args.port),
                                            thost=args.target_host,
                                            tport=int(args.target_port),
                                            )
    return [installer]
