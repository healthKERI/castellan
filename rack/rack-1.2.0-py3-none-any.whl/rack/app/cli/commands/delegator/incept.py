# -*- encoding: utf-8 -*-
"""
rack.app.cli.delegator.commands module

"""
import argparse

import requests
from hio import help
from hio.base import doing
from keri.app import habbing, agenting, indirecting, forwarding

from rack.app import delegating
from rack.app.cli import arging

logger = help.ogler.getLogger()

parser = argparse.ArgumentParser(description='Initialize a delegator prefix')
parser.set_defaults(handler=lambda args: handler(args))
arging.addInceptArguments(parser)


def handler(args):
    """
    Create KERI identifier prefix in specified key store with alias

    Args:
        args(Namespace): arguments object from command line
    """

    alias = args.alias

    hby, _ = delegating.init(args)
    kwa = arging.loadInceptOpts(args)
    icpDoer = InceptDoer(hby=hby, alias=alias, witopnet=args.witopnet, wcount=args.wcount, **kwa)
    doers = [icpDoer]
    return doers


class InceptDoer(doing.DoDoer):
    """ DoDoer for creating a new identifier prefix and Hab with an alias.
    """

    def __init__(self, hby, alias, witopnet, wcount, proxy=None, **kwa):

        self.hby = hby
        self.proxy = self.hby.habByName(proxy) if proxy is not None else None

        self.witopnet = witopnet
        self.wcount = wcount

        self.hbyDoer = habbing.HaberyDoer(habery=self.hby)  # setup doer
        self.witq = agenting.WitnessInquisitor(hby=self.hby)
        self.postman = forwarding.Poster(hby=self.hby)
        self.mbx = indirecting.MailboxDirector(hby=self.hby, topics=['/receipt', "/replay", "/reply"])
        doers = [self.hbyDoer, self.postman, self.mbx, self.witq, doing.doify(self.inceptDo)]

        self.inits = kwa
        self.alias = alias
        super(InceptDoer, self).__init__(doers=doers)

    def inceptDo(self, tymth, tock=0.0, **kwa):
        """
        Parameters:
            tymth (function): injected function wrapper closure returned by .tymen() of
                Tymist instance. Calling tymth() returns associated Tymist .tyme.
            tock (float): injected initial tock value

        Returns:  doifiable Doist compatible generator method
        """
        # enter context
        self.wind(tymth)
        self.tock = tock
        _ = (yield self.tock)

        rack = self.hby.makeHab(name="rack", transferable=True, icount=1, isith="1", ncount=1, nsith="1", toad=0)
        print(f"Created rack Hab ({rack.pre}")

        hab = self.hby.makeHab(name=self.alias, **self.inits)

        witnesser = delegating.Witnesser(self.hby, hab)
        self.extend([witnesser])

        wits = []
        for idx in range(self.wcount):
            rep = requests.post(url=self.witopnet, json=dict(aid=hab.pre))
            witData = rep.json()
            wits.append((idx, witData["eid"], witData["oobis"][0]))

        for (idx, eid, oobi) in wits:
            name = f"witness{idx}"
            witnesser.msgs.append((name, eid, oobi))
            while name not in witnesser.wits:
                yield self.tock

        hab.rotate(toad=self.wcount - 1, adds=list([wit.eid for wit in witnesser.wits.values()]))

        receiptor = agenting.Receiptor(hby=self.hby)
        self.extend([receiptor])

        yield from receiptor.receipt(hab.pre, sn=hab.kever.sn, auths=witnesser.auths)

        toRemove = [self.hbyDoer, self.mbx, self.witq, self.postman, witnesser, receiptor]
        self.remove(toRemove)

        return
