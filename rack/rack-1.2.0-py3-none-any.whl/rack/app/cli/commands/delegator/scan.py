# -*- encoding: utf-8 -*-
"""
KERI
rack.app.cli.commands module

Assign the delegate AID as the current signing AID for delegator.

"""
import argparse

from hio import help
from keri import kering
from keri.app import connecting
from keri.app.cli.common import existing

from rack.app import delegating
from rack.core import basing

logger = help.ogler.getLogger()

parser = argparse.ArgumentParser(description='Assign a delegate for a local source.')
parser.set_defaults(handler=lambda args: scan(args),
                    transferable=True)
parser.add_argument('--name', '-n', help='Name of the database environment', required=True)
parser.add_argument('--base', '-b', help='additional optional prefix to file location of KERI keystore',
                    required=False, default="")
parser.add_argument('--passcode', '-p', help='21 character encryption passcode for keystore (is not saved)',
                    dest="bran", default=None)  # passcode => bran
parser.add_argument('--delegator', '-s', help='alias or qb64 identifier prefix of the delegator', required=True)


def scan(args):
    name = args.name
    base = args.base
    bran = args.bran

    with existing.existingHby(name=name, base=base, bran=bran) as hby:
        rt = basing.RouteTable(name=hby.name, base=hby.base, temp=hby.temp)
        org = connecting.Organizer(hby=hby)

        delegator = None
        if args.delegator in hby.habs:
            delegator = args.delegator
        elif (hab := hby.habByName(args.delegator)) is not None:
            delegator = hab.pre
        else:
            contacts = org.find("alias", args.delegator)
            for contact in contacts:
                if contact["alias"] == args.delegator:
                    delegator = contact['id']

        if not delegator:
            raise kering.ConfigurationError(f"unknown delegator AID or alias {args.delegator}")

        delegating.scanForDelegates(hby, rt, delegator)
