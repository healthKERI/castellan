# -*- encoding: utf-8 -*-
"""
KERI
rack.app.cli.commands module

RACK Time-based One Time Password Utility
"""
import argparse

import pyotp
from hio import help

logger = help.ogler.getLogger()

parser = argparse.ArgumentParser(description='Return the current code for a one-time password URL or secret')
parser.set_defaults(handler=lambda args: getCode(args),
                    transferable=True)
parser.add_argument('--name', '-n', help='name to assign to the totp', required=False, default=None)
parser.add_argument('--url', '-u', help='timebased one-time password URL', required=False, default=None)
parser.add_argument('--secret', '-s', help='timebased one-time password secret', required=False, default="")
parser.add_argument('--issuer', '-i', help='issuer of the totp', required=False, default="")


def getCode(args):

    if args.url:
        otp = pyotp.parse_uri(args.url)
    elif args.secret:
        otp = pyotp.TOTP(s=args.secret, name=args.name, issuer=args.issuer)
    else:
        print("Either --url or --secret is required.")
        return

    print(otp.now())

