# -*- encoding: utf-8 -*-
"""
KERI
rack.app.cli.commands.passcode module

RACK Time-based One Time Password Utility
"""
import argparse
import os
import stat
from pathlib import Path

from hio import help
from hio.base import doing
from keri.app.cli.common import existing
from keri.kering import ConfigurationError

logger = help.ogler.getLogger()

parser = argparse.ArgumentParser(description='Save passcode in .rack directory for a database')
parser.set_defaults(handler=lambda args: handle(args),
                    transferable=True)
parser.add_argument('--name', '-n', help='keystore name and file location of KERI keystore', required=True)
parser.add_argument('--base', '-b', help='additional optional prefix to file location of KERI keystore',
                    required=False, default="")
parser.add_argument('--passcode', '-p', help='21 character encryption passcode for keystore (is not saved)',
                    dest="bran", required=True)  # passcode => bran


def handle(args):
    kwa = dict(args=args)
    return [doing.doify(save, **kwa)]


def save(tymth, tock=0.0, **opts):
    """ Command line status handler

    """
    _ = (yield tock)
    args = opts["args"]
    name = args.name
    base = args.base
    bran = args.bran

    try:
        with existing.existingHby(name=name, base=base, bran=bran) as hby:
            mkdir(Path.home() / ".rack")

            try:
                path = Path.home() / ".rack" / name
                with open(path, "w") as f:
                    print(f"{bran}", file=f)

                os.chmod(path, stat.S_IRUSR | stat.S_IWUSR)
            except OSError:
                pass
    except ConfigurationError as e:
        print(f"invalid passcode for {name}.", )
        return -1


def mkdir(dir_path):
    # Check if the directory exists
    if not os.path.exists(dir_path):
        # Create the directory
        os.makedirs(dir_path)
        print(f"Directory '{dir_path}' created.")

        # Set permissions to read/write for owner only (0o700 for directory)
        os.chmod(dir_path, stat.S_IRUSR | stat.S_IWUSR | stat.S_IXUSR)
        print(f"Permissions set to read/write/execute for owner only for '{dir_path}'.")
