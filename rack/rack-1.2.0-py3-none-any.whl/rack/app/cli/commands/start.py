# -*- encoding: utf-8 -*-
"""
KERI
rack.app.cli.commands module

Routing, Authentication and Confidentiality with KERI Server
"""
import argparse
import logging

from hio.base import doing
from keri.app import configing

from rack.app import racking
from keri import __version__
from keri import help

parser = argparse.ArgumentParser(description="RACK Server Command")
parser.set_defaults(handler=lambda args: launch(args))
parser.add_argument('--name', '-n', help='keystore name and file location of KERI keystore', required=True)
parser.add_argument('-V', '--version',
                    action='version',
                    version=__version__,
                    help="Prints out version of script runner.")
parser.add_argument('--base', '-b', help='additional optional prefix to file location of KERI keystore',
                    required=False, default="")
parser.add_argument('--passcode', '-p', help='21 character encryption passcode for keystore (is not saved)',
                    dest="bran", default=None)
parser.add_argument("--config-dir", "-c", dest="configDir", help="directory override for configuration data")
parser.add_argument('--config-file',
                    dest="configFile",
                    action='store',
                    default=None,
                    help="configuration filename override")
parser.add_argument('--metrics-port', '-mp', dest="metricsport",
                    action='store',
                    default=9001,
                    help="Local port number the Metrics server listens on. Default is 9001.")
parser.add_argument('--metrics-host', '-mh', dest="metricshost",
                    action='store',
                    default="127.0.0.1",
                    help="Local host IP address Metrics server listens on. Default is 127.0.0.1.")
parser.add_argument("--loglevel", action="store", required=False, default="INFO",
                    help="Set log level to DEBUG | INFO | WARNING | ERROR | CRITICAL. Default is INFO")
parser.add_argument("--logfile", action="store", required=False, default=None,
                    help="path of the log file. If not defined, logs will not be written to the file.")
parser.add_argument('--admin-port',
                    dest="port",
                    action='store',
                    default=15632,
                    help="Local port number the HTTP server listens on. Default is 5632.")
parser.add_argument('-H', '--admin-host',
                    dest="host",
                    action='store',
                    default="127.0.0.1",
                    help="Local host IP address HTTP server listens on. Default is 127.0.0.1.")



def launch(args):
    FORMAT = f'%(asctime)s [rack-{args.name}] %(levelname)-8s %(message)s'
    help.ogler.level = logging.getLevelName(args.loglevel)
    baseFormatter = logging.Formatter(FORMAT)  # basic format
    baseFormatter.default_msec_format = None
    help.ogler.baseConsoleHandler.setFormatter(baseFormatter)
    help.ogler.level = logging.getLevelName(args.loglevel)

    if args.logfile is not None:
        help.ogler.headDirPath = args.logfile
        help.ogler.reopen(name="RACK", temp=False, clear=True)

    logger = help.ogler.getLogger()

    logger.info("******* Starting Routing as a Service. ******")

    runService(args)

    logger.info("******* Ended Routing as a Service:. ******")


def runService(args, expire=0.0):
    """
    Setup and run one witness
    """
    configFile = args.configFile
    configDir = args.configDir

    cf = None
    if configFile is not None:
        cf = configing.Configer(name=configFile,
                                base="",
                                headDirPath=configDir,
                                temp=False,
                                reopen=True,
                                clear=False)


    doers = racking.setup(name=args.name, metricsHost=args.metricshost, cf=cf,
                          metricsPort=int(args.metricsport), base=args.base, bran=args.bran)

    tock = 0.00125
    doist = doing.Doist(limit=expire, tock=tock, real=True)
    doist.do(doers=doers)
