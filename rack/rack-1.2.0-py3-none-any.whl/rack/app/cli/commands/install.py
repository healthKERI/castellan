# -*- encoding: utf-8 -*-
"""
KERI
rack.app.cli.commands module

Routing, Authentication and Confidentiality with KERI Server
"""

import argparse

from keri import __version__
from keri.core import coring

from rack.core import installing

parser = argparse.ArgumentParser(description="Install RACK Gateway")
parser.set_defaults(handler=lambda args: launch(args))
parser.add_argument('--name', '-n', help='RACK Database name', required=True)
parser.add_argument('-V', '--version',
                    action='version',
                    version=__version__,
                    help="Prints out version of script runner.")
parser.add_argument('--base', '-b', help='additional optional prefix to file location of RACK database',
                    required=False, default="")
parser.add_argument('--salt', '-s', help='qualified base64 salt for creating key pairs', required=False,
                    default=None)
parser.add_argument('--passcode', '-p', help='21 character encryption passcode for keystore (is not saved)',
                    dest="bran", default=None)
parser.add_argument('--passid-file', '-i',
                    help="path to a CESR file containing the KEL of the passid to use for the admin account",
                    default=None)
parser.add_argument('--insecure', help="Used this flag for testing only.  Sets the RACK Core identifier and PassID to"
                                       "well known values for ease of testing.  DO NOT USE IN PRODUCTION",
                    action="store_true", default=False)
parser.add_argument('--ui', help="Use this flag to indicate that the UI should be installed.  This is not required for"
                                 "running the gateway in production.  It is required for running the gateway in "
                                 "development mode.  The UI is a web application that allows the user to manage "
                                 "the gateway.  It is not required for the gateway to run in production.  It is "
                                 "required for development mode.  The UI is a web application that allows the user "
                                 "to manage the gateway.  It is not required for the gateway to run in production.  It "
                                 "is required for development mode.",
                    action="store_true", default=False)
parser.add_argument('-H', '--admin-host', required=False,
                    dest="host",
                    action='store',
                    default="127.0.0.1",
                    help="Local host IP address HTTP server listens on. Default is 127.0.0.1.")
parser.add_argument('--admin-port', required=False,
                    dest="port",
                    action='store',
                    default=15632,
                    help="Local port number the HTTP server listens on. Default is 15632.")

DEFAULT_CORE_SALT = "DMUz2cSecTCKylVfV89op"


def launch(args):

    salt = args.salt

    if args.insecure:
        if not salt:
            salt = DEFAULT_CORE_SALT

    else:
        if not args.salt:
            salt = coring.randomNonce()[2:23]

        if not args.passid_file:
            print("You must specify a PassID file with --passid-file option or specify --insecure for testing mode")
            return


    if args.ui:
        installer = installing.AdminUIInstaller(name=args.name,
                                                 base=args.base,
                                                 salt=salt.encode('utf-8'),
                                                 bran=args.bran,
                                                 file=args.passid_file,
                                                 host=args.host,
                                                 port=int(args.port))

    else:
        installer = installing.Installer(name=args.name,
                                                base=args.base,
                                                salt=salt.encode('utf-8'),
                                                bran=args.bran)
    return [installer]
