# -*- encoding: utf-8 -*-
"""
KERI
rack.app.cli.commands module

RACK Time-based One Time Password Utility
"""
import argparse
import os
import stat
from pathlib import Path

import pyotp
from hio import help
from hio.base import doing
from keri.app import connecting
from keri.app.cli.common import existing
from keri.kering import ConfigurationError

logger = help.ogler.getLogger()

parser = argparse.ArgumentParser(description='Save current code for a one-time password URL or secret')
parser.set_defaults(handler=lambda args: handle(args),
                    transferable=True)
parser.add_argument('--name', '-n', help='keystore name and file location of KERI keystore', required=True)
parser.add_argument('--base', '-b', help='additional optional prefix to file location of KERI keystore',
                    required=False, default="")
parser.add_argument('--alias', '-a', help='human readable alias for the new identifier prefix', default=None,
                    required=True)
parser.add_argument('--passcode', '-p', help='21 character encryption passcode for keystore (is not saved)',
                    dest="bran", default=None)  # passcode => bran
parser.add_argument('--witness', '-w', help='alias or qb64 AID of witness to associate this auth with', required=False,
                    default=None)
parser.add_argument('--url', '-u', help='timebased one-time password URL', required=False, default=None)
parser.add_argument('--secret', '-s', help='timebased one-time password secret', required=False, default="")
parser.add_argument('--issuer', '-i', help='issuer of the totp', required=False, default="")


def handle(args):
    kwa = dict(args=args)
    return [doing.doify(save, **kwa)]


def save(tymth, tock=0.0, **opts):
    """ Command line status handler

    """
    _ = (yield tock)
    args = opts["args"]
    name = args.name
    alias = args.alias
    base = args.base
    bran = args.bran
    witness = args.witness

    try:
        with existing.existingHby(name=name, base=base, bran=bran) as hby:
            if args.url:
                otp = pyotp.parse_uri(args.url)
            elif args.secret:
                otp = pyotp.TOTP(s=args.secret, name=args.name, issuer=args.issuer)
            else:
                print("Either --url or --secret is required.")
                return

            org = connecting.Organizer(hby=hby)
            if witness in hby.kevers:
                wit = witness
            else:
                wit = org.find("alias", witness)
                if len(wit) != 1:
                    raise ValueError(f"invalid recipient {witness}")
                wit = wit[0]['id']

            if not wit:
                raise ValueError(f"unknown witness {witness}")

            if alias is None:
                alias = existing.aliasInput(hby)

            hab = hby.habByName(alias)
            codes = dict()

            mkdir(Path.home() / ".rack")

            try:
                path = Path.home() / ".rack" / hab.pre
                with open(path, "r") as f:
                    lines = f.readlines()
                    for line in lines:
                        splits = line.split(':')
                        if len(splits) != 2:
                            continue
                        (aid, code) = splits
                        codes[aid] = code
            except OSError:
                pass

            codes[wit] = otp.secret
            with open(path, "w") as f:
                for aid, code in codes.items():
                    print(f"{aid}:{code.rstrip()}", file=f)

            os.chmod(path, stat.S_IRUSR | stat.S_IWUSR)

    except ConfigurationError as e:
        print(f"identifier prefix for {name} does not exist, incept must be run first", )
        return -1


def mkdir(dir_path):
    # Check if the directory exists
    if not os.path.exists(dir_path):
        # Create the directory
        os.makedirs(dir_path)
        print(f"Directory '{dir_path}' created.")

        # Set permissions to read/write for owner only (0o700 for directory)
        os.chmod(dir_path, stat.S_IRUSR | stat.S_IWUSR | stat.S_IXUSR)
        print(f"Permissions set to read/write/execute for owner only for '{dir_path}'.")
