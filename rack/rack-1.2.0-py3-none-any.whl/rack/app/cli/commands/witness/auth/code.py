# -*- encoding: utf-8 -*-
"""
KERI
rack.app.cli.commands module

RACK Time-based One Time Password Utility
"""
import argparse

import pyotp
from hio import help
from hio.base import doing
from keri.app import connecting
from keri.app.cli.common import existing
from keri.help import helping
from keri.kering import ConfigurationError

from rack.app import witnessing

logger = help.ogler.getLogger()

parser = argparse.ArgumentParser(description='Return the current code for a one-time password URL or secret')
parser.set_defaults(handler=lambda args: handle(args),
                    transferable=True)
parser.add_argument('--name', '-n', help='keystore name and file location of KERI keystore', required=True)
parser.add_argument('--base', '-b', help='additional optional prefix to file location of KERI keystore',
                    required=False, default="")
parser.add_argument('--alias', '-a', help='human readable alias for the new identifier prefix', default=None,
                    required=True)
parser.add_argument('--passcode', '-p', help='21 character encryption passcode for keystore (is not saved)',
                    dest="bran", default=None)  # passcode => bran
parser.add_argument('--witness', '-w', help='alias or qb64 AID of witness to associate this auth with', required=True,
                    default=None)
parser.add_argument("--time", help="timestamp for the code", required=False, default=None)


def handle(args):
    kwa = dict(args=args)
    return [doing.doify(getCode, **kwa)]


def getCode(tymth, tock=0.0, **opts):
    """ Command line status handler

    """
    _ = (yield tock)
    args = opts["args"]
    name = args.name
    alias = args.alias
    base = args.base
    bran = args.bran
    witness = args.witness
    time = args.time

    try:
        with existing.existingHby(name=name, base=base, bran=bran) as hby:
            hab = hby.habByName(alias)
            org = connecting.Organizer(hby=hby)
            if witness in hby.kevers:
                wit = witness
            else:
                wit = org.find("alias", witness)
                if len(wit) != 1:
                    raise ValueError(f"invalid witness {witness}")
                wit = wit[0]['id']

            if not wit:
                raise ValueError(f"unknown witness {witness}")

            codes = witnessing.codes(hab)
            if wit not in codes:
                print(f"No code saved for witness with AID {wit}")
                return

            otp = pyotp.TOTP(s=codes[wit])
            if time:
                print(otp.at(helping.fromIso8601(time)))
            else:
                print(otp.now())

    except ConfigurationError as e:
        print(f"identifier prefix for {name} does not exist, incept must be run first")
        return -1



