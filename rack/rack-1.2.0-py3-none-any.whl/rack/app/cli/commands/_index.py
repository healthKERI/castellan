import argparse


def create_parser() -> argparse.ArgumentParser:
    prsr = argparse.ArgumentParser(description=
                                   'The healthKERI Routing, Authentication and Confidentiality with KERI (RACK) Gateway')
    prsr.set_defaults(handler=lambda args: None)
    return prsr


parser = create_parser()
