# -*- encoding: utf-8 -*-
"""
rack.core.loading module

Provides a Proc implementation that can dynamically load and execute code from external modules.
"""
import importlib
import importlib.util
import sys
import os
import time
import traceback
from pathlib import Path

from hio.base import doing
from hio.help import decking
from keri import help
from prometheus_client import Histogram


logger = help.ogler.getLogger()

MODULE_LOAD_TIME = Histogram('rack_dynamicproc_load_seconds', 'Time to load external module in seconds',
                             ['module_name', 'function_name'])
MODULE_EXEC_TIME = Histogram('rack_dynamicproc_exec_seconds', 'Time to execute external code in seconds',
                             ['module_name', 'function_name'])


class ModuleLoader:
    """
    Handles loading external modules and executing code from them.

    Supports loading modules by name, by path, or from a search path, with
    proper handling of module reloading and error reporting.
    """

    def __init__(self, module_name=None, function_name="get_doer",
                 search_paths=None, reload_module=False, **params):
        """
        Initialize the module loader.

        Args:
            router (Router): The router instance for accessing services
            src (str): Source identifier for the Proc
            dest (str, optional): Destination identifier for the Proc
            module_name (str): Name or path of the module to load
            function_name (str): Name of the function or class to execute within the module
            search_paths (list, optional): Additional paths to search for modules
            reload_module (bool, optional): Whether to reload the module each time it's used
        """
        self.module_name = module_name
        self.function_name = function_name
        self.search_paths = search_paths or []
        self.reload_module = reload_module
        self.params = params

        self.module = None
        self.doer = None
        self.module_path = None

        # Try to load the module during initialization
        if self.module_name:
            self.load_module()

    def load_module(self, module_name=None, function_name=None):
        """
        Load the specified module and function.

        Args:
            module_name (str, optional): Override the module name to load
            function_name (str, optional): Override the function name to load

        Returns:
            bool: True if loading was successful, False otherwise
        """
        start_time = time.time()

        if module_name:
            self.module_name = module_name

        if function_name:
            self.function_name = function_name

        if not self.module_name or not self.function_name:
            logger.error("No module name or no function name specified for dynamic loading")
            return False

        original_path = sys.path.copy()
        try:
            # Add search paths to sys.path temporarily
            if self.search_paths:
                for path in self.search_paths:
                    if path not in sys.path:
                        sys.path.insert(0, path)

            # Check if it's a file path or module name
            if os.path.exists(self.module_name) or '/' in self.module_name or '\\' in self.module_name:
                # It's a file path
                module_path = Path(self.module_name).resolve()
                if not module_path.exists():
                    logger.error(f"Module file not found: {module_path}")
                    return False

                self.module_path = str(module_path)
                spec = importlib.util.spec_from_file_location(
                    module_path.stem, self.module_path
                )
                if spec is None:
                    logger.error(f"Failed to create module spec from {self.module_path}")
                    return False

                module = importlib.util.module_from_spec(spec)
                sys.modules[module_path.stem] = module
                spec.loader.exec_module(module)
                self.module = module
            else:
                # It's a module name
                if self.reload_module and self.module_name in sys.modules:
                    self.module = importlib.reload(sys.modules[self.module_name])
                else:
                    self.module = importlib.import_module(self.module_name)

            # Find the specified function or class
            if not hasattr(self.module, self.function_name):
                logger.error(f"Function/class '{self.function_name}' not found in module '{self.module_name}'")
                return False
            function = getattr(self.module, self.function_name)

            self.doer = function(**self.params)

            load_time = time.time() - start_time
            MODULE_LOAD_TIME.labels(
                module_name=self.module_name,
                function_name=self.function_name or "none"
            ).observe(load_time)

            return True

        except ImportError as e:
            logger.error(f"Failed to import module '{self.module_name}': {str(e)}")
            logger.error(traceback.format_exc())
            return False
        except Exception as e:
            logger.error(f"Error loading module '{self.module_name}': {str(e)}")
            logger.error(traceback.format_exc())
            return False
        finally:
            # Restore original sys.path
            sys.path = original_path


class ModuleLoaderDoer(doing.DoDoer):
    """Doer that periodically processes messages for a ModuleLoader."""

    def __init__(self, loader, **kwa):
        """
        Initialize the ModuleLoaderDoer.

        Args:
            loader (ModuleLoader): The ModuleLoader to service
            **kwa: Additional keyword arguments for the Doer
        """
        self.loader = loader

        self.cues = decking.Deck()
        self.msgs = decking.Deck()

        super(ModuleLoaderDoer, self).__init__(doers=[self.loader.doer], **kwa)

    def recur(self, tyme, deeds = None):
        """Process messages on each recurrence."""
        while self.msgs:
            msg = self.msgs.pull()
            self.loader.doer.msgs.append(msg)

        while self.loader.doer.cues:
            cue = self.loader.doer.cues.pull()
            self.cues.append(cue)

        return super(ModuleLoaderDoer, self).recur(tyme, deeds = deeds)
