import json
from collections import namedtuple

from importlib.resources import files
from keri import kering, core
from keri.core import coring, counting, scheming, parsing
from keri.core.eventing import SealEvent
from keri.kering import Vrsn_1_0
from keri.vc import proving
from keri.vdr import verifying

from rack.core import basing

# SAID field labels
Procage = namedtuple("Procage", "httpsrv http httpcall tcpsrv tcp tcpremote essr dessr socks sockssrv sockscall sftp sftpsrv mllp mllpsrv")

Procs = Procage(httpsrv="httpsrv", http="http", httpcall="httpcall", tcpsrv="tcpsrv", tcp="tcp", tcpremote="tcpremote",
                essr="essr", dessr="dessr", socks="socks", sockssrv="sockssrv", sockscall="sockscall", sftpsrv="sftpsrv",
                sftp="sftp", mllp="mllp", mllpsrv="mllpsrv")

def load_schema(filename: str):
    schema_path = files('rack.schema').joinpath(filename)
    with schema_path.open('r', encoding='utf-8') as f:
        return json.load(f)


# HTTP Outbound Configuration Schema
HTTPOUTBOUNDSCHEMA = load_schema("HttpOutboundConfigurationSchema.json")
_, sad = coring.Saider.saidify(HTTPOUTBOUNDSCHEMA, label=coring.Saids.dollar)
HttpOutboundSchema = scheming.Schemer(sed=sad)

# SFTP Outbound Configuration Schema
SFTPOUTBOUNDSCHEMA = load_schema("SFTPOutboundConfigurationSchema.json")
_, sad = coring.Saider.saidify(SFTPOUTBOUNDSCHEMA, label=coring.Saids.dollar)
SftpOutboundSchema = scheming.Schemer(sed=sad)

# SFTP Inbound Configuration Schema
SFTPINBOUNDSCHEMA = load_schema("SFTPInboundConfigurationSchema.json")
_, sad = coring.Saider.saidify(SFTPINBOUNDSCHEMA, label=coring.Saids.dollar)
SftpInboundSchema = scheming.Schemer(sed=sad)

# HTTP Inbound Configuration Schema
HTTPINBOUNDSCHEMA = load_schema("HttpInboundConfigurationSchemaDetailed.json")
_, sad = coring.Saider.saidify(HTTPINBOUNDSCHEMA, label=coring.Saids.dollar)
HttpInboundSchema = scheming.Schemer(sed=sad)

# HTTP CALL Inbound Configuration Schema
HTTPCALLINBOUNDSCHEMA = load_schema("HttpCallInboundConfigurationSchemaDetailed.json")
_, sad = coring.Saider.saidify(HTTPCALLINBOUNDSCHEMA, label=coring.Saids.dollar)
HttpCallInboundSchema = scheming.Schemer(sed=sad)

# Load balancer Configuration Schema
LOADBALANCESCHEMA = load_schema("LoadBalanceConfigurationSchema.json")
_, sad = coring.Saider.saidify(LOADBALANCESCHEMA, label=coring.Saids.dollar)
LoadBalanceSchema = scheming.Schemer(sed=sad)

# Load balancer Configuration Schema
ROUTERSCHEMA = load_schema("RouterConfigurationSchema.json")
_, sad = coring.Saider.saidify(ROUTERSCHEMA, label=coring.Saids.dollar)
RouterSchema = scheming.Schemer(sed=sad)

# MLLP Outbound Configuration Schema
MLLPOUTBOUNDSCHEMA = load_schema("MLLPOutboundConfigurationSchema.json")
_, sad = coring.Saider.saidify(MLLPOUTBOUNDSCHEMA, label=coring.Saids.dollar)
MllpOutboundSchema = scheming.Schemer(sed=sad)

# MLLP Inbound Configuration Schema
MLLPINBOUNDSCHEMA = load_schema("MLLPInboundConfigurationSchema.json")
_, sad = coring.Saider.saidify(MLLPINBOUNDSCHEMA, label=coring.Saids.dollar)
MllpInboundSchema = scheming.Schemer(sed=sad)

class Routery:

    def __init__(self, hby, rgy, rt=None, name="routery", alias="routery"):
        """

        Parameters:
            rt (RouteTable): route database
            hby (Habery): database environment and Hab factory
            rgy (Regery): credential registry factory
            name (str): Name of route factory
            alias (str): Name of Hab ot use to issue and revoke credentials

        """
        self.name = name
        self.alias = alias
        self.hby = hby
        self.rgy = rgy
        self.hby.db.schema.pin(LoadBalanceSchema.said, LoadBalanceSchema)  # idempotent
        self.hby.db.schema.pin(RouterSchema.said, RouterSchema)  # idempotent
        self.hby.db.schema.pin(HttpInboundSchema.said, HttpInboundSchema)  # idempotent
        self.hby.db.schema.pin(HttpCallInboundSchema.said, HttpCallInboundSchema)  # idempotent
        self.hby.db.schema.pin(HttpOutboundSchema.said, HttpOutboundSchema)  # idempotent
        self.hby.db.schema.pin(SftpInboundSchema.said, SftpInboundSchema)  # idempotent
        self.hby.db.schema.pin(SftpOutboundSchema.said, SftpOutboundSchema)  # idempotent
        self.hby.db.schema.pin(MllpOutboundSchema.said, MllpOutboundSchema)  # idempotent
        self.hby.db.schema.pin(MllpInboundSchema.said, MllpInboundSchema)  # idempotent

        self.rt = rt if rt is not None else basing.RouteTable(name=self.hby.name, temp=self.hby.temp)

        self.hab = self.hby.habByName(self.alias)
        if self.hab is None:
            raise kering.ConfigurationError(f"{self.alias} is not a valid alias")

        self.reg = self.rgy.registryByName(self.alias)
        if self.reg is None:
            raise kering.ConfigurationError(f"{self.alias} not a valid registry name")

        saiders = self.rgy.reger.issus.get(keys=self.hab.pre)
        for saider in saiders:
            creder = self.reg.reger.creds.get(keys=(saider.qb64,))
            self.rt.routes[saider.qb64] = creder

    @property
    def routes(self):
        """ Return the routes database from the RouteTable """
        return self.rt.routes

    def makeRoute(self, **kwa):
        """ Create route object and pass parameters through to make method

        Returns:
            Route: the created Route
        """
        route = Route(rt=self.rt, hby=self.hby, hab=self.hab, rgy=self.rgy, reg=self.reg)

        try:
            route.make(**kwa)
        except Exception as e:
            if "MDB_BAD_RSLOT" in str(e) or "BadRslotError" in str(e):
                # Refresh registry connection and retry
                self.reg = self.rgy.registryByName(self.alias)
                route = Route(rt=self.rt, hby=self.hby, hab=self.hab, rgy=self.rgy, reg=self.reg)
                route.make(**kwa)
            else:
                raise


        return route

    def deleteRoute(self, said):
        try:
            creder = self.reg.reger.creds.get(keys=(said,))
        except Exception as e:
            if "MDB_BAD_RSLOT" in str(e) or "BadRslotError" in str(e):
                # Refresh the registry connection and try again
                self.reg = self.rgy.registryByName(self.alias)
                creder = self.reg.reger.creds.get(keys=(said,))
            else:
                raise

        if not creder:
            raise ValueError(f"{said} is not a valid route SAID")

        # Revoke the credential
        registry = self.rgy.regs[creder.regi]
        hab = registry.hab

        state = registry.tever.vcState(vci=creder.said)
        if state is None or state.et not in (coring.Ilks.iss, coring.Ilks.rev):
            raise kering.ValidationError(f"credential {creder.said} not is correct state for revocation")

        rserder = registry.revoke(said=creder.said)

        vcid = rserder.ked["i"]
        rseq = coring.Seqner(snh=rserder.ked["s"])
        rseal = SealEvent(vcid, rseq.snh, rserder.said)
        rseal = dict(i=rseal.i, s=rseal.s, d=rseal.d)

        hab.interact(data=[rseal])
        seqner = coring.Seqner(sn=hab.kever.sner.num)
        saider = coring.Saider(qb64=hab.kever.serder.said)
        registry.anchorMsg(pre=vcid, regd=rserder.said, seqner=seqner, saider=saider)
        self.rgy.processEscrows()

        self.reg.reger.cancs.rem(keys=(said,))
        self.reg.reger.creds.rem(keys=(said,))

        schema = creder.schema.encode("utf-8")
        issuer = creder.issuer.encode("utf-8")
        saider = coring.Saider(qb64=creder.said)

        self.reg.reger.saved.rem(keys=saider.qb64b)
        self.reg.reger.issus.rem(keys=issuer, val=saider)
        self.reg.reger.schms.add(keys=schema, val=saider)
        if not isinstance(creder.attrib, str) and 'i' in creder.attrib:
            subject = creder.attrib["i"].encode("utf-8")
            self.reg.reger.subjs.rem(keys=subject, val=saider)

        del self.rt.routes[said]


class Route:
    def __init__(self, rt, hby, hab, rgy, reg):
        self.rt = rt
        self.hby = hby
        self.hab = hab
        self.rgy = rgy
        self.reg = reg
        self.said = None

    def make(self, name, route_type, config):
        match route_type:
            case "http_inbound":
                schema = HttpInboundSchema.said
            case "httpcall_inbound":
                schema = HttpCallInboundSchema.said
            case "http_outbound":
                schema = HttpOutboundSchema.said
            case "sftp_inbound":
                schema = SftpInboundSchema.said
            case "sftp_outbound":
                schema = SftpOutboundSchema.said
            case "load_balancer":
                schema = LoadBalanceSchema.said
            case "router":
                schema = RouterSchema.said
            case "mllp_inbound":
                schema = MllpInboundSchema.said
            case "mllp_outbound":
                schema = MllpOutboundSchema.said
            case _:
                raise ValueError(f"Invalid route type: {route_type}")

        creder = proving.credential(issuer=self.hab.pre,
                                    recipient=None,
                                    schema=schema,
                                    data=config,
                                    status=self.reg.regk)

        iss = self.reg.issue(said=creder.said)
        rseal = SealEvent(iss.pre, "0", iss.said)._asdict()
        self.hab.interact(data=[rseal])
        seqner = coring.Seqner(sn=self.hab.kever.sn)
        self.reg.anchorMsg(pre=iss.pre,
                           regd=iss.said,
                           seqner=seqner,
                           saider=coring.Saider(qb64=self.hab.kever.serder.said))
        self.rgy.processEscrows()

        msg = bytearray(creder.raw)
        msg.extend(core.Counter(counting.CtrDex_1_0.SealSourceTriples, count=1, gvrsn=Vrsn_1_0).qb64b)
        msg.extend(coring.Prefixer(qb64=iss.pre).qb64b)
        msg.extend(coring.Seqner(sn=0).qb64b)
        msg.extend(iss.saidb)

        verifier = verifying.Verifier(hby=self.hby, reger=self.rgy.reger)
        parsing.Parser().parse(ims=msg, vry=verifier, gvrsn=Vrsn_1_0)

        creder, *_ = self.reg.reger.cloneCred(said=creder.said)
        self.said = creder.said

        self.rt.routes[self.said] = creder
        return self.said