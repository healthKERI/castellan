# -*- encoding: utf-8 -*-
"""
rack.core.basing module

"""
import schedule
from hio.base import doing
from keri import core, help
from keri.core import coring, serdering
from kerkle.core.treeing import SparseMerkleTree

from rack.app import delegating

logger = help.ogler.getLogger()


class MessageAnchorer:

    def __init__(self, router, signer, maximum=None, interactions=10,
                 rotations=10, frequency=60, interval="minutes", at=None, minimum=None):

        logger.info(f"Launching anchorer max={maximum} with ixn={interactions}/rot={rotations} freq={frequency} {interval}")
        self.router = router
        self.signer = signer
        self.cues = self.router.cues
        self.max = maximum
        self.interactions = interactions
        self.rotations = rotations
        self.freq = frequency
        self.interval = interval
        self.at = at
        self.schedule = schedule.Scheduler()

        job = self.schedule.every(self.freq)
        intervalattr = getattr(job, interval)
        if at:
            intervalattr.at(at).do(self.processMinimums)
        else:
            intervalattr.do(self.processMinimums)

    def processMaximums(self):
        if self.max is None:
            return

        hab = self.router.hab(self.signer)
        if self.router.rt.encs.cnt(keys=(hab.kever.serder.said,)) >= self.max:
            self.anchor(hab)

    def processMinimums(self):
        hab = self.router.hab(self.signer)
        if self.router.rt.encs.cnt(keys=(hab.kever.serder.said,)) > 0:
            self.anchor(hab)

    def anchor(self, hab):
        """ Pause, anchor and rotation/remove this delegated signer if appropriate

        Park the signing delegate represented by `hab` by rotating to the next signer, then
        create an anchor of all outstanding unanchored events and it appropriate, perform a
        key rotation (based on "interactions") and then if appropriate, remove this signing
        delegate from the pool of signers.

        Parameters:
            hab (Hab):  The habitat of the signing delegate

        """
        self.router.rotateSigner(self.signer)

        tree = SparseMerkleTree()

        for said in self.router.rt.encs.getIter(keys=(hab.kever.serder.said,)):
            tree.update(coring.Saider(qb64=said))

        root = core.Matter(raw=tree.root_as_bytes(), code=core.MtrDex.Blake3_256)

        said = hab.kever.serder.said
        msg = hab.interact(data=[{'d': root.qb64}])
        serder = serdering.SerderKERI(raw=msg)

        self.cues.append(dict(ked=serder.ked))

        kever = hab.kever

        self.router.rt.ancs.add(keys=(hab.pre, kever.serder.snh, said,),
                                val=(coring.Diger(qb64=kever.serder.said),
                                     coring.Diger(qb64=root.qb64)))

        ixns = self.router.rt.cntAncs(keys=(hab.pre,))
        if ixns > 0 and ixns % self.interactions == 0:
            self.rotate(hab)

            # Number of current rotations is kever.lastEst.s - 1 (get rid of the inception event)
            rots = kever.lastEst.s - 1 - self.router.rt.cntAncs(keys=(hab.pre,))
            if rots >= self.rotations:
                # remove this signing delegate from the pool, retiring him from duty
                self.router.rt.dlgs.rem(keys=(self.signer,), val=hab.pre)

                # create a new signing delegate to replace the retired one:
                hab = self.router.hby.habs[self.signer]
                deli = delegating.Delegatery(hby=self.router.hby, rt=self.router.rt, hab=hab)
                delegates = deli.make(count=1)
                logger.info(f"Created new delegate={delegates[0].name} ({delegates[0].pre}")

    def rotate(self, hab):
        msg = hab.rotate()
        serder = serdering.SerderKERI(raw=msg)

        self.cues.append(dict(ked=serder.ked))


class MessageAnchorerDoer(doing.Doer):

    def __init__(self, anchorer, **kwa):
        self.messageAnchorer = anchorer

        super(MessageAnchorerDoer, self).__init__(tock=1.0, **kwa)

    def recur(self, tyme):
        self.messageAnchorer.processMaximums()
        self.messageAnchorer.schedule.run_pending()
        return False
