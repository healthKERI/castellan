# -*- encoding: utf-8 -*-
"""
rack.core.basing module

"""
from dataclasses import dataclass

from keri.core import coring
from keri.db import dbing, koming, subing

from rack.core.subing import SetSuber

@dataclass
class InboundRoute:
    localPort: int
    localHost: int
    localAID: str
    route_type: str
    scheme: str
    host: str
    port: int
    gateway: str = None
    router: str = None
    anchoring: bool = False
    maximum: int = 0
    frequency: int = 0
    interval: str = None
    interactions: int = 0
    rotations: int = 0
    schema: str = ""
    saids: list = None
    lastPing: str = None


@dataclass
class OutboundRoute:
    localAID: str
    route_type: str
    scheme: str
    port: int
    gateway: str = None
    router: str = None
    anchoring: bool = False
    maximum: int = 0
    frequency: int = 0
    interval: str = None
    interactions: int = 0
    rotations: int = 0
    saids: list = None
    lastPing: str = None

@dataclass
class SftpInboundRoute:
    localAID: str
    route_type: str
    scheme: str
    host: str
    port: int
    root: str
    gateway: str = None
    router: str = None
    anchoring: bool = False
    minimum: int = 0
    maximum: int = 0
    frequency: int = 0
    interval: str = None
    interactions: int = 0
    rotations: int = 0
    schema: str = ""
    saids: list = None
    lastPing: str = None


@dataclass
class SftpOutboundRoute:
    localAID: str
    route_type: str
    scheme: str = "sftp"
    host: str = ""
    port: int = 22
    tcpAID: str = ""
    root: str = ""
    delete_original: bool = False
    gateway: str = None
    router: str = None
    anchoring: bool = False
    minimum: int = 0
    maximum: int = 0
    frequency: int = 0
    interval: str = None
    interactions: int = 0
    rotations: int = 0
    saids: list = None
    lastPing: str = None


@dataclass
class MllpInboundRoute:
    localAID: str
    route_type: str
    scheme: str = "mllp"
    host: str = ""
    port: int = 8080
    mllp_host: str = ""
    mllp_port: int = 2575
    gateway: str = None
    router: str = None
    anchoring: bool = False
    minimum: int = 0
    maximum: int = 0
    frequency: int = 0
    interval: str = None
    interactions: int = 0
    rotations: int = 0
    saids: list = None
    lastPing: str = None


@dataclass
class MllpOutboundRoute:
    localAID: str
    route_type: str
    scheme: str = "mllp"
    mllp_host: str = ""
    mllp_port: int = 2575
    tcp_aid: str = ""
    tcp_host: str = ""
    tcp_port: int = 8080
    gateway: str = None
    router: str = None
    anchoring: bool = False
    minimum: int = 0
    maximum: int = 0
    frequency: int = 0
    interval: str = None
    interactions: int = 0
    rotations: int = 0
    saids: list = None
    lastPing: str = None


@dataclass
class Delegator:
    alias: str
    local: bool
    resolved: bool = False


@dataclass
class Gateway:
    alias: str
    resolved: bool = False


@dataclass
class Notification:
    type: str
    title: str
    body: str
    external: bool = False
    read: bool = False
    params: dict = None


@dataclass
class CloudRouter:
    name: str
    localAID: str
    gateway: str

@dataclass
class LoadBalancer:
    aid: str
    host: str
    port: int
    hosts: list = None
    anchoring: bool = False
    minimum: int = 0
    maximum: int = 0
    frequency: int = 0
    interval: str = "minutes"
    interactions: int = 0
    rotations: int = 0
    saids: list = None
    lastPing: str = None

@dataclass
class Router:
    aid: str
    host: str
    port: int
    hosts: list = None
    anchoring: bool = False
    minimum: int = 0
    maximum: int = 0
    frequency: int = 0
    interval: str = "minutes"
    interactions: int = 0
    rotations: int = 0
    saids: list = None
    lastPing: str = None

@dataclass
class LastScan:
    scan: list

class RouteTable(dbing.LMDBer):
    TailDirPath = "keri/rt"
    AltTailDirPath = ".keri/rt"
    TempPrefix = "rt"

    def __init__(self, name="routetable", headDirPath=None, reopen=True, **kwa):
        """

        Parameters:
            headDirPath:
            perm:
            reopen:
            kwa:
        """
        self.srcs = None

        self.gators = None
        self.dsts = None
        self.dlgs = None
        self.rtrd = None

        self.inbs = None
        self.inbsAidIdx = None
        self.inbsGtwIdx = None
        self.otbs = None
        self.otbsAidIdx = None
        self.otbsGtwIdx = None

        self.inbSftps = None
        self.inbSftpsAidIdx = None
        self.inbSftpsGtwIdx = None
        self.otbSftps = None
        self.otbSftpsAidIdx = None
        self.otbSftpsGtwIdx = None

        self.inbMllps = None
        self.inbMllpsAidIdx = None
        self.inbMllpsGtwIdx = None
        self.otbMllps = None
        self.otbMllpsAidIdx = None
        self.otbMllpsGtwIdx = None

        self.loadBalancers = None
        self.loadBalancersAidIdx = None

        self.routers = None
        self.routersAidIdx = None

        self.cur = None
        self.encs = None
        self.ancs = None

        self.nots = None
        self.rtrs = None
        self.lscn = None

        self.routes = dict()

        super(RouteTable, self).__init__(name=name, headDirPath=headDirPath, reopen=reopen, **kwa)

    def reopen(self, **kwa):
        """  Reopen database and initialize sub-dbs
        """
        super(RouteTable, self).reopen(**kwa)

        self.srcs = SetSuber(db=self, subkey="srcs.")

        self.gators = koming.Komer(db=self, subkey='gators.', schema=Delegator, )

        # Mapping destination AIDs to source AIDs
        self.dsts = koming.Komer(db=self, subkey="dsts.", schema=Gateway)

        # Tracking current delegates available for given delegator keyed by delegator AID
        self.dlgs = subing.IoSetSuber(db=self, subkey="dlgs.")

        # Tracking retired delegates no longer available for given delegator keyed by delegator AID
        self.rtrd = subing.IoSetSuber(db=self, subkey="rtrd.")

        # Inbound HTTP Route Definitions for User Interface
        self.inbs = koming.Komer(db=self, subkey="inbs.", schema=InboundRoute)
        self.inbsAidIdx = subing.IoSetSuber(db=self, subkey="inbsAidIdx.")
        self.inbsGtwIdx = subing.IoSetSuber(db=self, subkey="inbsGtwIdx.")

        # Outbound HTTP Route Definitions for User Interface
        self.otbs = koming.Komer(db=self, subkey="otbs.", schema=OutboundRoute)
        self.otbsAidIdx = subing.IoSetSuber(db=self, subkey="otbsAidIdx.")
        self.otbsGtwIdx = subing.IoSetSuber(db=self, subkey="otbsGtwIdx.")

        # Inbound SFTP Route Definitions for User Interface
        self.inbSftps = koming.Komer(db=self, subkey="inbSftps.", schema=SftpInboundRoute)
        self.inbSftpsAidIdx = subing.IoSetSuber(db=self, subkey="inbSftpsAidIdx.")
        self.inbSftpsGtwIdx = subing.IoSetSuber(db=self, subkey="inbSftpsGtwIdx.")

        # Outbound SFTP Route Definitions for User Interface
        self.otbSftps = koming.Komer(db=self, subkey="otbSftps.", schema=SftpOutboundRoute)
        self.otbSftpsAidIdx = subing.IoSetSuber(db=self, subkey="otbSftpsAidIdx.")
        self.otbSftpsGtwIdx = subing.IoSetSuber(db=self, subkey="otbSftpsGtwIdx.")

        # Inbound MLLP Route Definitions for User Interface
        self.inbMllps = koming.Komer(db=self, subkey="inbMllps.", schema=MllpInboundRoute)
        self.inbMllpsAidIdx = subing.IoSetSuber(db=self, subkey="inbMllpsAidIdx.")
        self.inbMllpsGtwIdx = subing.IoSetSuber(db=self, subkey="inbMllpsGtwIdx.")

        # Outbound MLLP Route Definitions for User Interface
        self.otbMllps = koming.Komer(db=self, subkey="otbMllps.", schema=MllpOutboundRoute)
        self.otbMllpsAidIdx = subing.IoSetSuber(db=self, subkey="otbMllpsAidIdx.")
        self.otbMllpsGtwIdx = subing.IoSetSuber(db=self, subkey="otbMllpsGtwIdx.")

        # Load Balancer Definitions for User Interface
        self.loadBalancers = koming.Komer(db=self, subkey="loadBalancers.", schema=LoadBalancer)
        self.loadBalancersAidIdx = subing.IoSetSuber(db=self, subkey="loadBalancersAidIdx.")

        # Router Definitions for User Interface
        self.routers = koming.Komer(db=self, subkey="routers.", schema=Router)
        self.routersAidIdx = subing.IoSetSuber(db=self, subkey="routersAidIdx.")

        # Current in use delegate for a given delegator keyed by delegator AID
        self.cur = subing.Suber(db=self, subkey="cur.")

        # Current set of encoded but not anchored essr exn messages
        self.encs = subing.IoSetSuber(db=self, subkey="encs.")

        # Current set of anchoring interaction events created
        self.ancs = subing.CatCesrIoSetSuber(db=self, subkey="ancs.", klas=(coring.Diger, coring.Diger))

        # Notifications, system generate or received externally
        self.nots = koming.Komer(db=self, subkey="nots.", schema=Notification)

        # KERI Cloud Routers
        self.rtrs = koming.Komer(db=self, subkey="rtrs", schema=CloudRouter)

        # Last scan of files from a given base for client side sftp proc
        self.lscn = koming.Komer(db=self, subkey="lscn.", schema=LastScan)

        self.reload()
        return self.env

    def reload(self):
        pass

    def cntAncs(self, keys):
        vals = []
        for item in self.ancs.getItemIter(keys=keys):
            vals.append(item)

        return len(vals)

    def updateAidCounts(self):
        self.inbsAidIdx.trim()
        self.otbsAidIdx.trim()

        for (name,), inbound in self.inbs.getItemIter():
            self.inbsAidIdx.add(keys=(inbound.localAID,), val=name)

        for (name,), outbound in self.otbs.getItemIter():
            self.otbsAidIdx.add(keys=(outbound.localAID,), val=name)

        for (name,), inbound in self.inbSftps.getItemIter():
            self.inbsAidIdx.add(keys=(inbound.localAID,), val=name)

        for (name,), outbound in self.otbSftps.getItemIter():
            self.otbsAidIdx.add(keys=(outbound.localAID,), val=name)

        for (name,), inbound in self.inbMllps.getItemIter():
            self.inbsAidIdx.add(keys=(inbound.localAID,), val=name)

        for (name,), outbound in self.otbMllps.getItemIter():
            self.otbsAidIdx.add(keys=(outbound.localAID,), val=name)

    def updateGtwCounts(self):
        self.inbsGtwIdx.trim()
        self.otbsGtwIdx.trim()

        for (name,), inbound in self.inbs.getItemIter():
            if inbound.gateway:
                self.inbsGtwIdx.add(keys=(inbound.gateway,), val=name)

        for (name,), outbound in self.otbs.getItemIter():
            if outbound.gateway:
                self.otbsGtwIdx.add(keys=(outbound.gateway,), val=name)

        for (name,), inbound in self.inbSftps.getItemIter():
            if inbound.gateway:
                self.inbsGtwIdx.add(keys=(inbound.gateway,), val=name)

        for (name,), outbound in self.otbSftps.getItemIter():
            if outbound.gateway:
                self.otbsGtwIdx.add(keys=(outbound.gateway,), val=name)

        for (name,), inbound in self.inbMllps.getItemIter():
            if inbound.gateway:
                self.inbsGtwIdx.add(keys=(inbound.gateway,), val=name)

        for (name,), outbound in self.otbMllps.getItemIter():
            if outbound.gateway:
                self.otbsGtwIdx.add(keys=(outbound.gateway,), val=name)
