# -*- encoding: utf-8 -*-
"""
rack.core.pinging module

"""
import secrets

from hio.base import doing
from hio.help import decking
from keri import help
from keri.help import helping
from keri.peer import exchanging

logger = help.ogler.getLogger()


class PingHandler:
    """
    Handler for acknowledgement `exn` messages used to ack the reply of other exns

    on
        {
           "v": "KERI10JSON00011c_",                               // KERI Version String
           "t": "exn",                                             // peer to peer message ilk
           "dt": "2020-08-22T17:50:12.988921+00:00"
           "r": "/ping",
           "q": {}
           "a": {},
           "p": ""
        }-AABAA1o61PgMhwhi89FES_vwYeSbbWnVuELV_jv7Yv6f5zNiOLnj1ZZa4MW2c6Z_vZDt55QUnLaiaikE-d_ApsFEgCA

    """

    resource = "/ping"

    def __init__(self, router, name, src, cues=None, params=None):
        """

        Parameters:
            router (Router): Route environment
            cues (Deck): message storage for store and forward

        """
        self.router = router
        self.name = name
        self.src = src
        self.cues = cues if cues is not None else decking.Deck()
        self.params = params or {}

    def handle(self, serder, attachments=None):
        """  Do route specific processsing of IPEX protocol exn messages

        Parameters:
            serder (Serder): Serder of the IPEX protocol exn message
            attachments (list): list of tuples of root pathers and CESR SAD path attachments to the exn event

        """
        try:
            hab = self.router.hab(self.src)
            said = serder.ked['d']

            if (route := self.router.rt.inbs.get(keys=(self.name,))) is not None:
                route.lastPing = helping.nowIso8601()
                self.router.rt.inbs.pin(keys=(self.name,), val=route)
            elif (route := self.router.rt.otbs.get(keys=(self.name,))) is not None:
                route.lastPing = helping.nowIso8601()
                self.router.rt.otbs.pin(keys=(self.name,), val=route)

            pong, atc = makePongExn(hab, serder)
            self.cues.append(dict(serder=pong, atc=atc, a=dict(r="/pong")))

            logger.info(f"ping={said} received, replying with pong={pong.said}")
        except Exception as e:
            logger.exception(f"***** ERROR {e}")


class PongHandler:
    """
    Handler for acknowledgement `exn` messages used to ack the reply of other exns

    on
        {
           "v": "KERI10JSON00011c_",                               // KERI Version String
           "t": "exn",                                             // peer to peer message ilk
           "dt": "2020-08-22T17:50:12.988921+00:00"
           "r": "/pong",
           "q": {}
           "a": {},
           "p": "ECgaLXUw2rsjdJpAR0e2qCq3jX7q7gLld3LjAwZBp64A"
        }-AABAA1o61PgMhwhi89FES_vwYeSbbWnVuELV_jv7Yv6f5zNiOLnj1ZZa4MW2c6Z_vZDt55QUnLaiaikE-d_ApsFEgCA

    """

    resource = "/pong"

    def __init__(self, rt, name, cues=None, params=None):
        """

        Parameters:
            cues (Deck): message storage for store and forward

        """
        self.rt = rt
        self.name = name
        self.cues = cues if cues is not None else decking.Deck()
        self.params = params or {}

    def handle(self, serder, attachments=None):
        """  Do route specific processsing of IPEX protocol exn messages

        Parameters:
            serder (Serder): Serder of the IPEX protocol exn message
            attachments (list): list of tuples of root pathers and CESR SAD path attachments to the exn event

        """
        if (route := self.rt.inbs.get(keys=(self.name,))) is not None:
            route.lastPing = helping.nowIso8601()
            self.rt.inbs.pin(keys=(self.name,), val=route)
        elif (route := self.rt.otbs.get(keys=(self.name,))) is not None:
            route.lastPing = helping.nowIso8601()
            self.rt.otbs.pin(keys=(self.name,), val=route)

        said = serder.ked['d']
        dig = serder.ked['p']

        logger.info(f"pong={said} received for exn message {dig}")


def makePingExn(hab):
    """ Create a peer to peer message ping message to ensure the other end is alive

    Parameters:
        hab (Hab): identifier Hab for ensorsing the message to send

    Returns:
        SerderKERI: (Serder): Serder of exn message and CESR attachments

    """
    ping, _ = exchanging.exchange(route="/ping", payload={}, sender=hab.pre)
    return ping


def makePongExn(hab, png):
    """ Create a peer to peer message to respond to a ping message to alert the pinger you are still alive

    Either rot or ixn are required but not both

    Parameters:
        hab (GroupHab): identifier Hab for ensorsing the message to send
        png (Serder): Serder of ping message we are replying to

    Returns:
        tuple: (Serder, bytes): Serder of exn message and CESR attachments

    """
    pong, end = exchanging.exchange(route="/pong", sender=hab.pre, payload={}, dig=png.said)
    evt = hab.endorse(serder=pong, last=False, pipelined=False)
    atc = bytearray(evt[pong.size:])
    atc.extend(end)

    return pong, atc


class Pinger(doing.Doer):
    """ Class to send periodic ping exn messages """

    def __init__(self, router, src, reps, tock=60.0):
        """ Create pinger class

        Parameters:
            router(Router): Routing environment
            src (str): qb64 of base identifier
            reps (Deck): queue of ping messages to send
            tock (float): time between recurs

        """
        self.router = router
        self.src = src
        self.reps = reps if reps is not None else decking.Deck()

        super(Pinger, self).__init__(tock=tock)

    def recur(self, tyme):
        said = secrets.token_hex(32)
        self.reps.append(dict(r="/ping", said=said))


