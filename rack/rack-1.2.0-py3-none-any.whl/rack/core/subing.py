# -*- encoding: utf-8 -*-
"""
rack.core.subing module

"""
from keri.db.subing import Suber


class SetSuber(Suber):

    def add(self, key, val):
        self.pin(keys=(key, val), val=b'')

    def delete(self, key, val):
        self.rem(keys=(key, val))

    def exists(self, key, val):
        return self.get(keys=(key, val)) is not None

    def iter(self, key):
        for (_, val), _ in self.getItemIter(keys=(key,)):
            yield val

    def len(self, key):
        cnt = 0
        for v in self.getItemIter(keys=(key,)):
            cnt += 1

        return cnt


