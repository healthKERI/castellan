# -*- encoding: utf-8 -*-
"""
rack.core.installing module

"""
from hio.base import doing
from keri import kering, core
from keri.app import habbing
from keri.app.keeping import Algos
from keri.core import serdering, parsing, coring
from keri.core.eventing import SealEvent
from keri.help import helping
from keri.vdr import credentialing

from rack.core import basing, scheming

DEFAULT_ADMIN_PASSID = "EK4iFDRWMPH2mJ_VSJZt5VgCTg7wupzKX5nipreSOBuR"
DEFAULT_ADMIN_SALT = b'DQ7Hzp4faFdbesNx-_a1v'


class Installer(doing.DoDoer):
    """ Installer class for RACK gateway setup."""
    def __init__(self, name, base, bran, salt):
        self.name = name
        self.base = base
        self.bran = bran
        self.salt = salt
        self.hby = None
        self.rgy = None

        super(Installer, self).__init__(doers=[doing.doify(self.install)])

    def install(self, tymth, tock=0.0, **kwa):
        """ Process incoming messages to incept a credential registry

        Parameters:
            tymth (function): injected function wrapper closure returned by .tymen() of
                Tymist instance. Calling tymth() returns associated Tymist .tyme.
            tock (float): injected initial tock value

        Returns:  doifiable Doist compatible generator method
        """
        # enter context
        self.wind(tymth)
        self.tock = tock
        _ = (yield self.tock)

        print(f"Installng RACK gateway {self.name}...")

        yield from self.createKERIDatabase()
        self._install()

        if not self.bran:
            print("** WARNING - Your RACK keystore is not encrypted, your private keys are in the clear. **")

        print()

        self.exit()
        return True

    def createKERIDatabase(self):
        kwa = dict()
        kwa["salt"] = self.salt
        kwa["bran"] = self.bran
        if self.salt is None:
            kwa["algo"] = Algos.randy
            kwa["salt"] = None
        else:
            kwa["salt"] = core.Salter(raw=self.salt).qb64

        self.hby = habbing.Habery(name=self.name, base=self.base, temp=False, **kwa)
        self.rgy = credentialing.Regery(hby=self.hby, name=self.name, base=self.base, temp=False)
        registrar = credentialing.Registrar(hby=self.hby, rgy=self.rgy, counselor=None)

        self.extend([habbing.HaberyDoer(self.hby)])
        self.extend([registrar])

        rack = self.hby.makeHab(name="rack", transferable=True, icount=1, isith="1", ncount=1, nsith="1", toad=0)
        registry = self.rgy.makeRegistry(name="rack", prefix=rack.pre)

        rseal = SealEvent(registry.regk, "0", registry.regd)
        rseal = dict(i=rseal.i, s=rseal.s, d=rseal.d)
        anc = rack.interact(data=[rseal])

        aserder = serdering.SerderKERI(raw=bytes(anc))
        registrar.incept(iserder=registry.vcp, anc=aserder)
        while not registrar.complete(pre=registry.regk, sn=0):
            self.rgy.processEscrows()
            yield self.tock

        print(f"RACK Keystore created at: {self.hby.ks.path}")
        print(f"RACK Database created at: {self.hby.db.path}")
        print(f"RACK Credential Store created at: {self.rgy.reger.path}")
        print(f"RACK Credential Registry created as {registry.regk}")
        print()

    def _install(self):
        pass


class AdminUIInstaller(Installer):

    def __init__(self, name, base, bran, salt, host, port, file=None):
        self.file = file
        self.host = host
        self.port = port
        self.passid = None
        self.hby = None
        self.rgy = None

        super(AdminUIInstaller, self).__init__(name=name, base=base, bran=bran, salt=salt)

    def _install(self):
        self.createDefaultPassid()
        self.initializeCore()

    def createDefaultPassid(self):
        if self.file is None:
            nonce = coring.randomNonce()
            hby = habbing.Habery(name=f"temp_{nonce}", temp=False)
            hab = hby.makeHab(name="admin", transferable=True, icount=1, isith="1", ncount=1, nsith="1", toad=0,
                              salt=core.Salter(raw=DEFAULT_ADMIN_SALT).qb64)
            parsing.Parser(kvy=self.hby.kvy, local=False).parseOne(hab.makeOwnInception())
            self.passid = hab.pre
        else:
            with open(self.file, 'rb') as f:
                ims = f.read()
                serder = serdering.SerderKERI(raw=ims)
                parsing.Parser(kvy=self.hby.kvy, local=False).parseOne(ims)
                self.passid = serder.pre

        print(f"RACK Admin Passid is: {self.passid}")

    def exportRackAID(self):
        hab = self.hby.habByName("core")
        with open(f"./{self.hby.name}-core.cesr", 'w') as f:
            for msg in self.hby.db.clonePreIter(pre=hab.pre):
                f.write(msg.decode("utf-8"))

            msgs = hab.replyToOobi(aid=hab.pre, role="gateway")
            f.write(msgs.decode("utf-8"))

        print(f"RACK Core KEL exported to: {self.hby.name}-core.cesr")

    def initializeCore(self):
        rt = basing.RouteTable(name=self.hby.name, reopen=True)
        hab = self.hby.habByName("rack")

        core = self.hby.makeHab(name="core", transferable=True, icount=1, isith="1", ncount=1, nsith="1", toad=0)
        dt = helping.nowIso8601()
        msgs = bytearray()
        msgs.extend(core.makeEndRole(eid=core.pre,
                                     role=kering.Roles.gateway,
                                     stamp=dt))
        msgs.extend(core.makeLocScheme(url=f"{kering.Schemes.http}://{self.host}:{self.port}/",
                                       scheme=kering.Schemes.http,
                                       stamp=dt))
        core.psr.parse(ims=msgs)

        routery = scheming.Routery(name=self.hby.name, alias=hab.name, rt=rt, hby=self.hby, rgy=self.rgy)

        config = dict(aid=core.pre,
                      tcpsrv=dict(host=self.host, port=self.port),
                      httpcall=dict(app="rack.app.ui.admining", params=dict())
                      )

        routery.makeRoute(name="__admin__", route_type="httpcall_inbound", config=config)

        print(f"RACK Core Identifier created as: {core.pre}")
        print(f"RACK Core OOBI: {kering.Schemes.http}://{self.host}:{self.port}/oobi/{core.pre}")
        self.exportRackAID()


class WingmanInstaller(Installer):

    def __init__(self, name, base, bran, salt, host, port, thost, tport):
        """ Initialize Installer class for RACK gateway setup.

        Parameters:
            name (str): Name identifier for the RACK gateway
            base (str): Base directory path for data storage
            bran (str): Passcode for key store access
            host (str): Host address for the gateway server
            port (int): Port number for the gateway server
            salt (bytes): The package name of the web application to call
            thost (str): Destination host address for the gateway server
            tport (int): Destination port number for the gateway server

        The Installer class manages the setup of a RACK (Registry and Authentication Credential Kit) gateway.
        It handles the creation of KERI databases, credential registries, and route configurations.
        The class inherits from DoDoer to implement asynchronous processing capabilities.
        """
        self.name = name
        self.base = base
        self.bran = bran
        self.salt = salt
        self.host = host
        self.port = port
        self.dhost = thost
        self.dport = tport
        self.hby = None
        self.rgy = None

        super(WingmanInstaller, self).__init__(name=name, base=base, bran=bran, salt=salt)

    def _install(self):
        self.initializeCore()

    def initializeCore(self):
        """ Initialize the core HAB and create a base set of RACK routes

        The initializeCore method sets up the fundamental routing infrastructure for the RACK gateway.
        It performs the following tasks:
        1. Opens a RouteTable for managing message routing configurations
        2. Retrieves the 'rack' and core HABs for the gateway
        3. Creates a Routery instance to manage routing logic
        4. Configures a series of routes for the admin interface including:
           - TCP server route for network communication
           - Deserialization/serialization routes for message processing
           - HTTP call routes for web API integration
           - Event source/sink routes for message handling

        Side Effects:
            - Creates or updates`````` routing configurations in the RouteTable
            - Prints the created core identifier and OOBI information
            - Sets up bi-directional message flow paths for the gateway
        """
        rt = basing.RouteTable(name=self.hby.name, reopen=True)
        hab = self.hby.habByName("wingman")

        core = self.hby.habByName(self.hby.name)
        if not core:
            core = self.hby.makeHab(name=self.hby.name, transferable=True, icount=1, isith="1", ncount=1, nsith="1",
                                    toad=0)
            
        routery = scheming.Routery(name=self.hby.name, alias=hab.name, rt=rt, hby=self.hby, rgy=self.rgy)

        config = dict(aid=core.pre,
                      tcpsrv=dict(host=self.host, port=self.port),
                      http=dict(host=self.dhost, port=self.dport)
                      )

        routery.makeRoute(name=self.name, route_type="http_inbound", config=config)

        print(f"Wingman Core Identifier created as: {core.pre}")
        print(f"Wingman Core OOBI: {kering.Schemes.http}://{self.host}:{self.port}/oobi/{core.pre}")
