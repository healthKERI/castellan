# -*- encoding: utf-8 -*-
"""
rack.core.profiling module

"""

from prometheus_client.utils import INF

SIZE_BUCKETS = (5000, 10000, 50000, 100000, 500000, 1000000, 5000000, 10000000,
                20000000, 30000000, 40000000, 50000000, 60000000, 80000000, 100000000, INF)


