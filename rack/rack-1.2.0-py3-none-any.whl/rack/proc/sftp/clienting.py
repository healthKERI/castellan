# -*- encoding: utf-8 -*-
"""
rack.proc.sftp.clienting module

"""
import math
import time
import os
import platform

from rack.core.basing import LastScan
from pathlib import Path
from hio.base import doing
from hio.help import decking
from keri import help, core
from keri.core import coring, counting
from keri.kering import Vrsn_1_0
from rack.core.scheming import Procs
from rack.proc.http.httping import CHUNK_SIZE


logger = help.ogler.getLogger()

class Scanner:

    def __init__(self, router, name, src, params=None, base=None):
        self.router = router
        self.rt = self.router.rt
        self.hby = self.router.hby
        self.src = src
        self.lastScan = set()

        self.cues = decking.Deck()
        self.msgs = decking.Deck()
        self.dels = decking.Deck()

        self.params = params if params is not None else dict()
        self.base = base or self._getDefaultBase()

    def _getDefaultBase(self):
        """Get default base directory for scanning"""
        system = platform.system().lower()
        if system == "windows":
            return os.path.join(os.environ.get("PROGRAMDATA", "C:\\ProgramData"), "rack-sftp-scan")
        else:
            return "/opt/rack-sftp-scan"

    def parse(self, msg):
        """Decodes a message and processes it if it is valid.

        Parameters:
            msg (dict): The message to decode.

        Raises:
            ValueError: If the message or event is invalid.
        """
        ctx = msg.get("ctx", {})

        payload = msg['a']
        route = payload['r']
        match route:
            case "/sftp/del":
                if "path" not in payload:
                    raise ValueError(f"invalid message to sftp proc={msg}")

                self._deleteFile(payload, ctx=ctx)
            case _:
                raise ValueError(f"invalid message to sftp proc={msg}")

    def processMsgs(self):
        """Processes all messages in the deck.

        Decodes each message and logs any errors that occur during decoding.
        """
        while self.msgs:
            msg = self.msgs.pull()
            try:
                self.parse(msg)
            except Exception as e:
                logger.error(f"error={e} parsing msg /sftp/del msg={msg}")

    def scan(self):
        if not os.path.exists(self.base):
            os.makedirs(self.base, exist_ok=True)

        lastScan = None
        try:
            lastScan = self.rt.lscn.get(keys=self.base)
        except Exception as e:
            print(e)

        files = []
        scanDir = Path(self.base)
        for path in scanDir.rglob('*'):
            if path.is_file():
                try:
                    files.append(str(path))
                except Exception as e:
                    print(e)
                    continue

        newFiles = []
        if lastScan:
            newFiles = list(set(files) - set(lastScan.scan))
        else:
            newFiles = files

        for filePath in newFiles:
            try:
                self._processNewFile(filePath)
            except Exception as e:
                logger.error(f"Error processing new file {filePath}: {e}")

        scan = LastScan(scan=files)
        self.rt.lscn.pin(keys=self.base, val=scan)

    def _processNewFile(self, filePath):
        """Process a newly detected file and generate sftp/put message"""
        start = time.time()

        try:
            with open(filePath, 'rb') as f:
                fileBytes = f.read()
        except Exception as e:
            logger.error(f"Failed to read file {filePath}: {e}")
            return

        relativePath = os.path.relpath(filePath, self.base)
        if not relativePath.startswith('/'):
            relativePath = '/' + relativePath

        hab = self.router.hab(self.src)
        if fileBytes:
            dig = core.Diger(ser=fileBytes, code=core.MtrDex.Blake3_256).qb64
        else:
            dig = ""
        size = len(fileBytes)

        ctx = {}

        payload = dict(
            r="/sftp/put",
            path=relativePath,
            body=dig,
            size=size,
        )

        atc = bytearray()
        chunks = math.ceil(size / CHUNK_SIZE) if size > 0 else 0
        if chunks:
            atc.extend(counting.Counter(
                code=counting.CtrDex_1_0.ESSRPayloadGroup,
                count=chunks,
                gvrsn=Vrsn_1_0
            ).qb64b)

            for idx in range(chunks):
                start_byte = idx * CHUNK_SIZE
                end_byte = start_byte + CHUNK_SIZE
                texter = coring.Matter(raw=fileBytes[start_byte:end_byte], code=coring.MtrDex.Bytes_L0)
                atc.extend(texter.qb64b)

        cue = dict(i=Procs.sftp, src=hab.pre, c=self.params, ctx=ctx,
                   a=dict(r="/sftp/put", path=relativePath, body=dig, size=size, atc=atc.decode("utf-8")))

        self.cues.append(cue)

    def _deleteFile(self, payload, ctx):
        """Delete file based on del message payload"""
        relativePath = payload['path']
        if relativePath.startswith('/'):
            relativePath = relativePath[1:]

        fullPath = os.path.join(self.base, relativePath)
        if os.path.exists(fullPath):
            try:
                os.remove(fullPath)
                logger.info(f"Deleted file: {fullPath}")
            except Exception as e:
                logger.error(f"Failed to delete file {fullPath}: {e}")
        else:
            logger.warning(f"File not found for deletion: {fullPath}")

    def service(self):
        """Services the Scanner by processing messages and scanning."""
        self.scan()
        self.processMsgs()

    def close(self):
        self.msgs.clear()
        self.cues.clear()

class ScannerDoer(doing.Doer):
    """
    SFTP Scanner Doer
    """

    def __init__(self, scanner, **kwa):
        super(ScannerDoer, self).__init__(**kwa)
        self.scanner = scanner

    def recur(self, tyme):
        self.scanner.service()

    def exit(self):
        self.scanner.close()

class SftpScannerProc:
    def __init__(self, router, name, src, base=None, params=None):
        self.router = router
        self.name = name
        self.hby = self.router.hby
        self.src = src
        self.base = base
        self.params = params or {}

        self.scanner = Scanner(router=self.router, name=self.name, src=self.src, base=self.base, params=self.params)

    @property
    def inbound(self):
        return self.scanner.msgs

    @property
    def outbound(self):
        return self.scanner.cues

    def service(self):
        self.scanner.service()

    def close(self):
        self.scanner.close()
