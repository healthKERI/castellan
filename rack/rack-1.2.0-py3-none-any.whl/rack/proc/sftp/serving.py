# -*- encoding: utf-8 -*-
"""
rack.proc.sftp.serving module

"""
import os
import platform

from hio.base import doing
from hio.help import decking
from keri import help, core
from keri.core import counting
from rack.core.scheming import Procs

logger = help.ogler.getLogger()

class Filer:

    def __init__(self, router, name, src, params=None, base=None, delete=True):
        self.router = router
        self.hby = self.router.hby
        self.src = src

        self.cues = decking.Deck()
        self.msgs = decking.Deck()

        self.params = params if params is not None else dict()
        self.base = base
        self.delete = delete

    def parse(self, msg):
        """Decodes a message and processes it if it is valid.

        Parameters:
            msg (dict): The message to decode.

        Raises:
            ValueError: If the message or event is invalid.
        """
        ctx = msg.get("ctx", {})

        payload = msg['a']
        route = payload['r']
        match route:
            case "/sftp/put":
                if "path" not in payload or "atc" not in payload:
                    raise ValueError(f"invalid message to sftp proc={msg}")

                atc = bytearray(payload['atc'].encode("utf-8"))
                body = bytearray()

                if atc:
                    counter = counting.Counter(qb64b=atc, strip=True)
                    for _ in range(counter.count):
                        body.extend(core.Texter(qb64b=atc, strip=True).raw)

                self.writeFile(payload, ctx=ctx, body=body)
            case _:
                raise ValueError(f"invalid message to sftp proc={msg}")

    def processMsgs(self):
        """Processes all messages in the deck.

        Decodes each message and logs any errors that occur during decoding.
        """
        while self.msgs:
            msg = self.msgs.pull()
            try:
                self.parse(msg)
            except Exception as e:
                logger.error(f"error={e} parsing msg /sftp/put msg={msg}")

    def writeFile(self, payload, ctx, body):
        """Write file to disk based on payload and body data"""

        basePath = self.base
        if not self.base:
            system = platform.system().lower()
            if system == "windows":
                basePath = os.path.join(os.environ.get("PROGRAMDATA", "C:\\ProgramData"), "rack-sftp-put")
            else:
                basePath = "/opt/rack-sftp-put"

        sender = ctx.get("src", self.src)

        aid_folder = os.path.join(basePath, sender)
        if not os.path.exists(aid_folder):
            raise FileNotFoundError(f"AID folder does not exist: {aid_folder}")

        file_path = payload['path']
        if file_path.startswith('/'):
            file_path = file_path[1:]

        full_path = os.path.join(aid_folder, file_path)

        directory = os.path.dirname(full_path)
        if directory and not os.path.exists(directory):
            os.makedirs(directory, exist_ok=True)

        try:
            if isinstance(body, str):
                with open(full_path, 'w', encoding='utf-8') as f:
                    f.write(body)
            else:
                with open(full_path, 'wb') as f:
                    f.write(body)

            logger.info(f"Successfully wrote file: {full_path}")

            file_ctx = dict(ctx)

            if self.delete:
                hab = self.router.hab(self.src)

                del_payload = dict(
                    r="/sftp/del",
                    path=payload['path'],
                    body="",
                    size=0,
                )

                cue = dict(i=Procs.sftpsrv, src=hab.pre, c=self.params, ctx=file_ctx, a=del_payload)
                self.cues.append(cue)

        except Exception as e:
            logger.error(f"Failed to write file {full_path}: {e}")
            raise

    def service(self):
        """Services the Filer by processing messages."""
        self.processMsgs()

    def close(self):
        self.msgs.clear()
        self.cues.clear()

class FilerDoer(doing.Doer):
    """
    SFTP Filer Doer
    """

    def __init__(self, filer, **kwa):
        super(FilerDoer, self).__init__(**kwa)
        self.filer = filer

    def recur(self, tyme):
        self.filer.service()

    def exit(self):
        self.filer.close()

class SftpPutProc:
    def __init__(self, router, name, src, base=None, params=None, delete=True):
        self.router = router
        self.name = name
        self.hby = self.router.hby
        self.src = src
        self.base = base
        self.params = params or {}
        self.delete = delete

        self.filer = Filer(router=self.router, name=self.name,
                           src=self.src, base=self.base,
                           params=self.params, delete=self.delete)

    @property
    def inbound(self):
        return self.filer.msgs

    @property
    def outbound(self):
        return self.filer.cues

    def service(self):
        self.filer.service()

    def close(self):
        self.filer.close()


