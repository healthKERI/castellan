# -*- encoding: utf-8 -*-
"""
rack.proc.tcp.serving module

"""
from hio.base import doing
from hio.core import tcp
from hio.help import decking
from keri import help
from keri.core import parsing, serdering, coring
from keri.peer import exchanging
from prometheus_client import Counter

from rack.core.scheming import Procs

logger = help.ogler.getLogger()

REQUESTS = Counter('rack_tcpsrv_request_duration_seconds', 'TCP server request duration in seconds',
                   ['src', 'dest'])


class Directant(doing.DoDoer):
    """
    Directant class with TCP Server.
    Responds to initiated connections from a remote Director by creating and
    running a Reactant per connection. Each Reactant has TCP remoter.

    Directant Subclass of DoDoer with doers list from do generator methods:
        .serviceDo

    Enables continuous scheduling of doers (do generator instances or functions)

    Implements Doist like functionality to allow nested scheduling of doers.
    Each DoDoer runs a list of doers like a Doist but using the tyme from its
       injected tymist as injected by its parent DoDoer or Doist.

    Scheduling hierarchy: Doist->DoDoer...->DoDoer->Doers

    Inherited Attributes:
        .done is Boolean completion state:
            True means completed
            Otherwise incomplete. Incompletion maybe due to close or abort.
        .opts is dict of injected options for its generator .do
        .doers is list of Doers or Doer like generator functions

    Attributes:
        .hab is Habitat instance of local controller's context
        .server is TCP client instance. Assumes operated by another doer.
        .rants is dict of Reactants indexed by connection address

    Inherited Properties:
        .tyme is float relative cycle time of associated Tymist .tyme obtained
            via injected .tymth function wrapper closure.
        .tymth is function wrapper closure returned by Tymist .tymeth() method.
            When .tymth is called it returns associated Tymist .tyme.
            .tymth provides injected dependency on Tymist tyme base.
        .tock is desired time in seconds between runs or until next run,
                 non negative, zero means run asap

    Properties:

    Inherited Methods:
        .wind  injects ._tymth dependency from associated Tymist to get its .tyme
        .__call__ makes instance callable
            Appears as generator function that returns generator
        .do is generator method that returns generator
        .enter is enter context action method
        .recur is recur context action method or generator method
        .clean is clean context action method
        .exit is exit context method
        .close is close context method
        .abort is abort context method

    Methods:

    Hidden:
       ._tymth is injected function wrapper closure returned by .tymen() of
            associated Tymist instance that returns Tymist .tyme. when called.
       ._tock is hidden attribute for .tock property
    """

    def __init__(self, router, src, server, msgs=None, cues=None, misses=None, doers=None, **kwa):
        """
        Initialize instance.

        Inherited Parameters:
            tymist is  Tymist instance
            tock is float seconds initial value of .tock

        Parameters:
            db is database instance of local controller's context
            verifier (optional) is Verifier instance of local controller's TEL context
            server is TCP Server instance
        """
        self.router = router
        self.src = src
        self.msgs = msgs if msgs is not None else decking.Deck()
        self.cues = cues if cues is not None else decking.Deck()
        self.misses = misses if misses is not None else decking.Deck()

        self.server = server  # use server for cx
        self.rants = dict()
        doers = doers if doers is not None else []
        doers.extend([doing.doify(self.serviceDo), doing.doify(self.msgDo)])

        super(Directant, self).__init__(doers=doers, **kwa)
        if self.tymth:
            self.server.wind(self.tymth)

    def wind(self, tymth):
        """
        Inject new tymist.tymth as new ._tymth. Changes tymist.tyme base.
        Updates winds .tymer .tymth
        """
        super(Directant, self).wind(tymth)
        self.server.wind(tymth)

    def serviceDo(self, tymth=None, tock=0.0, **kwa):
        """  Process incoming comnnections in a Do loop by provisioning a Reactant for each connection

        Parameters:
            tymth (Tymyth):  Timer object
            tock (float):  Pause time until the scheduler processes this look again

        Returns:
            Never

        """
        # start enter context
        self.wind(tymth)
        self.tock = tock
        yield self.tock

        while True:
            for ca, ix in list(self.server.ixes.items()):
                if ix.cutoff:
                    self.closeConnection(ca)
                    continue

                if ca not in self.rants:  # create Reactant and extend doers with it
                    rant = Reactant(ca=ca, tymth=self.tymth, router=self.router, src=self.src,
                                    cues=self.cues, misses=self.misses, remoter=ix)
                    self.rants[ca] = rant
                    # add Reactant (rant) doer to running doers
                    self.extend(doers=[rant])  # open and run rant as doer

                if ix.tymeout > 0.0 and ix.tymer.expired:
                    self.closeConnection(ca)  # also removes rant

            yield

    def msgDo(self, tymth=None, tock=0.0, **kwa):
        self.wind(tymth)
        self.tock = tock
        yield self.tock

        while True:
            while self.msgs:
                msg = self.msgs.pull()
                ctx = msg.get("ctx", {})
                ca = ctx.get("ca", None)

                if ca not in self.rants:
                    logger.info(f"msgDo: no rant for ca={ca}")
                    continue

                rant = self.rants[ca]
                rant.msgs.append(msg)

                yield self.tock

            yield self.tock


    def closeConnection(self, ca):
        """
        Close and remove connection given by ca and remove associated rant at ca.
        """
        if ca in self.server.ixes:  # remoter still there
            self.server.ixes[ca].serviceSends()  # send final bytes to socket
        self.server.removeIx(ca)
        if ca in self.rants:  # remove rant (Reactant) if any
            self.remove([self.rants[ca]])  # close and remove rant from doers list
            del self.rants[ca]


class Reactant(doing.DoDoer):
    """
    Reactant Subclass of DoDoer with doers list from do generator methods:
        .msgDo, .cueDo, and .escrowDo.
    Enables continuous scheduling of doers (do generator instances or functions)

    Implements Doist like functionality to allow nested scheduling of doers.
    Each DoDoer runs a list of doers like a Doist but using the tyme from its
       injected tymist as injected by its parent DoDoer or Doist.

    Scheduling hierarchy: Doist->DoDoer...->DoDoer->Doers

    Attributes:
        .hab is Habitat instance of local controller's context
        .kevery is Kevery instance
        .remoter is TCP Remoter instance for connection from remote TCP client.

    Inherited Attributes:
        .done is Boolean completion state:
            True means completed
            Otherwise incomplete. Incompletion maybe due to close or abort.
        .opts is dict of injected options for its generator .do
        .doers is list of Doers or Doer like generator functions


    Inherited Properties:
        .tyme is float relative cycle time of associated Tymist .tyme obtained
            via injected .tymth function wrapper closure.
        .tymth is function wrapper closure returned by Tymist .tymeth() method.
            When .tymth is called it returns associated Tymist .tyme.
            .tymth provides injected dependency on Tymist tyme base.
        .tock is float, desired time in seconds between runs or until next run,
                 non negative, zero means run asap

    Properties:

    Inherited Methods:
        .wind  injects ._tymth dependency from associated Tymist to get its .tyme
        .__call__ makes instance callable
            Appears as generator function that returns generator
        .do is generator method that returns generator
        .enter is enter context action method
        .recur is recur context action method or generator method
        .clean is clean context action method
        .exit is exit context method
        .close is close context method
        .abort is abort context method

    Overidden Methods:

    Hidden:
       ._tymth is injected function wrapper closure returned by .tymen() of
            associated Tymist instance that returns Tymist .tyme. when called.
       ._tock is hidden attribute for .tock property

    """

    def __init__(self, ca, router, src, remoter, msgs=None, cues=None, misses=None, doers=None, **kwa):
        """
        Initialize instance.

        Inherited Parameters:
            tymist is  Tymist instance
            tock is float seconds initial value of .tock
            doers is list of doers (do generator instancs or functions)

        Parameters:
            router (Router): The Router object for managing routes.
            src (str): qb64 identifier prefix of data source
            remoter is TCP Remoter instance
            doers is list of doers (do generator instances, functions or methods)

        """
        self.ca = ca
        self.router = router
        self.src = src
        self.xip = coring.randomNonce()

        self.reps = decking.Deck()
        self.misses = misses if misses is not None else decking.Deck()

        self.forwarder = ForwardHandler(ca=ca, router=self.router, src=self.src, cues=cues, reps=self.reps)
        self.exc = exchanging.Exchanger(hby=self.router.hby, handlers=[self.forwarder])

        self.remoter = remoter  # use remoter for both rx and tx
        self.msgs = msgs if msgs is not None else decking.Deck()

        doers = doers if doers is not None else []
        doers.extend([doing.doify(self.remoteDo),
                      doing.doify(self.cueDo),
                      doing.doify(self.repsDo),
                      doing.doify(self.msgDo),
                      doing.doify(self.escrowDo)])

        self.parser = parsing.Parser(ims=self.remoter.rxbs,
                                     framed=True,
                                     exc=self.exc)

        super(Reactant, self).__init__(doers=doers, **kwa)
        if self.tymth:
            self.remoter.wind(self.tymth)

    def wind(self, tymth):
        """
        Inject new tymist.tymth as new ._tymth. Changes tymist.tyme base.
        Updates winds .tymer .tymth
        """
        super(Reactant, self).wind(tymth)
        self.remoter.wind(tymth)

    def remoteDo(self, tymth=None, tock=0.0, **kwa):
        """  Yields from self.parser to ensure constant processing of incoming stream as
             CESR parsable stream.

        Parameters:
            tymth (Tymyth):  Timer object
            tock (float):  Pause time until the scheduler processes this look again

        Returns:
            Never

        """

        # start enter context
        self.wind(tymth)
        self.tock = tock
        yield self.tock

        done = yield from self.parser.parsator(local=True)  # process messages continuously
        return done  # should nover get here except forced close

    def cueDo(self, tymth=None, tock=0.0, **kwa):
        """  Process cues coming out of Exchanger exn protocol messaging handling

        Parameters:
            tymth (Tymyth):  Timer object
            tock (float):  Pause time until the scheduler processes this look again

        Returns:
            Never

        """

        # start enter context
        self.wind(tymth)
        self.tock = tock
        yield self.tock

        while True:
            while self.exc.cues:
                cue = self.exc.cues.pull()
                if "kin" in cue and cue["kin"] == "saved":
                    said = cue["said"]
                    logger.info(f"exn with said={said} saved")

                elif "kin" in cue and cue["kin"] == "query":
                    q = cue["q"]
                    pre = q["pre"]
                    snh = q["sn"]
                    self.misses.append(dict(src=self.src, pre=pre, snh=snh))
                    logger.info(
                        f"exn query for pre={pre} snh={snh} received, "
                        f"saved to miss cue deck"
                    )

                else:
                    logger.info(f"unhandled cue={cue}")

                yield  # throttle just do one cue at a time
            yield

    def repsDo(self, tymth=None, tock=0.0, **kwa):
        self.wind(tymth)
        self.tock = tock
        yield self.tock

        while True:
            while self.reps:
                rep = self.reps.pull()
                serder = rep["serder"]
                atc = rep["atc"]
                ims = bytearray(serder.raw)
                ims.extend((bytes(atc)))

                self.sendMessage(ims, label="response protocol messages")

            yield self.tock

    def msgDo(self, tymth=None, tock=0.0, **kwa):
        self.wind(tymth)
        self.tock = tock
        yield self.tock

        while True:
            while self.msgs:
                msg = self.msgs.pull()
                ctx = msg.get("ctx", {})
                payload = msg['a']
                hab = self.router.hab(self.src)

                # We need to check for both kinds of cues in our system, a KERI event or a raw message
                if "serder" and "atc" in payload:  # This is a cue with a KERI event
                    serder = serdering.SerderKERI(sad=payload['serder'])
                    atc = payload["atc"]
                    evt = bytearray(serder.raw)
                    if hasattr(atc, "encode"):
                        atc = atc.encode("utf-8")

                    evt.extend(atc)
                    fwd, atc = exchanging.exchange(route='/fwd', modifiers=dict(),
                                                   payload=dict(src=serder.ked['i'], dest=serder.ked['rp'], ctx=ctx),
                                                   embeds=dict(evt=evt),
                                                   sender=hab.pre)
                    ims = hab.endorse(serder=fwd, last=False, pipelined=False)
                    ims.extend(atc)

                    self.sendMessage(ims, label="response message")
                    hab.db.epath.rem(keys=(fwd.said,))

                else:  # No KERI event, forward the payload
                    fwd, atc = exchanging.exchange(route='/fwd', modifiers=dict(),
                                                   payload=payload, embeds=dict(), sender=hab.pre)
                    ims = hab.endorse(serder=fwd, last=False, pipelined=False)
                    ims.extend(atc)

                    self.sendMessage(ims, label="response message")
                    hab.db.epath.rem(keys=(fwd.said,))

            yield

    def escrowDo(self, tymth=None, tock=0.0, **kwa):
        """  Run escrow processing for Exchanger

        Parameters:
            tymth (Tymyth):  Timer object
            tock (float):  Pause time until the scheduler processes this look again

        Returns:
            Never

        """

        # start enter context
        self.wind(tymth)
        self.tock = tock
        yield self.tock

        while True:
            self.exc.processEscrow()
            yield

    def sendMessage(self, msg, label=""):
        """
        Sends message msg and loggers label if any
        """
        self.remoter.tx(msg)  # send to remote
        hab = self.router.hab(self.src)
        logger.info("Server %s: sent %s: %d", hab.name,
                    label, len(msg))

class TcpSrvProcDoer(doing.DoDoer):
    """ tcpsrc proc doer for running tcp server doer"""

    def __init__(self, tcpsrv, **kwa):
        self.tcpsrv = tcpsrv
        super(TcpSrvProcDoer, self).__init__(doers=tcpsrv.doers, **kwa)

    def close(self):
        """Close the wrapped TcpSrvProc and then call parent close"""
        logger.info(f"type {type(self.tcpsrv)}")

        if hasattr(self.tcpsrv, 'close') and type(self.tcpsrv) is TcpSrvProc:
            logger.info(f"TcpSrvProcDoer closing TcpSrvProc on port {self.tcpsrv.port}")
            self.tcpsrv.close()
        super().close()


class TcpSrvProc:
    def __init__(self, router, name, host, port, src, params, misses=None):
        self.router = router
        self.hby = self.router.hby
        self.name = name
        self.src = src
        self.msgs = decking.Deck()
        self.cues = decking.Deck()
        self.misses = misses if misses is not None else decking.Deck()

        self.host = host
        self.port = port
        self.params = params
        self.server = tcp.Server(host=host, port=port)

        if not self.server.reopen():
            raise RuntimeError(f"cannot create tcp server on port {port}")

        self.directant = Directant(router=router, src=src, server=self.server, msgs=self.msgs, cues=self.cues,
                                   misses=misses)

        self.doers = [self.directant, tcp.ServerDoer(server=self.server)]

    @property
    def inbound(self):
        return self.msgs

    @property
    def outbound(self):
        return self.cues

    def service(self):
        """"""
        pass

    def close(self):
        """Close the TCP server and clean up resources"""
        logger.info(f"Closing TcpSrvProc on port {self.port}")

        try:
            # Step 1: Close all doers first
            if hasattr(self, 'doers'):
                for doer in self.doers:
                    if hasattr(doer, 'close'):
                        try:
                            doer.close()
                            logger.debug(f"Closed doer: {type(doer).__name__}")
                        except Exception as e:
                            logger.warning(f"Error closing doer {type(doer).__name__}: {e}")

            # Step 2: Close the server
            if hasattr(self, 'server') and self.server:
                try:
                    # Close all incoming connections first
                    if hasattr(self.server, 'closeAllIx'):
                        self.server.closeAllIx()
                        logger.debug(f"Closed all connections on port {self.port}")

                    # Clear connections dict
                    if hasattr(self.server, 'ixes'):
                        self.server.ixes.clear()

                    # Close the listen socket
                    self.server.close()
                    logger.debug(f"Closed server listen socket on port {self.port}")

                except Exception as e:
                    logger.warning(f"Error closing TCP server on port {self.port}: {e}")
                finally:
                    self.server = None

            logger.info(f"TcpSrvProc on port {self.port} closed successfully")

        except Exception as e:
            logger.error(f"Error in TcpSrvProc.close(): {e}")



class ForwardHandler:
    """
    Handler for forward `exn` messages used to envelope other KERI messages intended for another recipient.
    This handler acts as a mailbox for other identifiers and stores the messages in a local database.

    on
        {
           "v": "KERI10JSON00011c_",                               // KERI Version String
           "t": "exn",                                             // peer to peer message ilk
           "dt": "2020-08-22T17:50:12.988921+00:00"
           "r": "/fwd",
           "q": {
              "pre": "EEBp64Aw2rsjdJpAR0e2qCq3jX7q7gLld3LjAwZgaLXU",
              "topic": "delegate"
            }
           "a": '{
              "v":"KERI10JSON000154_",
              "t":"dip",
              "d":"Er4bHXd4piEtsQat1mquwsNZXItvuoj_auCUyICmwyXI",
              "i":"Er4bHXd4piEtsQat1mquwsNZXItvuoj_auCUyICmwyXI",
              "s":"0",
              "kt":"1",
              "k":["DuK1x8ydpucu3480Jpd1XBfjnCwb3dZ3x5b1CJmuUphA"],
              "n":"EWWkjZkZDXF74O2bOQ4H5hu4nXDlKg2m4CBEBkUxibiU",
              "bt":"0",
              "b":[],
              "c":[],
              "a":[],
              "di":"Et78eYkh8A3H9w6Q87EC5OcijiVEJT8KyNtEGdpPVWV8"
           }
        }-AABAA1o61PgMhwhi89FES_vwYeSbbWnVuELV_jv7Yv6f5zNiOLnj1ZZa4MW2c6Z_vZDt55QUnLaiaikE-d_ApsFEgCA

    """

    resource = "/fwd"

    def __init__(self, ca, router, src, cues=None, reps=None, params=None):
        """

        Parameters:
            router (Router): routing environment
            cues (Deck): message storage for store and forward

        """
        self.ca = ca
        self.router = router
        self.src = src
        self.cues = cues if cues is not None else decking.Deck()
        self.reps = reps if reps is not None else decking.Deck()
        self.params = params or {}

    def handle(self, serder, attachments=None):
        """  Do route specific processsing of IPEX protocol exn messages

        Parameters:
            serder (Serder): Serder of the IPEX protocol exn message
            attachments (list): list of tuples of root pathers and CESR SAD path attachments to the exn event

        """
        embeds = serder.ked['e']
        if attachments:
            payload = dict()
            for pather, atc in attachments:
                sad = pather.resolve(embeds)
                payload["serder"] = sad
                payload["atc"] = atc.decode("utf-8")
        else:
            payload = serder.ked['a']

        src = serder.ked['a']["src"]
        dest = serder.ked["a"]["dest"]
        ctx = serder.ked['a'].get("ctx", {})

        logger.info(f"Message from {src} to {dest}")

        ctx['ca'] = self.ca
        cue = dict(i=Procs.tcpsrv, src=src, dest=dest, c=self.params, ctx=ctx, a=payload)
        self.cues.append(cue)

        kwargs = dict(src=src, dest=dest)
        REQUESTS.labels(**kwargs).inc()

        self.router.hby.db.epath.rem(keys=(serder.said,))
        hab = self.router.hab(self.src)

        ack, _ = exchanging.exchange(route='/ack', modifiers=dict(topic="/"),
                                     payload={}, sender=hab.pre, dig=serder.said)
        ims = hab.endorse(serder=ack, last=False, pipelined=False)
        self.reps.append(dict(serder=ack, atc=ims[ack.size:]))
