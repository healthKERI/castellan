# -*- encoding: utf-8 -*-
"""
rack.proc.tcp.remoting module

TCP Proc that Uses a remote gateway as its server

"""
import time

from hio.base import doing
from hio.core.tcp import Client as TcpClient, ClientDoer as TcpClientDoer
from hio.help import decking
from keri import help
from keri.core import parsing, serdering
from keri.peer import exchanging
from prometheus_client import Histogram

from rack.core import profiling
from rack.core.scheming import Procs

logger = help.ogler.getLogger()

REQUEST_TIME = Histogram('rack_tcp_remote_request_duration_seconds', 'TCP remote request duration in seconds',
                         ['src', 'host', 'port'])
REQUEST_SIZE = Histogram('rack_tcp_remote_reqest_size_bytes', 'TCP remote request size in bytes',
                         ['src', 'host', 'port'], buckets=profiling.SIZE_BUCKETS)


class Director(doing.Doer):
    """
    Base class for Direct Mode KERI Controller Doer with habitat and TCP Client

    Attributes:
        router (Router): The Router object for managing routes.
        client (serving.Client): hio TCP client instance.
            Assumes operated by another doer.

    Inherited Properties:
        tyme (float): relative cycle time of associated Tymist, obtained
            via injected .tymth function wrapper closure.
        tymth (function): function wrapper closure returned by Tymist .tymeth()
            method.  When .tymth is called it returns associated Tymist .tyme.
            .tymth provides injected dependency on Tymist tyme base.
        tock (float): desired time in seconds between runs or until next run,
            non negative, zero means run asap

    Properties:

    Inherited Methods:
        .__call__ makes instance callable return generator
        .do is generator function returns generator

    Methods:

    Hidden:
       ._tymth is injected function wrapper closure returned by .tymen() of
            associated Tymist instance that returns Tymist .tyme. when called.
       ._tock is hidden attribute for .tock property
    """

    def __init__(self, router, src, dest, client, **kwa):
        """
        Initialize instance.

        Inherited Parameters:
            tymist is  Tymist instance
            tock is float seconds initial value of .tock

        Parameters:
            hab is Habitat instance
            client is TCP Client instance. Assumes opened/closed elsewhere

        """
        super(Director, self).__init__(**kwa)
        self.router = router
        self.src = src
        self.dest = dest
        self.msgs = decking.Deck()

        self.client = client  # use client to initiate comms
        if self.tymth:
            self.client.wind(self.tymth)

    def wind(self, tymth):
        """
        Inject new tymist.tymth as new ._tymth. Changes tymist.tyme base.
        Updates winds .tymer .tymth
        """
        super(Director, self).wind(tymth)
        self.client.wind(tymth)
        self.sendSyn()

    def sendSyn(self):
        logger.info(f"Sending /syn from {self.dest} -> {self.src}")
        hab = self.router.hab(self.src)
        syn, atc = exchanging.exchange(route="/syn", modifiers=dict(),
                                       payload=dict(src=self.src, dest=self.dest),
                                       sender=hab.pre)
        ims = hab.endorse(serder=syn, last=False, pipelined=False)
        ims.extend(atc)

        self.client.tx(ims)

    def recur(self, tyme):
        """ Process incoming messages by enveloping them in a /fwd and sending them to the client.

        Args:
            tyme (Tymist):  ticker

        Returns:

        """
        # On each step, loop through all queued messages
        while self.msgs:
            start = time.time()
            msg = self.msgs.pull()
            payload = msg['a']
            hab = self.router.hab(self.src)

            if not self.client.connected or (self.client.connected and self.client.cutoff):
                self.client.reopen()

            # We need to check for both kinds of cues in our system, a KERI event or a raw message
            if "serder" and "atc" in payload:  # This is a cue with a KERI event
                serder = serdering.SerderKERI(sad=payload['serder'])
                atc = payload["atc"]
                evt = bytearray(serder.raw)
                if hasattr(atc, "encode"):
                    atc = atc.encode("utf-8")
                evt.extend(atc)
                fwd, atc = exchanging.exchange(route="/fwd", modifiers=dict(),
                                               payload=dict(src=serder.ked['i'], dest=serder.ked['rp']),
                                               embeds=dict(evt=evt),
                                               sender=hab.pre)
                ims = hab.endorse(serder=fwd, last=False, pipelined=False)
                ims.extend(atc)

                size = len(ims)
                self.client.tx(ims)
                hab.db.epath.rem(keys=(fwd.said,))

            else:  # No KERI event, forward the payload
                fwd, atc = exchanging.exchange(route='/fwd', modifiers=dict(),
                                               payload=payload, embeds=dict(), sender=hab.pre)
                ims = hab.endorse(serder=fwd, last=False, pipelined=False)
                ims.extend(atc)

                size = len(ims)
                self.client.tx(ims)
                hab.db.epath.rem(keys=(fwd.said,))

            request_time = time.time() - start
            (host, port) = self.client.ha
            kwargs = dict(src=hab.pre, host=host, port=port)
            REQUEST_TIME.labels(**kwargs).observe(request_time)
            REQUEST_SIZE.labels(**kwargs).observe(size)


class Reactor(doing.DoDoer):
    """
    TCP Client Reactor for processing incoming responses from a connected client.  Handles exn protocol messages

    """

    def __init__(self, router, src, client, exc, doers=None, **kwa):
        """
        Initialize instance.

        Inherited Parameters:
            tymist is  Tymist instance
            tock is float seconds initial value of .tock
            doers is list of doers (do generator instances, functions or methods)

        Parameters:
            router (Router): The Router object for managing routes.
            src (Str): qb64 identifier prefix of data source
            client is TCP Client instance
            exc is Exchanger instance of local controller's TEL context

        """
        self.router = router
        self.src = src
        self.reps = decking.Deck()

        self.client = client  # use client for both rx and tx
        self.exc = exc
        doers = doers if doers is not None else []
        doers.extend([doing.doify(self.msgDo),
                      doing.doify(self.repsDo),
                      doing.doify(self.escrowDo),
                      doing.doify(self.reconnectDo),
                      doing.doify(self.cueDo)])

        self.parser = parsing.Parser(ims=self.client.rxbs,
                                     framed=True,
                                     exc=self.exc)

        super(Reactor, self).__init__(doers=doers, **kwa)
        if self.tymth:
            self.client.wind(self.tymth)

    def wind(self, tymth):
        """
        Inject new tymist.tymth as new ._tymth. Changes tymist.tyme base.
        Updates winds .tymer .tymth
        """
        super(Reactor, self).wind(tymth)
        self.client.wind(tymth)

    def reconnectDo(self, tymth=None, tock=0.0, **kwa):
        # start enter context
        self.wind(tymth)
        self.tock = tock
        yield self.tock

        while True:
            if not self.client.connected or (self.client.connected and self.client.cutoff):
                self.client.reopen()
            yield 0.5

    def repsDo(self, tymth=None, tock=0.0, **kwa):
        self.wind(tymth)
        self.tock = tock
        yield self.tock

        while True:
            while self.reps:
                rep = self.reps.pull()
                serder = rep["serder"]
                atc = rep["atc"]
                ims = bytearray(serder.raw)
                ims.extend((bytes(atc)))

                self.sendMessage(ims, label="response protocol messages")

            yield self.tock

    def msgDo(self, tymth=None, tock=0.0, **kwa):
        """
        Returns doifiable Doist compatibile generator method (doer dog) to process
            incoming message stream of .kevery

        Doist Injected Attributes:
            g.tock = tock  # default tock attributes
            g.done = None  # default done state
            g.opts

        Parameters:
            tymth is injected function wrapper closure returned by .tymen() of
                Tymist instance. Calling tymth() returns associated Tymist .tyme.
            tock is injected initial tock value
            opts is dict of injected optional additional parameters


        Usage:
            add result of doify on this method to doers list
        """
        # start enter context
        self.wind(tymth)
        self.tock = tock
        yield self.tock

        done = yield from self.parser.parsator(local=True)  # process messages continuously
        return done  # should nover get here except forced close

    def cueDo(self, tymth=None, tock=0.0, **kwa):
        """
         Returns doifiable Doist compatibile generator method (doer dog) to process
            .kevery.cues deque

        Doist Injected Attributes:
            g.tock = tock  # default tock attributes
            g.done = None  # default done state
            g.opts

        Parameters:
            tymth is injected function wrapper closure returned by .tymen() of
                Tymist instance. Calling tymth() returns associated Tymist .tyme.
            tock is injected initial tock value
            opts is dict of injected optional additional parameters

        Usage:
            add result of doify on this method to doers list
        """
        # start enter context
        self.wind(tymth)
        self.tock = tock
        yield self.tock

        while True:
            while self.exc.cues:
                cue = self.exc.cues.pull()
                said = cue["said"]
                logger.info(f"tcp client cue received for evt={said}")
            yield  # throttle just do one cue at a time

    def escrowDo(self, tymth=None, tock=0.0, **kwa):
        """
         Returns doifiable Doist compatibile generator method (doer dog) to process
            .kevery escrows.

        Doist Injected Attributes:
            g.tock = tock  # default tock attributes
            g.done = None  # default done state
            g.opts

        Parameters:
            tymth is injected function wrapper closure returned by .tymen() of
                Tymist instance. Calling tymth() returns associated Tymist .tyme.
            tock is injected initial tock value
            opts is dict of injected optional additional parameters

        Usage:
            add result of doify on this method to doers list
        """
        # start enter context
        self.wind(tymth)
        self.tock = tock
        yield self.tock

        while True:
            self.exc.processEscrow()
            yield

    def sendMessage(self, msg, label=""):
        """
        Sends message msg and loggers label if any
        """
        self.client.tx(msg)  # send to remote
        hab = self.router.hab(self.src)
        logger.info("%s sent %s: %s", hab.name, label, len(msg))


class TcpRemoteProc(doing.DoDoer):
    """
    Remote Gateways in RACK admin can come from OOBIs from other gateways that are direct connections to the other
    gateway or are OOBIs with an end role of gateway pointing to healthKERI.net, using a non-transferable AID

    This proc acts like server even though it is a client that connects to its remote gateway and sends a SYN announcing
    its src and dest.
    """

    def __init__(self, router, host, port, src, dest, params):
        """
        Initialize a TCP Remote Proc instance that provides remote connectivity between gateways.

        Args:
            router (Router): The router for handling message routes
            host (str): Hostname/IP of the remote gateway
            port (int): Port number of the remote gateway
            src (str): The source identifier prefix (qb64)
            dest (str): The destination identifier prefix (qb64)
            params (dict): Additional parameters for message handling

        The proc establishes a TCP client connection with a remote gateway and handles:
        - Connection management and auto-reconnection
        - Bidirectional message forwarding between src and dest identifiers
        - Protocol message processing via Director and Reactor components
        - Message queuing and acknowledgements
        """

        self.router = router
        self.hby = self.router.hby
        self.src = src
        self.dest = dest

        self.params = params

        self.client = TcpClient(host=host, port=port, reconnectable=True)
        self.director = Director(router=router, src=src, dest=dest, client=self.client)

        ack = AckHandler(hby=self.hby)
        self.fwd = ForwardHandler(hby=self.hby)
        exc = exchanging.Exchanger(hby=self.hby, handlers=[ack, self.fwd])
        reactor = Reactor(router=router, src=src, client=self.client, exc=exc)

        doers = [TcpClientDoer(client=self.client), self.director, reactor]

        super(TcpRemoteProc, self).__init__(doers=doers)

    @property
    def inbound(self):
        return self.director.msgs

    @property
    def outbound(self):
        return self.fwd.cues


    def service(self):
        """"""
        pass

    def close(self):
        """"""
        pass



class AckHandler:
    """
    Handler for acknowledgement `exn` messages used to ack the reply of other exns

    on
        {
           "v": "KERI10JSON00011c_",                               // KERI Version String
           "t": "exn",                                             // peer to peer message ilk
           "dt": "2020-08-22T17:50:12.988921+00:00"
           "r": "/ack",
           "q": {
              "pre": "EEBp64Aw2rsjdJpAR0e2qCq3jX7q7gLld3LjAwZgaLXU",
              "topic": "delegate"
            }
           "a": {},
           "p": "ECgaLXUw2rsjdJpAR0e2qCq3jX7q7gLld3LjAwZBp64A"
        }-AABAA1o61PgMhwhi89FES_vwYeSbbWnVuELV_jv7Yv6f5zNiOLnj1ZZa4MW2c6Z_vZDt55QUnLaiaikE-d_ApsFEgCA

    """

    resource = "/ack"

    def __init__(self, hby, cues=None, params=None):
        """

        Parameters:
            hby (Habery): database environment
            cues (Deck): message storage for store and forward

        """
        self.hby = hby
        self.cues = cues if cues is not None else decking.Deck()
        self.params = params or {}

    @staticmethod
    def handle(serder, attachments=None):
        """  Do route specific processsing of IPEX protocol exn messages

        Parameters:
            serder (Serder): Serder of the IPEX protocol exn message
            attachments (list): list of tuples of root pathers and CESR SAD path attachments to the exn event

        """

        said = serder.ked['d']
        dig = serder.ked['p']

        logger.info(f"ack={said} received for exn message {dig}")


class ForwardHandler:
    """
    Handler for forward `exn` messages used to envelope other KERI messages intended for another recipient.
    This handler acts as a mailbox for other identifiers and stores the messages in a local database.

    on
        {
           "v": "KERI10JSON00011c_",                               // KERI Version String
           "t": "exn",                                             // peer to peer message ilk
           "dt": "2020-08-22T17:50:12.988921+00:00"
           "r": "/fwd",
           "q": {
              "pre": "EEBp64Aw2rsjdJpAR0e2qCq3jX7q7gLld3LjAwZgaLXU",
              "topic": "delegate"
            }
           "a": '{
              "v":"KERI10JSON000154_",
              "t":"dip",
              "d":"Er4bHXd4piEtsQat1mquwsNZXItvuoj_auCUyICmwyXI",
              "i":"Er4bHXd4piEtsQat1mquwsNZXItvuoj_auCUyICmwyXI",
              "s":"0",
              "kt":"1",
              "k":["DuK1x8ydpucu3480Jpd1XBfjnCwb3dZ3x5b1CJmuUphA"],
              "n":"EWWkjZkZDXF74O2bOQ4H5hu4nXDlKg2m4CBEBkUxibiU",
              "bt":"0",
              "b":[],
              "c":[],
              "a":[],
              "di":"Et78eYkh8A3H9w6Q87EC5OcijiVEJT8KyNtEGdpPVWV8"
           }
        }-AABAA1o61PgMhwhi89FES_vwYeSbbWnVuELV_jv7Yv6f5zNiOLnj1ZZa4MW2c6Z_vZDt55QUnLaiaikE-d_ApsFEgCA

    """

    resource = "/fwd"

    def __init__(self, hby, cues=None, params=None):
        """

        Parameters:
            hby (Habery): database environment
            cues (Deck): message storage for store and forward

        """
        self.hby = hby
        self.cues = cues if cues is not None else decking.Deck()
        self.params = params or {}

    def handle(self, serder, attachments=None):
        """  Do route specific processsing of IPEX protocol exn messages

        Parameters:
            serder (Serder): Serder of the IPEX protocol exn message
            attachments (list): list of tuples of root pathers and CESR SAD path attachments to the exn event

        """
        embeds = serder.ked['e']
        if attachments:
            payload = dict()
            for pather, atc in attachments:
                sad = pather.resolve(embeds)
                payload["serder"] = sad
                payload["atc"] = atc.decode("utf-8")
        else:
            payload = serder.ked['a']

        src = serder.ked['a']["src"]
        dest = serder.ked["a"]["dest"]

        logger.info(f"Message from {src} to {dest}")

        cue = dict(i=Procs.tcpremote, src=src, dest=dest, c=self.params, a=payload)
        self.cues.append(cue)

        self.hby.db.epath.rem(keys=(serder.said,))

