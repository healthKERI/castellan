# -*- encoding: utf-8 -*-
"""
rack.proc.mllp.clienting module

MLLP (Minimal Lower Layer Protocol) client implementation
"""
import math

from hio.base import doing
from hio.help import decking
from keri import help, core
from keri.core import serdering, counting, coring
from keri.kering import Ilks, Schemes, Vrsn_1_0
from keri.peer import exchanging
from prometheus_client import Histogram

from rack.core import profiling, tcp
from rack.core.scheming import Procs
from rack.proc.essr.encoding import CHUNK_SIZE

logger = help.ogler.getLogger()

REQUEST_TIME = Histogram('rack_mllp_request_duration_seconds', 'MLLP Client request duration in seconds',
                         ['src', 'host', 'port'])
REMOTE_REQUEST_TIME = Histogram('rack_mllp_remote_request_duration_seconds',
                                'MLLP Client remote request duration in seconds',
                                ['src', 'host', 'port'])
REQUEST_SIZE = Histogram('rack_mllp_request_size_bytes', 'ESSR encoded size in bytes',
                         ['src', 'host', 'port'],
                         buckets=profiling.SIZE_BUCKETS)
RESPONSE_SIZE = Histogram('rack_mllp_response_size_bytes',
                          'MLLP response size in bytes', ['src', 'host', 'port'],
                          buckets=profiling.SIZE_BUCKETS)

# MLLP Protocol Constants
SOB = b'\x0B'  # Start of Block (Vertical Tab)
EOD = b'\x1C'  # End of Data (File Separator)
EOB = b'\x0D'  # End of Block (Carriage Return)


class MLLPDirector:
    """MLLP Client Director for managing connections and message processing"""

    def __init__(self, router, clientary, name, src, dests, scheme=Schemes.http, params=None):
        """
        Initialize MLLP Director

        Parameters:
            router (Router): The Router object for managing routes
            clientary (tcp.Clientary): TCP client manager
            name (str): Name of the director
            src (str): qb64 identifier prefix of data source
            dests (list): List of destination tuples (aid, address, port)
            scheme (Schemes): Protocol scheme
            params (dict): Additional parameters
        """
        self.name = name
        self.router = router
        self.clientary = clientary
        self.hby = self.router.hby
        self.src = src
        self.dests = {(address, port): aid for (aid, address, port) in dests}
        self.scheme = scheme
        self.clients = {}
        self.ctxs = {}

        self.cues = decking.Deck()
        self.msgs = decking.Deck()
        self.reqs = decking.Deck()

        self.params = params if params is not None else dict()

        # Buffer for partial MLLP messages
        self.response_buffers = {}

    def parse(self, msg):
        """Decodes a message and processes it if it is valid.

        Parameters:
            msg (dict): The message to decode.

        Raises:
            ValueError: If the message or event is invalid.
        """
        ctx = msg.get("ctx", {})
        payload = msg['a']
        sad = payload.get('message', {})

        serder = serdering.SerderKERI(sad=sad)
        if serder.ilk != Ilks.exn or serder.ked['r'] != "/mllp/msg" or serder.ked['a'] is None:
            raise ValueError(f"invalid event (route={serder.ked['r']}) to mllp proc={serder.ked}")

        logger.info(f"MLLP client parsing {serder.ked['r']} message.")
        self.ctxs[serder.said] = ctx
        atc = bytearray(payload['atc'].encode("utf-8"))

        body = bytearray()
        if atc:
            counter = counting.Counter(qb64b=atc, strip=True)
            for _ in range(counter.count):
                body.extend(core.Texter(qb64b=atc, strip=True).raw)

        self.reqs.append((serder.ked, body))

    def processMsgs(self):
        """Processes all messages in the deck.

        Decodes each message and logs any errors that occur during decoding.
        """
        while self.msgs:
            msg = self.msgs.pull()
            try:
                self.parse(msg)
            except Exception as e:
                logger.error(f"error={e} parsing exn /mllp/msg msg={msg}")

    def tcpclient(self, address, port):
        """Get or create TCP client for address:port

        Parameters:
            address (str): Target address
            port (int): Target port

        Returns:
            tcp.Client: TCP client instance
        """
        if (client := self.clients.get((address, port))) is None:
            logger.info(f"creating MLLP client for {address}:{port}")
            client = self.clientary.connect(address, port)
            self.clients[(address, port)] = client
            self.response_buffers[(address, port)] = bytearray()

        return client

    def processReqs(self):
        """Process MLLP message requests"""
        while self.reqs:
            (ked, body) = self.reqs.pull()
            try:
                said = ked['d']
                ctx = self.ctxs.get(said, {})
                if said in self.ctxs:
                    del self.ctxs[said]

                # For MLLP, we need to determine the destination
                # This could be configured in params or derived from message content
                destinations = list(self.dests.keys())
                if not destinations:
                    logger.error("No MLLP destinations configured")
                    continue
                    
                # Use first destination for now - could be enhanced with routing logic
                address, port = destinations[0]
                self.ctxs[(address, port)] = ctx
                
                client = self.tcpclient(address, port)
                
                # Wrap message in MLLP format
                mllp_message = SOB + body + EOD + EOB
                client.tx(mllp_message)

                logger.info(f"MLLP Client sent message of {len(body)} bytes to {address}:{port}")

            except Exception as e:
                logger.error(f"error={e} when executing mllp req")

    def processResponses(self):
        """Process MLLP responses from servers"""
        for (address, port), client in list(self.clients.items()):
            if client.rxbs:
                data = bytes(client.rxbs)
                del client.rxbs[:]
                
                # Add to response buffer
                buffer = self.response_buffers[(address, port)]
                buffer.extend(data)
                
                # Process complete MLLP messages from buffer
                self.processResponseBuffer(address, port, buffer)

    def processResponseBuffer(self, address, port, buffer):
        """Process response buffer for complete MLLP messages
        
        Parameters:
            address (str): Server address
            port (int): Server port
            buffer (bytearray): Response buffer
        """
        while True:
            message = self.extractMLLPMessage(buffer)
            if message is None:
                break
                
            self.forwardResponse(address, port, message)

    def extractMLLPMessage(self, buffer):
        """Extract a complete MLLP message from buffer
        
        Parameters:
            buffer (bytearray): Buffer containing potential MLLP messages
            
        Returns:
            bytes: Complete MLLP message data or None if incomplete
        """
        if len(buffer) < 3:  # Minimum: SOB + 1 byte + EOD + EOB
            return None

        # Find start of block
        sob_idx = buffer.find(SOB)
        if sob_idx == -1:
            return None

        # Remove any data before SOB
        if sob_idx > 0:
            del buffer[:sob_idx]

        # Find end sequence (EOD + EOB)
        end_sequence = EOD + EOB
        end_idx = buffer.find(end_sequence)
        if end_idx == -1:
            return None

        # Extract message data (excluding SOB, EOD, EOB)
        message_data = bytes(buffer[1:end_idx])
        
        # Remove processed message from buffer
        del buffer[:end_idx + 2]
        
        return message_data

    def forwardResponse(self, address, port, message_data):
        """Forward MLLP response message
        
        Parameters:
            address (str): Server address
            port (int): Server port
            message_data (bytes): Response message data
        """
        try:
            ctx = self.ctxs.get((address, port), {})

            dig = core.Diger(ser=message_data, code=core.MtrDex.Blake3_256).qb64
            payload = dict(
                body=dig,
                address=address,
                port=port,
                timestamp=help.nowIso8601(),
            )

            ims = bytearray()
            size = len(message_data)
            chunks = math.ceil(size / CHUNK_SIZE)
            if chunks:
                ims.extend(
                    counting.Counter(code=counting.CtrDex_1_0.ESSRPayloadGroup, count=chunks, gvrsn=Vrsn_1_0).qb64b)
                for idx in range(chunks):
                    start = idx * CHUNK_SIZE
                    end = start + CHUNK_SIZE
                    texter = coring.Matter(raw=message_data[start:end], code=coring.MtrDex.Bytes_L0)
                    ims.extend(texter.qb64b)

            dest = self.dests[(address, port)]
            hab = self.router.hab(self.src)

            exn, _ = exchanging.exchange(route="/mllp/rep",
                                       payload=payload,
                                       sender=hab.pre)

            cue = dict(i=Procs.mllp, c={}, src=self.src, dest=dest, ctx=ctx,
                       a=dict(message=exn.ked, atc=ims.decode("utf-8")))
            self.cues.append(cue)

            hab.db.essrs.rem(keys=(exn.said,))
            hab.db.epath.rem(keys=(exn.said,))

            logger.info(f"MLLP Client forwarded response of {len(message_data)} bytes from {address}:{port}")

        except Exception as e:
            logger.error(f"Error forwarding MLLP response: {e}")

    def service(self):
        """Services the Director by processing messages and escrows."""
        self.processMsgs()
        self.processReqs()
        self.processResponses()

    def close(self):
        """Close the director and clean up resources"""
        self.msgs.clear()
        self.cues.clear()
        self.clients.clear()
        self.ctxs.clear()
        self.response_buffers.clear()


class MLLPDirectorDoer(doing.Doer):
    """
    MLLP Director Doer

    See Doer for inherited attributes, properties, and methods.
    """

    def __init__(self, director, **kwa):
        """
        Initialize

        Parameters:
           director (MLLPDirector): MLLP Director instance
        """
        super(MLLPDirectorDoer, self).__init__(**kwa)
        self.director = director

    def recur(self, tyme):
        """Service the director"""
        self.director.service()

    def exit(self):
        """Close the director"""
        self.director.close()


class MLLPProc:
    """MLLP Client Processor"""
    
    def __init__(self, router, name, src, dests):
        """
        Initialize MLLP Processor

        Parameters:
            router (Router): The Router object for managing routes
            name (str): Name of the processor
            src (str): qb64 identifier prefix of data source
            dests (list): List of destination tuples (aid, address, port)
        """
        self.router = router
        self.hby = self.router.hby
        self.clientary = tcp.Clientary()
        self.director = MLLPDirector(router=router, name=name, src=src, dests=dests, clientary=self.clientary)

        self.doers = [self.clientary]

    @property
    def inbound(self):
        return self.director.msgs

    @property
    def outbound(self):
        return self.director.cues

    def service(self):
        """Service the processor"""
        self.director.service()

    def close(self):
        """Close the processor"""
        self.director.close()


def extract_message_id(hl7_string):
    """
    Extract the message control ID from an HL7 message string.

    Args:
        hl7_string (str): The HL7 message as a string

    Returns:
        str: The message control ID (MSH.10) if found, None otherwise

    Raises:
        ValidationError: If the HL7 message is invalid
        ParserError: If parsing fails
    """
    try:
        # Parse the HL7 message - need to determine message type first
        lines = hl7_string.strip().split('\n')
        if not lines:
            return None

        # Get MSH segment
        msh_line = lines[0]
        if not msh_line.startswith('MSH'):
            return None

        # Parse MSH fields
        fields = msh_line.split('|')
        if len(fields) < 10:
            return None

        # MSH.10 is the 10th field (0-indexed would be 9)
        message_control_id = fields[9]

        return message_control_id if message_control_id else None

    except Exception as e:
        raise e


def extract_message_id_safe(hl7_string):
    """
    Safely extract the message control ID from an HL7 message string.

    Args:
        hl7_string (str): The HL7 message as a string

    Returns:
        tuple: (message_id, error_message) where message_id is the ID if found,
               and error_message is the error description if extraction failed
    """
    try:
        message_id = extract_message_id(hl7_string)
        return message_id
    except Exception as e:
        return None
