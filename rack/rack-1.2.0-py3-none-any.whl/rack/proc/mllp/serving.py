# -*- encoding: utf-8 -*-
"""
rack.proc.mllp.serving module

MLLP (Minimal Lower Layer Protocol) server implementation
"""
import math
import struct

from hio.base import doing
from hio.core import tcp
from hio.help import decking
from keri import help, core
from keri.core import serdering, counting, coring
from keri.kering import Ilks, Vrsn_1_0
from keri.peer import exchanging
from prometheus_client import Counter

from rack.core import pinging
from rack.core.scheming import Procs
from rack.proc.essr.encoding import CHUNK_SIZE

logger = help.ogler.getLogger()

REQUESTS = Counter('rack_mllpsrv_request_duration_seconds', 'TCP MLLP server request duration in seconds',
                   ['src', 'dest'])

# MLLP Protocol Constants
SOB = b'\x0B'  # Start of Block (Vertical Tab)
EOD = b'\x1C'  # End of Data (File Separator)  
EOB = b'\x0D'  # End of Block (Carriage Return)


class MLLPDirectant(doing.DoDoer):
    """
    MLLPDirectant class with MLLP TCP Server.
    Responds to initiated MLLP connections from remote clients by creating and
    running a MLLPReactant per connection. Each MLLPReactant handles MLLP message parsing.
    """

    def __init__(self, router, src, server, msgs=None, cues=None, doers=None, **kwa):
        """
        Initialize instance.

        Parameters:
            router (Router): The Router object for managing routes
            src (str): qb64 identifier prefix of data source
            server (tcp.Server): TCP Server instance
            msgs (Deck): inbound message storage
            cues (Deck): outbound message storage
        """
        self.router = router
        self.src = src
        self.msgs = msgs if msgs is not None else decking.Deck()
        self.cues = cues if cues is not None else decking.Deck()

        self.server = server
        self.rants = dict()

        doers = doers if doers is not None else []
        doers.extend([doing.doify(self.serviceDo)])
        super(MLLPDirectant, self).__init__(doers=doers, **kwa)
        if self.tymth:
            self.server.wind(self.tymth)

    def wind(self, tymth):
        """
        Inject new tymist.tymth as new ._tymth. Changes tymist.tyme base.
        Updates winds .tymer .tymth
        """
        super(MLLPDirectant, self).wind(tymth)
        self.server.wind(tymth)

    def serviceDo(self, tymth=None, tock=0.0, **kwa):
        """Process incoming connections in a Do loop by provisioning a MLLPReactant for each connection

        Parameters:
            tymth (Tymyth): Timer object
            tock (float): Pause time until the scheduler processes this loop again

        Returns:
            Never
        """
        self.wind(tymth)
        self.tock = tock
        yield self.tock

        while True:
            for ca, ix in list(self.server.ixes.items()):
                if ix.cutoff:
                    self.closeConnection(ca)
                    continue

                if ca not in self.rants:
                    rant = MLLPReactant(tymth=self.tymth, router=self.router, src=self.src,
                                        msgs=self.msgs, cues=self.cues, remoter=ix)
                    self.rants[ca] = rant
                    self.extend(doers=[rant])

                if ix.tymeout > 0.0 and ix.tymer.expired:
                    self.closeConnection(ca)

            yield

    def closeConnection(self, ca):
        """
        Close and remove connection given by ca and remove associated rant at ca.
        """
        if ca in self.server.ixes:
            self.server.ixes[ca].serviceSends()
        self.server.removeIx(ca)
        if ca in self.rants:
            rant = self.rants[ca]
            rant.close()
            self.remove([self.rants[ca]])
            del self.rants[ca]


class MLLPReactant(doing.DoDoer):
    """
    MLLP TCP Reactant DoDoer for handling MLLP message parsing and forwarding
    """

    def __init__(self, router, src, remoter, msgs=None, cues=None, doers=None, **kwa):
        """
        Initialize instance.

        Parameters:
            router (Router): The Router object for managing routes
            src (str): qb64 identifier prefix of data source
            remoter (tcp.Remoter): TCP Remoter instance
            msgs (Deck): inbound message storage
            cues (Deck): outbound message storage
        """
        self.router = router
        self.src = src
        self.cues = cues if cues is not None else decking.Deck()
        self.msgs = msgs if msgs is not None else decking.Deck()

        self.remoter = remoter
        self.buffer = bytearray()

        doers = doers if doers is not None else []
        doers.extend([doing.doify(self.mllpDo), doing.doify(self.msgDo)])

        super(MLLPReactant, self).__init__(doers=doers, **kwa)
        if self.tymth:
            self.remoter.wind(self.tymth)

    def wind(self, tymth):
        """
        Inject new tymist.tymth as new ._tymth. Changes tymist.tyme base.
        Updates winds .tymer .tymth
        """
        super(MLLPReactant, self).wind(tymth)
        self.remoter.wind(tymth)

    def close(self):
        """Close the reactant"""
        pass

    def mllpDo(self, tymth=None, tock=0.0, **opts):
        """Process MLLP messages from TCP connection

        Parameters:
            tymth (Tymyth): Timer object
            tock (float): Pause time until the scheduler processes this loop again

        Returns:
            Never
        """
        self.wind(tymth)
        self.tock = tock
        yield self.tock

        while True:
            if self.remoter.rxbs:
                data = bytes(self.remoter.rxbs)
                del self.remoter.rxbs[:]
                self.buffer.extend(data)
                
                self.processBuffer()

            yield self.tock

    def processBuffer(self):
        """Process buffer for complete MLLP messages"""
        while True:
            message = self.extractMLLPMessage()
            if message is None:
                break
                
            self.forwardMessage(message)

    def extractMLLPMessage(self):
        """Extract a complete MLLP message from buffer
        
        Returns:
            bytes: Complete MLLP message data or None if incomplete
        """
        if len(self.buffer) < 3:  # Minimum: SOB + 1 byte + EOD + EOB
            return None

        # Find start of block
        sob_idx = self.buffer.find(SOB)
        if sob_idx == -1:
            return None

        # Remove any data before SOB
        if sob_idx > 0:
            del self.buffer[:sob_idx]

        # Find end sequence (EOD + EOB)
        end_sequence = EOD + EOB
        end_idx = self.buffer.find(end_sequence)
        if end_idx == -1:
            return None

        # Extract message data (excluding SOB, EOD, EOB)
        message_data = bytes(self.buffer[1:end_idx])
        
        # Remove processed message from buffer
        del self.buffer[:end_idx + 2]
        
        return message_data

    def forwardMessage(self, message_data):
        """Forward MLLP message as /mllp/msg exn message
        
        Parameters:
            message_data (bytes): The MLLP message payload
        """
        try:
            # Create digest of message data
            dig = core.Diger(ser=message_data, code=core.MtrDex.Blake3_256).qb64
            
            payload = dict(
                body=dig,
                timestamp=help.nowIso8601(),
            )

            hab = self.router.hab(self.src)

            exn, _ = exchanging.exchange(route="/mllp/msg",
                                         payload=payload,
                                         sender=hab.pre)
            ims = bytearray()
            size = len(message_data)
            chunks = math.ceil(size / CHUNK_SIZE)
            if chunks:
                ims.extend(
                    counting.Counter(code=counting.CtrDex_1_0.ESSRPayloadGroup, count=chunks, gvrsn=Vrsn_1_0).qb64b)
                for idx in range(chunks):
                    start = idx * CHUNK_SIZE
                    end = start + CHUNK_SIZE
                    texter = coring.Matter(raw=message_data[start:end], code=coring.MtrDex.Bytes_L0)
                    ims.extend(texter.qb64b)

            cue = dict(i=Procs.mllpsrv, c={}, a=dict(message=exn.ked, atc=ims.decode("utf-8")))
            self.cues.append(cue)

            hab.db.essrs.rem(keys=(exn.said,))
            hab.db.epath.rem(keys=(exn.said,))

            logger.info(f"MLLP Server forwarded message of {len(message_data)} bytes")

        except Exception as e:
            logger.error(f"Error forwarding MLLP message: {e}")


    def msgDo(self, tymth=None, tock=0.0, **opts):
        """Process MLLP messages from TCP connection

        Parameters:
            tymth (Tymyth): Timer object
            tock (float): Pause time until the scheduler processes this loop again

        Returns:
            Never
        """
        self.wind(tymth)
        self.tock = tock
        yield self.tock

        while True:
            while self.msgs:
                msg = self.msgs.popleft()
                payload = msg['a']
                atc = bytearray(payload['atc'].encode("utf-8"))

                body = bytearray()
                if atc:
                    counter = counting.Counter(qb64b=atc, strip=True)
                    for _ in range(counter.count):
                        body.extend(core.Texter(qb64b=atc, strip=True).raw)

                mllp_message = SOB + body + EOD + EOB
                self.remoter.tx(mllp_message)

                yield self.tock

            yield self.tock



class MLLPSrvProc:
    """MLLP Server Processor"""
    
    def __init__(self, router, name, host, port, src, params):
        """
        Initialize MLLP Server Processor

        Parameters:
            router (Router): The Router object for managing routes
            name (str): Name of the processor
            host (str): Host to bind server to
            port (int): Port to bind server to  
            src (str): qb64 identifier prefix of data source
            params (dict): Additional parameters
        """
        self.router = router
        self.hby = self.router.hby
        self.name = name
        self.src = src
        self.msgs = decking.Deck()
        self.cues = decking.Deck()

        self.host = host
        self.port = port
        self.params = params

        logger.info(f"Starting MLLP Server on {host}:{port}")
        self.server = tcp.Server(host=host, port=port)

        if not self.server.reopen():
            raise RuntimeError(f"cannot create tcp server on port {port}")

        self.directant = MLLPDirectant(router=router, src=src, server=self.server,
                                       msgs=self.msgs, cues=self.cues)

        self.doers = [self.directant, tcp.ServerDoer(server=self.server)]

    @property
    def inbound(self):
        return self.msgs

    @property
    def outbound(self):
        return self.cues

    def service(self):
        """Service the processor"""
        pass

    def close(self):
        """Close the processor"""
        pass


class MLLPSrvProcDoer(doing.DoDoer):
    """
    MLLP Server Processor Doer

    See Doer for inherited attributes, properties, and methods.
    """

    def __init__(self, mllpsrv, **kwa):
        """
        Initialize

        Parameters:
           mllpsrv (MLLPSrvProc): MLLP Server Processor instance
        """
        super(MLLPSrvProcDoer, self).__init__(doers=mllpsrv.doers, **kwa)
