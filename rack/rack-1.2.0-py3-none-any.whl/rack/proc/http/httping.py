# -*- encoding: utf-8 -*-
"""
rack.proc.http.httping module

"""
import math

from keri import core
from keri.core import counting, coring
from keri.kering import Vrsn_1_0

CHUNK_SIZE = 65536

def http_request(scheme, method, host, port, path="/", raw=b'', query_string="", remote_addr="",
                 headers=None, content_type="text/html", content_length=None, reqid=""):

    headers = headers if headers is not None else dict()

    if raw:
        dig = core.Diger(ser=raw, code=core.MtrDex.Blake3_256).qb64
    else:
        dig = ""

    payload = dict(
        scheme=scheme,
        method=method,
        host=host,
        port=port,
        path=path,
        query=query_string,
        remote=remote_addr,
        headers=headers,
        contentType=content_type,
        body=dig,
        reqid=reqid,
    )

    if content_length is not None:
        payload["contentLength"] = content_length

    ims = bytearray()
    size = len(raw)
    chunks = math.ceil(size / CHUNK_SIZE)
    if chunks:
        ims.extend(counting.Counter(code=counting.CtrDex_1_0.ESSRPayloadGroup, count=chunks, gvrsn=Vrsn_1_0).qb64b)
        for idx in range(chunks):
            start = idx * CHUNK_SIZE
            end = start + CHUNK_SIZE
            texter = coring.Matter(raw=raw[start:end], code=coring.MtrDex.Bytes_L0)
            ims.extend(texter.qb64b)

    return dict(r="/http/req", request=payload, atc=ims.decode("utf-8"))


def http_response(status, reason, remote_request_time, headers=None, raw=b'', reqid=""):
    headers = headers if headers is not None else dict()
    if raw:
        dig = core.Diger(ser=raw, code=core.MtrDex.Blake3_256).qb64
    else:
        dig = ""

    data = dict(
        version="HTTP 1.1",
        status=status,
        reason=reason,
        response_time=remote_request_time,
        headers={k.lower(): v for (k, v) in headers.items()},
        body=dig
    )

    ims = bytearray()
    size = len(raw)
    chunks = math.ceil(size / CHUNK_SIZE)
    if chunks:
        ims.extend(counting.Counter(code=counting.CtrDex_1_0.ESSRPayloadGroup, count=chunks, gvrsn=Vrsn_1_0).qb64b)
        for idx in range(chunks):
            start = idx * CHUNK_SIZE
            end = start + CHUNK_SIZE
            texter = coring.Matter(raw=raw[start:end], code=coring.MtrDex.Bytes_L0)
            ims.extend(texter.qb64b)

    return dict(r="/http/rep", response=data, atc=ims.decode("utf-8"), reqid=reqid)