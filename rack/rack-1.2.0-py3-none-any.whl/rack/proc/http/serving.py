# -*- encoding: utf-8 -*-
"""
rack.proc.http.serving module

"""
import datetime
import io
import sys
import time

from hio import help
from hio.base import doing
from hio.core import tcp
from hio.core.http import httping, serving
from hio.core.http.serving import Requestant, Server as HttpServer, ServerDoer
from hio.help import decking
from keri import core
from keri.core import coring, counting
from prometheus_client import Histogram

from rack.core import profiling
from rack.core.scheming import Procs
from rack.proc.http.httping import http_request

logger = help.ogler.getLogger()

REQUEST_TIME = Histogram('rack_httpsrv_request_duration_seconds',
                         'HttpSrv request duration in seconds', ['method', 'src', 'host', 'port', 'path'])
REQUEST_SIZE = Histogram('rack_httpsrv_request_size_bytes',
                         'HttpSrv request size in bytes', ['method', 'src', 'host', 'port', 'path'],
                         buckets=profiling.SIZE_BUCKETS)
RESPONSE_SIZE = Histogram('rack_httpsrv_response_size_bytes',
                          'HttpSrv response size in bytes', ['method', 'src', 'host', 'port', 'path'],
                          buckets=profiling.SIZE_BUCKETS)

GATEWAY_TIMEOUT = 3


class Responder:
    """
    Nonblocking HTTP WSGI Responder class

    """
    HttpVersionString = httping.HTTP_11_VERSION_STRING  # http version string
    Delay = 1.0

    def __init__(self,
                 incomer,
                 app,
                 environ,
                 chunkable=False):
        """
        Initialize Instance
        Parameters:
            incomer = incomer connection instance
            app = wsgi app callable
            environ = wsgi environment dict
            chunkable = True if may send body in chunks
        """
        status = "200 OK"  # integer or string with reason, WSGI is string with reason
        self.incomer = incomer
        self.app = app
        self.environ = environ
        self.chunkable = True if chunkable else False
        self.started = False  # True once start called (start_response)
        self.headed = False  # True once headers sent
        self.chunked = False  # True if should send in chunks
        self.ended = False  # True if response body completely sent
        self.closed = False  # True if connection closed by far side
        self.iterator = None  # iterator on application body
        self.status = status
        self.headers = help.Hict()  # headers
        self.length = None  # if content-length provided must not exceed
        self.size = 0  # number of body bytes sent so far
        self.evented = False  # True if response is event-stream

    def close(self):
        """
        Close any resources
        """
        if not self.closed and not self.ended:
            self.write(b'')  # in case chunked send empty chunk to terminate
        self.ended = True
        self.closed = True

    def reset(self, environ, chunkable=None):
        """
        Reset attributes for another request-response
        """
        self.environ = environ

        if self.chunkable is not None:
            self.chunkable = chunkable

        self.started = False
        self.headed = False
        self.chunked = False
        self.ended = False
        self.iterator = None
        self.status = "200 OK"
        self.headers = help.Hict()
        self.length = None
        self.size = 0

    def build(self):
        """
        Return built head bytes from .status and .headers

        """
        lines = []

        _status = getattr(self.iterator, '_status', None)  # if AttributiveGenerator
        if _status is not None:  # override
            self.status = _status

        if isinstance(self.status, int):  # replace int with str
            self.status = "{0} {1}".format(self.status,
                                           httping.STATUS_DESCRIPTIONS[self.status])

        startLine = "{0} {1}".format(self.HttpVersionString, self.status)
        try:
            startLine = startLine.encode('ascii')
        except UnicodeEncodeError:
            startLine = startLine.encode('idna')
        lines.append(startLine)

        # Override if AttributiveGenerator
        self.headers.update(getattr(self.iterator, '_headers', help.Hict()))

        if u'server' not in self.headers:  # create Server header
            self.headers[u'server'] = "Ioflo WSGI Server"

        if u'date' not in self.headers:  # create Date header
            self.headers[u'date'] = httping.httpDate1123(datetime.datetime.now(datetime.UTC))

        if self.chunkable and 'transfer-encoding' not in self.headers:
            self.chunked = True
            self.headers[u'transfer-encoding'] = u'chunked'

        for name, value in self.headers.items():
            lines.append(httping.packHeader(name, value))

        lines.extend((b"", b""))
        head = serving.CRLF.join(lines)  # b'/r/n'

        return head

    def write(self, msg):
        """
        WSGI write callback This writes out the headers the first time its called
        otherwise writes the msg bytes
        """
        if not self.started:
            raise AssertionError("WSGI write() before start_response()")

        if not self.headed:  # head not written yet
            head = self.build()
            self.incomer.tx(head)
            self.headed = True

        if self.chunked:
            msg = httping.packChunk(msg)

        if self.length is not None:  # limit total size to length
            size = self.size + len(msg)
            if size > self.length:
                msg = msg[:self.length - size]
            self.size += len(msg)

        if msg:
            self.incomer.tx(msg)

    def start(self, status, response_headers, exc_info=None):
        """
        WSGI application start_response callable

        Parameters:

        status is string of status code and status reason '200 OK' or simple
            status code int which will be replaced with string

        response_headers is list of tuples of strings of the form (field, value)
                          one tuple for each header example:
                          [
                              ('Content-type', 'text/plain'),
                              ('X-Some-Header', 'value')
                          ]

        exc_info is optional exception info if exception occurred while
                    processing request in wsgi application
                    If exc_info is supplied, and no HTTP headers have been output yet,
                    start_response should replace the currently-stored
                    HTTP response headers with the newly-supplied ones,
                    thus allowing the application to "change its mind" about
                    the output when an error has occurred.

                    However, if exc_info is provided, and the HTTP headers
                    have already been sent, start_response must raise an error,
                    and should re-raise using the exc_info tuple. That is:

                    raise exc_info[1].with_traceback(exc_info[2]) (python3)

        Nonstandard modifiction to allow for iterable/generator of body to change
           headers and status before first write to support async processing of
           responses whose iterator/generator yields empty before first non-empty
           yield.  In .service yielding empty does not cause write so status line
           and headers are not sent until first non-empty write.

           The mode is that the app.headers and app.status are consulted to see
           if changed from when .start = wsgi start_response was first called.
        """
        if exc_info:
            try:
                if self.headed:
                    # Re-raise original exception if headers sent
                    raise exc_info[1].with_traceback(exc_info[2])
            finally:
                pass
        elif self.started:  # may not call start_response again without exc_info
            raise AssertionError("Already started!")

        self.status = status
        self.headers = help.Hict(response_headers)

        if u'content-length' in self.headers:
            self.length = int(self.headers['content-length'])
            self.chunkable = False  # cannot use chunking with finite content-length
        else:
            self.length = None

            if u'content-type' in self.headers:
                if self.headers['content-type'].startswith('text/event-stream'):
                    self.evented = True

        self.started = True
        return self.write

    def service(self):
        """
        Service wsgi compatible application
        """
        if not self.closed and not self.ended:
            if self.iterator is None:  # initiate application
                self.iterator = iter(self.app(self.environ,
                                              start_response=self.start))
            try:
                msg = next(self.iterator)
            except StopIteration as ex:
                if hasattr(ex, "value") and ex.value:
                    self.write(ex.value)  # new style generators in python3.3+
                self.write(b'')  # in case chunked send empty chunk to terminate
                self.ended = True
            except httping.HTTPError as ex:
                if not self.headed:
                    headers = help.Hict()
                    headers.update(ex.headers.items())
                    if 'content-type' not in headers:
                        headers['content-type'] = 'text/plain'
                    msg = ex.render()
                    headers['content-length'] = str(len(msg))
                    # WSGI status is string of status code and reason
                    status = "{} {}".format(ex.status, ex.reason)
                    self.start(status, headers.items(), sys.exc_info())
                    self.write(msg)
                    self.ended = True
                else:
                    logger.error("HTTPError streaming body after headers sent.\n"
                                 "%s\n", ex)
            except Exception as ex:  # handle http exceptions not caught by app
                logger.error("Unexcepted Server Error.\n%s\n", ex)
            else:
                if msg:  # only write if not empty allows async processing
                    self.write(msg)
                    if self.length is not None and self.size >= self.length:
                        self.ended = True


class Server:
    """
    Server WSGI HTTP Server Class
    """
    Tymeout = 5.0  # default tcp server connection tymeout

    def __init__(self,
                 name="hio.wsgi.server",
                 app=None,
                 reqs=None,
                 reps=None,
                 servant=None,
                 bufsize=8096,
                 wl=None,
                 ha=None,
                 host=u'',
                 port=None,
                 eha=None,
                 scheme=u'',
                 tymeout=None,
                 **kwa):
        """
        Initialization method for instance.

        Parameters:
            name is wsgi server name
            app is wsgi application callable
            reqs is dict of Requestant instances keyed by ca
            reps is dict of running Wsgi Responder instances keyed by ca
            servant is instance of Server or ServerTls or None

            bufsize is buffer size for servant
            wl is WireLog instance if any for servant
            ha is  host address duple (host, port) for local servant listen socket
            host is host address for local servant listen socket,
                '' means any interface on host
            port is socket port for local servant listen socket
            eha is external destination address for servant
                for incoming connections used in TLS
            scheme is http scheme u'http' or u'https' or empty
                for servant and WSGI environment
            kwa needed to pass additional parameters to servant
            tymeout is tymeout in seconds for dropping idle connections

        Attributes:
            .app is wsgi application callable
            .reqs is dict of Requestant instances keyed by ca
            .reps is dict of running Wsgi Responder instances keyed by ca
            .servant is instance of Server or ServerTls or None
            .tymeout is tymeout in seconds for dropping idle connections
            .scheme is http scheme http or https for servant and environment
            .secured is Boolean true if TLS

        """
        self.name = name
        self.app = app
        self.cues = decking.Deck()
        self.reqs = reqs if reqs is not None else dict()  # allows external view
        self.reqs.clear()  # items should only be assigned by valet
        self.reps = reps if reps is not None else dict()  # allows external view
        self.reps.clear()  # items should only be assigned by valet

        if tymeout is None:
            tymeout = self.Tymeout

        ha = ha or (host, port)  # ha = host address takes precendence over host, port
        if servant:
            if isinstance(servant, tcp.ServerTls):
                if scheme and scheme != u'https':
                    raise ValueError("Provided scheme '{0}' incompatible with servant".format(scheme))
                secured = True
                scheme = u'https'
                defaultPort = 443
            elif isinstance(servant, tcp.Server):  # or isinstance(servant, uxd.Server):
                if scheme and scheme != u'http':
                    raise ValueError("Provided scheme '{0}' incompatible with servant".format(scheme))
                secured = False
                scheme = 'http'
                defaultPort = 80
            else:
                raise ValueError("Invalid servant type {0}".format(type(servant)))
        else:
            scheme = u'https' if scheme == u'https' else u'http'
            if scheme == u'https':
                secured = True  # use tls socket connection
                defaultPort = 443
            else:
                secured = False  # non tls socket connection
                defaultPort = 80

        self.scheme = scheme
        host, port = ha
        port = port or defaultPort  # if port not specified
        ha = (host, port)

        if servant:
            if servant.ha != ha:
                ValueError("Provided ha '{0}:{1}' incompatible with servant".format(ha[0], ha[1]))
            # at some point may want to support changing the ha of provided servant

        else:  # what about timeouts for servant connections
            if secured:
                servant = tcp.ServerTls(ha=ha,
                                        eha=eha,
                                        bufsize=bufsize,
                                        wl=wl,
                                        tymeout=tymeout,
                                        **kwa)
            else:
                servant = tcp.Server(ha=ha,
                                     eha=eha,
                                     bufsize=bufsize,
                                     wl=wl,
                                     tymeout=tymeout,
                                     **kwa)

        self.secured = secured
        self.servant = servant

    def wind(self, tymth):
        """
        Inject new tymist.tymth as new ._tymth. Changes tymist.tyme base.
        Updates winds .tymer .tymth
        """
        if self.servant:
            self.servant.wind(tymth)

    def reopen(self):
        """
        Return result of .servant.reopen()
        """
        return self.servant.reopen()

    def close(self):
        """
        Close all reqs, reps, and ixes

        """
        # start with reqs
        for ca in list(self.reqs.keys()):  # need list as closeConnection deletes
            self.closeConnection(ca)

        # just in case there is an orphan rep
        for ca in list(self.reps.keys()):  # need list as closeConnection deletes
            self.closeConnection(ca)

        # just in case there is an orphan ix
        self.servant.close()

    def idle(self):
        """
        Returns True if no connections have requests in process
        Useful for debugging
        """
        idle = True
        for requestant in self.reqs.values():
            if not requestant.ended:
                idle = False
                break
        if idle:
            for responder in self.reps.values():
                if not responder.ended:
                    idle = False
                    break
        return idle

    def buildEnviron(self, requestant):
        """
        Returns wisgi environment dictionary for supplied requestant
        """
        environ = dict()  # maybe should be mudict for cookies or other repeated headers

        # WSGI variables
        environ['wsgi.version'] = (1, 0)
        environ['wsgi.url_scheme'] = self.scheme
        environ['wsgi.input'] = io.BytesIO(requestant.body)
        environ['wsgi.errors'] = sys.stderr
        environ['wsgi.multithread'] = False
        environ['wsgi.multiprocess'] = False
        environ['wsgi.run_once'] = False
        environ["wsgi.server_name"] = self.name
        environ["wsgi.server_version"] = (1, 0)

        # Required CGI variables
        environ['REQUEST_METHOD'] = requestant.method  # GET
        environ['SERVER_NAME'] = self.servant.eha[0]  # localhost
        environ['SERVER_PORT'] = str(self.servant.eha[1])  # 8888
        environ['SERVER_PROTOCOL'] = "HTTP/{0}.{1}".format(*requestant.version)  # used by request http/1.1
        environ['SCRIPT_NAME'] = u''
        environ['PATH_INFO'] = requestant.path  # /hello?name=john

        # Optional CGI variables
        environ['QUERY_STRING'] = requestant.query  # name=john
        environ['REMOTE_ADDR'] = requestant.remoter.ca
        environ['CONTENT_TYPE'] = requestant.headers.get('content-type', '')
        if requestant.length is not None:
            environ['CONTENT_LENGTH'] = str(requestant.length)

        # recieved http headers mapped to all caps with HTTP_ prepended
        for key, value in requestant.headers.items():
            key = "HTTP_" + key.replace("-", "_").upper()
            environ[key] = value

        return environ

    def closeConnection(self, ca):
        """
        Close and remove connection given by ca
        """
        if ca in self.reqs:
            self.reqs[ca].close()  # this signals request parser
            del self.reqs[ca]
        if ca in self.reps:
            self.reps[ca].close()  # this signals response handler
            if ca in self.servant.ixes:
                self.servant.ixes[ca].serviceSends()  # send final bytes to socket
            del self.reps[ca]
        self.servant.removeIx(ca)

    def serviceConnects(self):
        """
        Service new incoming connections
        Create requestants
        Timeout stale connections
        """
        self.servant.serviceConnects()
        for ca, ix in list(self.servant.ixes.items()):  # ixes changes during iteration
            if ix.cutoff:
                self.closeConnection(ca)
                continue

            if ca not in self.reqs:  # point requestant.msg to incomer.rxbs
                self.reqs[ca] = Requestant(msg=ix.rxbs, remoter=ix)

            if ix.tymeout > 0.0 and ix.tymer.expired:
                self.closeConnection(ca)

    def serviceReqs(self):
        """
        Service pending requestants
        """
        for ca, requestant in list(self.reqs.items()):
            if requestant.parser:
                try:
                    requestant.parse()
                except httping.HTTPException as ex:  # unkown error cause this may be superfluous
                    sys.stderr.write(str(ex))
                    self.closeConnection(ca)
                    continue  # give up on request since shouldn't be here

                if requestant.ended:
                    if requestant.errored:  # parse may swallow error but set .errored and .error
                        sys.stderr.write(requestant.error)
                        self.closeConnection(ca)
                        continue

                    logger.info("Parsed Request: %s %s %s", requestant.method,
                                requestant.path,
                                requestant.version)
                    logger.debug("Headers/Body: %s -- %d", requestant.headers,
                                 len(requestant.body))
                    # create or restart wsgi app responder here
                    environ = self.buildEnviron(requestant)
                    if ca not in self.reps:
                        chunkable = True if requestant.version >= (1, 1) else False
                        responder = Responder(incomer=requestant.remoter,
                                              app=self.app,
                                              environ=environ,
                                              chunkable=chunkable)
                        self.reps[ca] = responder
                    else:  # reuse
                        responder = self.reps[ca]
                        responder.reset(environ=environ)

    def serviceReps(self):
        """
        Service pending responders
        """
        for ca, responder in list(self.reps.items()):
            if responder.closed:
                self.closeConnection(ca)
                continue

            if not responder.ended:
                responder.service()

            if responder.ended:
                requestant = self.reqs[ca]
                if requestant.persisted:
                    if requestant.parser is None:  # reuse
                        requestant.makeParser()  # resets requestant parser
                else:  # not persistent so close and remove requestant and responder
                    ix = self.servant.ixes[ca]
                    if not ix.txbs:  # wait for outgoing txbs to be empty
                        self.closeConnection(ca)

    def service(self):
        """
        Service request response
        """
        self.serviceConnects()
        self.servant.serviceReceivesAllIx()
        self.serviceReqs()
        self.serviceReps()
        self.servant.serviceSendsAllIx()


class MessageParser:

    def __init__(self, router, name, params, msgs=None):
        self.name = name
        self.router = router
        self.msgs = msgs if msgs is not None else decking.Deck()
        self.cues = decking.Deck()

        super(MessageParser, self).__init__()

    def service(self):
        while self.msgs:
            msg = self.msgs.pull()
            try:
                self.parseMessage(msg)
            except Exception as e:
                logger.error(f"error={e} message parser decoding msg={msg}")

    def parseMessage(self, msg):
        payload = msg['a']
        ctx = msg.get("ctx", {})
        route = payload['r']

        match route:
            case "/http/rep":
                rep = payload["response"]
                atc = payload["atc"]
                reqid = payload["reqid"]

                body = bytearray()

                if atc:
                    atc = bytearray(atc.encode("utf-8"))
                    counter = counting.Counter(qb64b=atc, strip=True)
                    for _ in range(counter.count):
                        body.extend(core.Texter(qb64b=atc, strip=True).raw)

                rep['body'] = body

                cue = dict(rep=rep, dig=reqid, ctx=ctx)
                self.cues.append(cue)
            case _:
                logger.error(f"unsupported route={route}")


class HttpSrvProcDoer(doing.DoDoer):
    """ tcpsrc proc doer for running tcp server doer"""

    def __init__(self, httpsrv, **kwa):
        self.httpsrv = httpsrv

        super(HttpSrvProcDoer, self).__init__(doers=httpsrv.doers, **kwa)

    def recur(self, tyme, deeds = None):
        self.httpsrv.service()
        return super(HttpSrvProcDoer, self).recur(tyme, deeds)


class HttpSrvProc:
    """A doer class to handle HTTP server processing.

    Attributes:
        host (str): The host address for the server.
        port (int): The port number for the server.
        params (dict): Additional parameters for processing.
        server (HttpServer): The HTTP server instance.
        cues (decking.Deck): The deck for outbound cues.
    """

    def __init__(self, router, name, src, host, port, params):
        """Initializes the HttpSrvProc with the given host, port, and parameters.

        Args:
            router (Router): The Router object for managing routes.
            src (str): qb64 AID of signer for ourbound exn cues.
            host (str): The host address for the server.
            port (int): The port number for the server.
            params (dict): Additional parameters to configure the host.

        """
        self.router = router
        self.hby = self.router.hby
        self.src = src
        self.cues = decking.Deck()
        self.msgs = decking.Deck()
        self.pings = decking.Deck()

        self.host = host
        self.port = port
        self.params = params

        if "keypath" in params and "certpath" in params and "cafilepath" in params:
            keypath = params["keypath"]
            certpath = params["certpath"]
            cafilepath = params["cafilepath"]
            servant = tcp.ServerTls(certify=False,
                                    keypath=keypath,
                                    certpath=certpath,
                                    cafilepath=cafilepath,
                                    port=port)
            self.server = HttpServer(host=host, port=port, app=self.app, servant=servant)
        else:
            self.server = HttpServer(host=host, port=port, app=self.app)

        self.msgParser = MessageParser(router=self.router, name=name, params=params, msgs=self.msgs)

        self.doers = [ServerDoer(self.server)]


    @property
    def inbound(self) -> decking.Deck:
        return self.msgs

    @property
    def outbound(self) -> decking.Deck:
        return self.cues

    def service(self):
        self.msgParser.service()


    def app(self, environ, start_response):
        """WSGI application to handle incoming HTTP requests and generate appropriate responses.

        Args:
            environ (dict): The WSGI environment dictionary.
            start_response (callable): The WSGI start_response callable.

        Returns:
            list: An empty byte response indicating no content.
        """
        start = time.time()
        hab = self.router.hab(self.src)

        headers = dict()
        for key, val in environ.items():
            if key.startswith("HTTP_"):
                headers[key[5:].replace("_", "-")] = val

        headers['ESSR-SENDER'] = hab.pre

        # externalize the body to an attachment
        raw = environ['wsgi.input'].read()
        size = len(raw)

        path = environ["PATH_INFO"]
        method = environ['REQUEST_METHOD']
        reqid = coring.randomNonce()

        # Must create an exn `/http/req` route
        req = http_request(
            scheme=environ['wsgi.url_scheme'],
            method=method,
            host=self.host,
            port=self.port,
            path=path,
            query_string=environ["QUERY_STRING"],
            remote_addr=environ["REMOTE_ADDR"],
            headers=headers,
            content_type=environ['CONTENT_TYPE'],
            raw=raw,
            reqid=reqid,
        )

        cue = dict(i=Procs.httpsrv, c=self.params, a=req)
        self.cues.append(cue)

        end = time.time() + datetime.timedelta(seconds=GATEWAY_TIMEOUT).seconds
        while time.time() < end:
            if (rep := self.pullResponse(reqid)) is not None:
                headers = rep['headers']
                response = rep['body']

                if "transfer-encoding" in headers and headers["transfer-encoding"] == 'chunked':
                    del headers["transfer-encoding"]
                    headers["content-length"] = len(response)

                start_response(f"{rep['status']} {rep['reason']}",
                               list(headers.items()))
                response_time = time.time() - start

                kwargs = dict(method=method, path=path, src=hab.pre, host=self.host, port=self.port)
                REQUEST_TIME.labels(**kwargs).observe(response_time)
                REQUEST_SIZE.labels(**kwargs).observe(size)
                RESPONSE_SIZE.labels(**kwargs).observe(len(response))

                logger.info(f"httpsrv sending {len(response)} bytes for {reqid}")

                return response

            yield b''

        start_response(f"504 Gateway Timeout",
                       list())
        return b''

    def pullResponse(self, reqid):
        found = None

        for msg in self.msgParser.cues:
            dig = msg['dig']
            if dig == reqid:
                found = msg
                break
        if found:
            rep = found['rep']
            self.msgParser.cues.remove(found)
            return rep

        return None


class PingForwarder(doing.Doer):
    """ This class takes ping exn messages from a Pinger and forwards them out our cues."""

    def __init__(self, params, msgs, cues, tock=10.0):
        self.params = params
        self.msgs = msgs
        self.cues = cues
        super(PingForwarder, self).__init__(tock=tock)

    def recur(self, tyme):
        if self.msgs:
            ping = self.msgs.pull()
            cue = dict(i=Procs.httpsrv, c=self.params, a=ping)
            self.cues.append(cue)
