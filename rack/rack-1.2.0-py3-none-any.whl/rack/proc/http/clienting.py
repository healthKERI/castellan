# -*- encoding: utf-8 -*-
"""
rack.proc.http.clienting module

"""
import time
from urllib.parse import urlencode

from hio.base import doing
from hio.help import decking
from keri import help, core
from keri.app import httping
from keri.core import counting
from keri.kering import Schemes
from prometheus_client import Histogram

from rack.core import profiling
from rack.core.scheming import Procs
from rack.proc.http.httping import http_response

logger = help.ogler.getLogger()

REQUEST_TIME = Histogram('rack_http_request_duration_seconds', 'HTTP Client request duration in seconds',
                         ['method', 'src', 'host', 'port', 'path'])
REMOTE_REQUEST_TIME = Histogram('rack_http_remote_request_duration_seconds',
                                'HTTP Client remote request duration in seconds',
                                ['method', 'src', 'host', 'port', 'path'])
REQUEST_SIZE = Histogram('rack_http_request_size_bytes', 'ESSR encoded size in bytes',
                         ['method', 'src', 'host', 'port', 'path'],
                         buckets=profiling.SIZE_BUCKETS)
RESPONSE_SIZE = Histogram('rack_http_response_size_bytes',
                          'Http response size in bytes', ['method', 'src', 'host', 'port', 'path'],
                          buckets=profiling.SIZE_BUCKETS)


class Director:

    def __init__(self, router, clienter, src, scheme=Schemes.http, host=None, port=None, params=None):
        self.router = router
        self.hby = self.router.hby
        self.src = src
        self.scheme = scheme
        self.host = host
        self.port = port
        self.clienter = clienter
        self.clients = decking.Deck()

        self.cues = decking.Deck()
        self.msgs = decking.Deck()

        self.params = params if params is not None else dict()

    def parse(self, msg):
        """Decodes a message and processes it if it is valid.

        Parameters:
            msg (dict): The message to decode.

        Raises:
            ValueError: If the message or event is invalid.
        """
        ctx = msg.get("ctx", {})

        payload = msg['a']
        route = payload['r']
        match route:
            case "/http/req":
                if "request" not in payload or "atc" not in payload:
                    raise ValueError(f"invalid message to http proc={msg}")

                request = payload['request']
                atc = bytearray(payload['atc'].encode("utf-8"))

                body = bytearray()
                if atc:
                    counter = counting.Counter(qb64b=atc, strip=True)
                    for _ in range(counter.count):
                        body.extend(core.Texter(qb64b=atc, strip=True).raw)

                self.request(request, ctx=ctx, body=body)
            case _:
                raise ValueError(f"invalid message to http proc={msg}")

    def processMsgs(self):
        """Processes all messages in the deck.

        Decodes each message and logs any errors that occur during decoding.
        """
        while self.msgs:
            msg = self.msgs.pull()
            try:
                self.parse(msg)
            except Exception as e:
                logger.error(f"error={e} parsing msg /http/req msg={msg}")

    def request(self, req, ctx, body):
        if self.scheme is not None:
            scheme = self.scheme
        elif "scheme" in req:
            scheme = req['scheme']
        else:
            raise ValueError(f"unable to determine scheme for req={req}")

        if self.host is not None:
            host = self.host
        elif "host" in req:
            host = req['host']
        else:
            raise ValueError(f"unable to determine host for req={req}")

        if self.port is not None:
            port = self.port
        elif "port" in req:
            port = req['port']
        else:
            raise ValueError(f"unable to determine port for req={req}")

        if 'path' not in req:
            path = '/'
        else:
            path = req['path'].lstrip("/")

        # query string support
        qs = req.get('query', '')
        if isinstance(qs, dict):
            qs = urlencode(qs)
        url = f"{scheme}://{host}:{port}/{path}"
        if qs:
            url += f"?{qs}"

        client = self.clienter.request(req['method'], url, body, req['headers'])

        msg = dict()
        msg['reqid'] = req['reqid']
        msg['ctx'] = ctx
        msg['client'] = client
        msg['start'] = time.time()
        msg['size'] = len(body)
        self.clients.append(msg)

    def processResponses(self):
        for msg in list(self.clients):
            reqid = msg['reqid']  # SAID of the original /http/req
            ctx = msg['ctx']

            client = msg['client']
            start = msg['start']

            if client.responses:
                self.clients.remove(msg)
                hab = self.router.hab(self.src)

                remote_request_time = time.time() - start
                rep = client.respond()
                self.clienter.remove(client)

                # externalize the body to an attachment
                raw = rep.body
                response_size = len(raw)

                payload = http_response(
                    status=rep.status,
                    reason=rep.reason,
                    remote_request_time=remote_request_time,
                    headers={k.lower(): v for (k, v) in rep.headers.items()},
                    raw=raw,
                    reqid=reqid
                )

                cue = dict(i=Procs.http, src=hab.pre, c=self.params, ctx=ctx, a=payload)

                self.cues.append(cue)
                request_time = time.time() - start
                kwargs = dict(method=rep.request['method'], path=rep.request['path'], src=hab.pre, host=self.host,
                              port=self.port)
                REQUEST_TIME.labels(**kwargs).observe(request_time)
                REMOTE_REQUEST_TIME.labels(**kwargs).observe(remote_request_time)
                REQUEST_SIZE.labels(**kwargs).observe(response_size)
                RESPONSE_SIZE.labels(**kwargs).observe(response_size)

    def service(self):
        """Services the Decodant by processing messages and escrows."""
        self.processMsgs()
        self.processResponses()

    def close(self):
        self.msgs.clear()
        self.cues.clear()
        self.clients.clear()


class DirectorDoer(doing.Doer):
    """
    HTTP WSGI Server Doer

    See Doer for inherited attributes, properties, and methods.

    Attributes:
       .server is HTTP WSGI Server instance

    Properties:

    """

    def __init__(self, director, **kwa):
        """
        Initialize

        Parameters:
           server is HTTP Server instance
        """
        super(DirectorDoer, self).__init__(**kwa)
        self.director = director

    def recur(self, tyme):
        """"""
        self.director.service()

    def exit(self):
        """"""
        self.director.close()


class HttpProc:
    def __init__(self, router, name, src, host, port):
        self.router = router
        self.hby = self.router.hby
        self.host = host
        self.port = port
        self.clienter = httping.Clienter()

        self.director = Director(router=router, clienter=self.clienter, src=src,
                                 host=self.host, port=self.port)

        self.doers = [self.clienter]

    @property
    def inbound(self):
        return self.director.msgs

    @property
    def outbound(self):
        return self.director.cues

    def service(self):
        """"""
        self.director.service()

    def close(self):
        """"""
        self.director.close()



