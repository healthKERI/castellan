# -*- encoding: utf-8 -*-
"""
rack.proc.http.calling module


Internal proc for calling WSGI based application from routed HTTPSRV messages

"""
import datetime
import importlib
import io
import math
import sys
import time
from collections import deque

from hio.base import doing
from hio.core.http import httping
from hio.core.http.clienting import Respondent
from hio.help import decking, Hict
from keri import help, core
from keri.core import counting, coring
from keri.help import helping
from keri.kering import Schemes, Vrsn_1_0
from prometheus_client import Histogram

from rack.core import profiling
from rack.core.scheming import Procs
from rack.proc.http.httping import CHUNK_SIZE, http_response

logger = help.ogler.getLogger()

CRLF = b"\r\n"

REQUEST_TIME = Histogram('rack_httpcall_request_duration_seconds', 'HTTP Callable request duration in seconds',
                         ['method', 'src', 'app', 'path'])
REMOTE_REQUEST_TIME = Histogram('rack_httpcall_remote_request_duration_seconds',
                                'HTTP Callable remote request duration in seconds',
                                ['method', 'src', 'app', 'path'])
REQUEST_SIZE = Histogram('rack_httpcall_request_size_bytes', 'HTTP Callable request encoded size in bytes',
                         ['method', 'src', 'app', 'path'],
                         buckets=profiling.SIZE_BUCKETS)
RESPONSE_SIZE = Histogram('rack_httpcall_response_size_bytes',
                          'Http Callable response size in bytes', ['method', 'src', 'app', 'path'],
                          buckets=profiling.SIZE_BUCKETS)


class Director:

    def __init__(self, router, src, app, scheme=Schemes.http, params=None, misses=None):
        self.name = "rack.wsgi.server"
        self.router = router
        self.hby = self.router.hby
        self.src = src
        self.scheme = scheme
        self.app = app
        self.calls = decking.Deck()
        self.misses = misses if misses is not None else decking.Deck()

        self.params = params if params is not None else dict()

        self.cues = decking.Deck()
        self.msgs = decking.Deck()

    def parse(self, msg):
        """Decodes a message and processes it if it is valid.

        Parameters:
            msg (dict): The message to decode.

        Raises:
            ValueError: If the message or event is invalid.
        """
        ctx = msg.get("ctx", {})
        payload = msg['a']

        route = payload['r']
        match route:
            case "/http/req":
                if "request" not in payload or "atc" not in payload:
                    raise ValueError(f"invalid message to httpcall proc={msg}")

                request = payload['request']
                atc = bytearray(payload['atc'].encode("utf-8"))

                body = bytearray()

                if atc:
                    counter = counting.Counter(qb64b=atc, strip=True)
                    for _ in range(counter.count):
                        body.extend(core.Texter(qb64b=atc, strip=True).raw)

                self.request(request, ctx=ctx, body=body)

            case _:
                raise ValueError(f"invalid message to http proc={msg}")


    def processMsgs(self):
        """Processes all messages in the deck.

        Decodes each message and logs any errors that occur during decoding.
        """
        while self.msgs:
            msg = self.msgs.pull()
            try:
                self.parse(msg)
            except Exception as e:
                logger.error(f"error={e} call parsing msg /http/req msg={msg}")

    def request(self, req, ctx, body):
        environ = dict()  # maybe should be mudict for cookies or other repeated headers

        if hasattr(body, "encode"):
            body = body.encode("utf-8")

        # WSGI variables
        environ['wsgi.version'] = (1, 0)
        environ['wsgi.url_scheme'] = self.scheme
        environ['wsgi.input'] = io.BytesIO(body)
        environ['wsgi.errors'] = sys.stderr
        environ['wsgi.multithread'] = False
        environ['wsgi.multiprocess'] = False
        environ['wsgi.run_once'] = False
        environ["wsgi.server_name"] = self.name
        environ["wsgi.server_version"] = (1, 0)

        # Required CGI variables
        environ['REQUEST_METHOD'] = req['method']  # GET
        environ['SERVER_NAME'] = req['host']  # localhost
        environ['SERVER_PORT'] = str(req['port'])  # 8888
        environ['SERVER_PROTOCOL'] = "HTTP/{0}.{1}".format(1, 1)  # used by request http/1.1
        environ['SCRIPT_NAME'] = u''
        environ['PATH_INFO'] = req['path']  # /hello?name=john

        # Optional CGI variables
        environ['QUERY_STRING'] = req['query']  # name=john
        environ['REMOTE_ADDR'] = req['remote']
        environ['CONTENT_TYPE'] = req['contentType']
        if 'contentLength' in req:
            environ['CONTENT_LENGTH'] = req['contentLength']
        else:
            # Set CONTENT_LENGTH to actual body size if not provided in request
            # This is critical for Falcon to parse form data from wsgi.input
            environ['CONTENT_LENGTH'] = str(len(body))



        # recieved http headers mapped to all caps with HTTP_ prepended
        headers = req['headers']
        for key, value in headers.items():
            key = "HTTP_" + key.replace("-", "_").upper()
            environ[key] = value

        call = Call(environ=environ, app=self.app)
        msg = dict()
        msg['reqid'] = req['reqid']
        msg['ctx'] = ctx
        msg['call'] = call
        msg['start'] = time.time()
        msg['size'] = len(body)

        self.calls.append(msg)

    def processResponses(self):
        for msg in list(self.calls):
            reqid = msg['reqid']  # SAID of the original /http/req
            ctx = msg['ctx']
            call = msg['call']
            start = msg['start']

            if not call.ended:
                call.service()

            if (rep := call.response()) is not None:
                self.calls.remove(msg)
                hab = self.router.hab(self.src)

                remote_request_time = time.time() - start
                try:
                    rep.parse()
                except httping.HTTPException as ex:
                    logger.error(f"Bad response from app {ex}")
                    continue

                # externalize the body to an attachment
                raw = rep.body
                response_size = len(raw)

                rep = http_response(
                    status=rep.status,
                    reason=rep.reason,
                    remote_request_time=remote_request_time,
                    headers={k.lower(): v for (k, v) in rep.headers.items()},
                    raw=raw,
                    reqid=reqid
                )

                cue = dict(i=Procs.httpcall, src=hab.pre, c=self.params, ctx=ctx, a=rep)
                self.cues.append(cue)

                request_time = time.time() - start
                kwargs = dict(method=call.method, path=call.environ['PATH_INFO'], src=hab.pre, app="TODO")
                REQUEST_TIME.labels(**kwargs).observe(request_time)
                REMOTE_REQUEST_TIME.labels(**kwargs).observe(remote_request_time)
                REQUEST_SIZE.labels(**kwargs).observe(response_size)
                RESPONSE_SIZE.labels(**kwargs).observe(response_size)

    def service(self):
        """Services the Decodant by processing messages and escrows."""
        self.processMsgs()
        self.processResponses()

    def close(self):
        self.msgs.clear()
        self.cues.clear()
        self.calls.clear()


class DirectorDoer(doing.Doer):
    """
    HTTP WSGI Server Doer

    See Doer for inherited attributes, properties, and methods.

    Attributes:
       .server is HTTP WSGI Server instance

    Properties:

    """

    def __init__(self, director, **kwa):
        """
        Initialize

        Parameters:
           server is HTTP Server instance
        """
        super(DirectorDoer, self).__init__(**kwa)
        self.director = director

    def recur(self, tyme):
        """"""
        self.director.service()

    def exit(self):
        """"""
        self.director.close()


class Call:

    HttpVersionString = httping.HTTP_11_VERSION_STRING  # http version string

    def __init__(self, environ, app):
        self.environ = environ
        self.method = environ['REQUEST_METHOD']
        self.events = deque()
        self.redirects = list()

        self.app = app
        self.started = False
        self.headed = False
        self.chunked = False
        self.chunkable = None
        self.ended = False  # True if response body completely sent
        self.iterator = None  # iterator on application body
        self.status = "200 OK"
        self.headers = Hict()
        self.length = None
        self.size = 0
        self.evented = False
        self.msg = bytearray()

    def reset(self, environ, chunkable=None):
        """
        Reset attributes for another request-response
        """
        self.environ = environ

        if self.chunkable is not None:
            self.chunkable = chunkable

        self.started = False
        self.headed = False
        self.chunked = False
        self.ended = False
        self.iterator = None
        self.status = "200 OK"
        self.headers = Hict()
        self.length = None
        self.size = 0
        self.evented = False
        self.msg = bytearray()

    def build(self):
        """
        Return built head bytes from .status and .headers

        """
        lines = []

        _status = getattr(self.iterator, '_status', None)  # if AttributiveGenerator
        if _status is not None:  # override
            self.status = _status

        if isinstance(self.status, int):  # replace int with str
            self.status = "{0} {1}".format(self.status,
                                           httping.STATUS_DESCRIPTIONS[self.status])

        startLine = "{0} {1}".format(self.HttpVersionString, self.status)
        try:
            startLine = startLine.encode('ascii')
        except UnicodeEncodeError:
            startLine = startLine.encode('idna')
        lines.append(startLine)

        # Override if AttributiveGenerator
        self.headers.update(getattr(self.iterator, '_headers', Hict()))

        if u'server' not in self.headers:  # create Server header
            self.headers[u'server'] = "Ioflo WSGI Server"

        if u'date' not in self.headers:  # create Date header
            self.headers[u'date'] = httping.httpDate1123(datetime.datetime.now(datetime.UTC))

        if self.chunkable and ('transfer-encoding' not in self.headers or
                               self.headers['transfer-encoding'] == 'chunked'):
            self.chunked = True
            self.headers[u'transfer-encoding'] = u'chunked'

        for name, value in self.headers.items():
            lines.append(httping.packHeader(name, value))

        lines.extend((b"", b""))
        head = CRLF.join(lines)  # b'/r/n'

        return head

    def write(self, msg):
        """
        WSGI write callback This writes out the headers the first time its called
        otherwise writes the msg bytes
        """
        if not self.started:
            raise AssertionError("WSGI write() before start_response()")

        if not self.headed:  # head not written yet
            head = self.build()
            self.msg.extend(head)
            self.headed = True

        if self.chunked:
            msg = httping.packChunk(msg)

        if self.length is not None:  # limit total size to length
            size = self.size + len(msg)
            if size > self.length:
                msg = msg[:self.length - size]
            self.size += len(msg)

        if msg:
            self.msg.extend(msg)

    def start(self, status, response_headers, exc_info=None):
        """
        WSGI application start_response callable

        Parameters:

        status is string of status code and status reason '200 OK' or simple
            status code int which will be replaced with string

        response_headers is list of tuples of strings of the form (field, value)
                          one tuple for each header example:
                          [
                              ('Content-type', 'text/plain'),
                              ('X-Some-Header', 'value')
                          ]

        exc_info is optional exception info if exception occurred while
                    processing request in wsgi application
                    If exc_info is supplied, and no HTTP headers have been output yet,
                    start_response should replace the currently-stored
                    HTTP response headers with the newly-supplied ones,
                    thus allowing the application to "change its mind" about
                    the output when an error has occurred.

                    However, if exc_info is provided, and the HTTP headers
                    have already been sent, start_response must raise an error,
                    and should re-raise using the exc_info tuple. That is:

                    raise exc_info[1].with_traceback(exc_info[2]) (python3)

        Nonstandard modifiction to allow for iterable/generator of body to change
           headers and status before first write to support async processing of
           responses whose iterator/generator yields empty before first non-empty
           yield.  In .service yielding empty does not cause write so status line
           and headers are not sent until first non-empty write.

           The mode is that the app.headers and app.status are consulted to see
           if changed from when .start = wsgi start_response was first called.
        """
        if exc_info:
            try:
                if self.headed:
                    # Re-raise original exception if headers sent
                    raise exc_info[1].with_traceback(exc_info[2])
            finally:
                exc_info = None  # avoid dangling circular ref
        elif self.started:  # may not call start_response again without exc_info
            raise AssertionError("Already started!")

        self.status = status
        self.headers = Hict(response_headers)

        if u'content-length' in self.headers:
            self.length = int(self.headers['content-length'])
            self.chunkable = False  # cannot use chunking with finite content-length
        else:
            self.length = None

            if u'content-type' in self.headers:
                if self.headers['content-type'].startswith('text/event-stream'):
                    self.evented = True

        self.started = True
        return self.write

    def service(self):
        """
        Service wsgi compatible application
        """
        if not self.ended:
            if self.iterator is None:  # initiate application
                self.iterator = iter(self.app(self.environ,
                                              start_response=self.start))
            try:
                msg = next(self.iterator)
            except StopIteration as ex:
                if hasattr(ex, "value") and ex.value:
                    self.write(ex.value)  # new style generators in python3.3+
                self.write(b'')  # in case chunked send empty chunk to terminate
                self.ended = True
            except httping.HTTPError as ex:
                if not self.headed:
                    headers = Hict()
                    headers.update(ex.headers.items())
                    if 'content-type' not in headers:
                        headers['content-type'] = 'text/plain'
                    msg = ex.render()
                    headers['content-length'] = str(len(msg))
                    # WSGI status is string of status code and reason
                    status = "{} {}".format(ex.status, ex.reason)
                    self.start(status, headers.items(), sys.exc_info())
                    self.write(msg)
                    self.ended = True
                else:
                    logger.error("HTTPError streaming body after headers sent.\n"
                                 "%s\n", ex)
            except Exception as ex:  # handle http exceptions not caught by app
                logger.error("Unexcepted Server Error.\n%s\n", ex)
            else:
                if msg:  # only write if not empty allows async processing
                    self.write(msg)
                    if self.length is not None and self.size >= self.length:
                        self.ended = True

    def response(self):
        if self.ended:
            return Respondent(msg=self.msg,
                              method=self.method,
                              dictable=None,
                              events=self.events,
                              redirectable=False,
                              redirects=self.redirects)
        return None


class HttpCallProc:
    def __init__(self, router, src, app, misses=None, **params):
        self.router = router
        self.hby = self.router.hby
        self.misses = misses

        module = importlib.import_module(app)
        self.app = module.setup_app(router=self.router, **params)

        self.director = Director(router=router, src=src, app=self.app, misses=self.misses)

    @property
    def inbound(self):
        return self.director.msgs

    @property
    def outbound(self):
        return self.director.cues

    def service(self):
        """"""
        self.director.service()

    def close(self):
        """"""
        self.director.close()
