# -*- encoding: utf-8 -*-
"""
rack.proc.socks.clienting module

"""

from hio.base import doing
from hio.help import decking
from keri import help, core
from keri.core import parsing, serdering, counting, coring
from keri.kering import Ilks, Schemes, Vrsn_1_0
from keri.peer import exchanging
from prometheus_client import Histogram

from rack.core import profiling, pinging, tcp
from rack.core.scheming import Procs

logger = help.ogler.getLogger()

REQUEST_TIME = Histogram('rack_socks_request_duration_seconds', 'HTTP Client request duration in seconds',
                         ['method', 'src', 'host', 'port', 'path'])
REMOTE_REQUEST_TIME = Histogram('rack_socks_remote_request_duration_seconds',
                                'HTTP Client remote request duration in seconds',
                                ['method', 'src', 'host', 'port', 'path'])
REQUEST_SIZE = Histogram('rack_socks_request_size_bytes', 'ESSR encoded size in bytes',
                         ['method', 'src', 'host', 'port', 'path'],
                         buckets=profiling.SIZE_BUCKETS)
RESPONSE_SIZE = Histogram('rack_socks_response_size_bytes',
                          'Http response size in bytes', ['method', 'src', 'host', 'port', 'path'],
                          buckets=profiling.SIZE_BUCKETS)


class Director:

    def __init__(self, router, clientary, name, src, dests, scheme=Schemes.http, params=None):
        self.router = router
        self.clientary = clientary
        self.hby = self.router.hby
        self.src = src
        self.dests = {(address, port): aid for (aid, address, port) in dests}
        self.scheme = scheme
        self.clients = {}

        self.cues = decking.Deck()
        self.msgs = decking.Deck()
        self.fins = decking.Deck()
        self.pongs = decking.Deck()

        self.params = params if params is not None else dict()
        self.handler = SocksReqHandler(hby=self.hby, params=self.params)
        self.finner = SocksFinHandler(hby=self.hby, fins=self.fins, params=self.params)
        self.pinger = pinging.PingHandler(name=name, router=self.router, src=self.src, cues=self.pongs)
        self.exc = exchanging.Exchanger(hby=self.hby, handlers=[self.handler, self.pinger, self.finner])
        self.parser = parsing.Parser(exc=self.exc)

    def parse(self, msg):
        """Decodes a message and processes it if it is valid.

        Parameters:
            msg (dict): The message to decode.

        Raises:
            ValueError: If the message or event is invalid.
        """
        payload = msg['a']
        if "serder" not in payload or "atc" not in payload:
            raise ValueError(f"invalid message to http proc={msg}")

        serder = serdering.SerderKERI(sad=payload['serder'])
        if serder.ilk != Ilks.exn:
            raise ValueError(f"invalid event (route={serder.ked['r']}) to http proc={serder.ked}")

        logger.info(f"SOCKS client parsing {serder.ked['r']} message.")
        atc = payload['atc']
        ims = bytearray(serder.raw)
        ims.extend(atc.encode("utf-8"))

        self.parser.parseOne(ims=ims)

    def processMsgs(self):
        """Processes all messages in the deck.

        Decodes each message and logs any errors that occur during decoding.
        """
        while self.msgs:
            msg = self.msgs.pull()
            try:
                self.parse(msg)
            except Exception as e:
                logger.error(f"error={e} parsing exn /socks/req msg={msg}")

    def processPongs(self):
        # hab = self.router.hab(self.src)

        while self.pongs:
            pong = self.pongs.pull()
            serder = pong['serder']
            atc = pong['atc']

            # TODO: what to do with PONGS
            # cue = dict(i=Procs.socks, src=hab.pre, dest=self.dest, c=self.params,
            #            a=dict(serder=serder.ked, atc=atc.decode("utf-8")))
            # self.cues.append(cue)

    def tcpclient(self, address, port, xip):
        if (client := self.clients.get((address, port, xip))) is None:
            logger.info(f"creating client for {address}:{port} - {xip}")
            client = self.clientary.connect(address, port)
            self.clients[(address, port, xip)] = client

        return client

    def processReqs(self):
        while self.handler.reqs:
            (ked, body) = self.handler.reqs.pull()
            try:
                payload = ked['a']
                address = payload['address']
                port = payload['port']
                xip = payload['xip']

                client = self.tcpclient(address, port, xip)
                client.tx(body)

            except Exception as e:
                logger.error(f"error={e} when executing socks req=req")

    def processResponses(self):
        for (address, port, xip), client in self.clients.items():

            if client.rxbs:
                data = client.rxbs[0:8192]
                del client.rxbs[0:8192]

                dig = core.Diger(ser=data, code=core.MtrDex.Blake3_256).qb64
                payload = dict(
                    body=dig,
                    address=address,
                    port=port,
                    xip=xip
                )

                dest = self.dests[(address, port)]
                hab = self.router.hab(self.src)

                exn, _ = exchanging.exchange(route="/socks/rep",
                                             payload=payload,
                                             sender=hab.pre,
                                             )
                ims = hab.endorse(serder=exn, last=False, pipelined=False)
                ims.extend(counting.Counter(code=counting.CtrDex_1_0.ESSRPayloadGroup, count=1, gvrsn=Vrsn_1_0).qb64b)
                texter = coring.Matter(raw=data, code=coring.MtrDex.Bytes_L0)
                ims.extend(texter.qb64b)

                atc = ims[exn.size:]

                cue = dict(i=Procs.sockssrv, c={}, src=self.src, dest=dest, a=dict(serder=exn.ked, atc=atc.decode("utf-8")))
                self.cues.append(cue)

                hab.db.essrs.rem(keys=(exn.said,))
                hab.db.epath.rem(keys=(exn.said,))

    def processEscrows(self):
        """Processes escrows in the exchanger."""
        self.exc.processEscrow()

    def service(self):
        """Services the Decodant by processing messages and escrows."""
        self.processMsgs()
        self.processPongs()
        self.processEscrows()
        self.processReqs()
        self.processResponses()

    def close(self):
        self.msgs.clear()
        self.cues.clear()
        self.clients.clear()


class DirectorDoer(doing.Doer):
    """
    HTTP WSGI Server Doer

    See Doer for inherited attributes, properties, and methods.

    Attributes:
       .server is HTTP WSGI Server instance

    Properties:

    """

    def __init__(self, director, **kwa):
        """
        Initialize

        Parameters:
           server is HTTP Server instance
        """
        super(DirectorDoer, self).__init__(**kwa)
        self.director = director

    def recur(self, tyme):
        """"""
        self.director.service()

    def exit(self):
        """"""
        self.director.close()


class SocksProc:
    def __init__(self, router, name, src, dests):
        self.router = router
        self.hby = self.router.hby
        self.clientary = tcp.Clientary()
        self.director = Director(router=router, name=name, src=src, dests=dests, clientary=self.clientary)

        self.doers = [self.clientary]

    @property
    def inbound(self):
        return self.director.msgs

    @property
    def outbound(self):
        return self.director.cues

    def service(self):
        """"""
        self.director.service()

    def close(self):
        """"""
        self.director.close()


class SocksReqHandler:
    """
    Handler for forward `exn` messages used to envelope other KERI messages intended for another recipient.
    This handler acts as a mailbox for other identifiers and stores the messages in a local database.

    on
        {
           "v": "KERI10JSON00011c_",                               // KERI Version String
           "t": "exn",                                             // peer to peer message ilk
           "d": "EAhDiMFIINHBIn139nSG7QlNj7Sa2YHdZDIvzRYylQeE",
           "dt": "2020-08-22T17:50:12.988921+00:00"
           "r": "/socks/req",
           "q": {
            }
           "a": '{
              "d": "EAhDiMFIINHBIn139nSG7QlNj7Sa2YHdZDIvzRYylQeE"
              "method": "POST",
              "path": "/foo/bar",
              "body": "data"
           }
        }-AABAA1o61PgMhwhi89FES_vwYeSbbWnVuELV_jv7Yv6f5zNiOLnj1ZZa4MW2c6Z_vZDt55QUnLaiaikE-d_ApsFEgCA

    """

    resource = "/socks/req"

    def __init__(self, hby, reqs=None, params=None):
        """

        Parameters:
            hby (Habery): database environment
            reqs (Deck): message storage outgoing requests to be made

        """
        self.hby = hby
        self.reqs = reqs if reqs is not None else decking.Deck()
        self.params = params or {}

    def handle(self, serder, attachments=None, essr=None):
        """  Perform SOCKs request from payload of /socks/req exn message

        Parameters:
            serder (Serder): Serder of the http req exn message
            attachments (list): list of tuples of root pathers and CESR SAD path attachments to the exn event
            essr (bytes):  essr attachment

        """
        if essr:
            dig = serder.ked['a']['body']
            diger = core.Diger(qb64=dig)
            if not diger.verify(ser=essr):
                logger.error(f"invalid http request body for event={serder.ked}, digest does not match body")
                return

            body = essr
        else:
            logger.info("Empty /socks/req request, ignoring")
            return

        self.reqs.append((serder.ked, body))

        self.hby.db.essrs.rem(keys=(serder.said,))
        self.hby.db.epath.rem(keys=(serder.said,))


class SocksFinHandler:
    """
    Handler for terminating (FIN) a connection.

    on
        {
           "v": "KERI10JSON00011c_",                               // KERI Version String
           "t": "exn",                                             // peer to peer message ilk
           "d": "EAhDiMFIINHBIn139nSG7QlNj7Sa2YHdZDIvzRYylQeE",
           "dt": "2020-08-22T17:50:12.988921+00:00"
           "r": "/socks/fin",
           "q": {
            }
           "a": '{
              "d": "EAhDiMFIINHBIn139nSG7QlNj7Sa2YHdZDIvzRYylQeE"
              "method": "POST",
              "path": "/foo/bar",
              "body": "data"
           }
        }-AABAA1o61PgMhwhi89FES_vwYeSbbWnVuELV_jv7Yv6f5zNiOLnj1ZZa4MW2c6Z_vZDt55QUnLaiaikE-d_ApsFEgCA

    """

    resource = "/socks/fin"

    def __init__(self, hby, fins=None, params=None):
        """

        Parameters:
            hby (Habery): database environment
            fins (Deck): message storage outgoing connections to close

        """
        self.hby = hby
        self.fins = fins if fins is not None else decking.Deck()
        self.params = params or {}

    def handle(self, serder, attachments=None, essr=None):
        """  Perform HTTP request from payload of /essr/req exn message

        Parameters:
            serder (Serder): Serder of the http req exn message
            attachments (list): list of tuples of root pathers and CESR SAD path attachments to the exn event
            essr (bytes):  essr attachment

        """
        if essr:
            dig = serder.ked['a']['body']
            diger = core.Diger(qb64=dig)
            if not diger.verify(ser=essr):
                logger.error(f"invalid http request body for event={serder.ked}, digest does not match body")
                return

            body = essr
        else:
            body = serder.ked['a']['body']
            del serder.ked['a']['body']

        self.fins.append((serder.ked, body))

        self.hby.db.essrs.rem(keys=(serder.said,))
        self.hby.db.epath.rem(keys=(serder.said,))
