# -*- encoding: utf-8 -*-
"""
rack.proc.socks.calling module

"""
import importlib
import io
import sys
from urllib.parse import quote

from hio.base import doing, tyming
from hio.core.http import httping
from hio.core.http.serving import Requestant, Responder
from hio.help import decking
from keri import help, core
from keri.core import parsing, serdering, counting, coring
from keri.kering import Ilks, Schemes, Vrsn_1_0
from keri.peer import exchanging
from prometheus_client import Histogram

from rack.core import profiling
from rack.core.scheming import Procs

logger = help.ogler.getLogger()

REQUEST_TIME = Histogram('rack_sockscall_request_duration_seconds', 'HTTP Client request duration in seconds',
                         ['method', 'src', 'host', 'port', 'path'])
REMOTE_REQUEST_TIME = Histogram('rack_sockscall_remote_request_duration_seconds',
                                'HTTP Client remote request duration in seconds',
                                ['method', 'src', 'host', 'port', 'path'])
REQUEST_SIZE = Histogram('rack_sockscall_request_size_bytes', 'ESSR encoded size in bytes',
                         ['method', 'src', 'host', 'port', 'path'],
                         buckets=profiling.SIZE_BUCKETS)
RESPONSE_SIZE = Histogram('rack_sockscall_response_size_bytes',
                          'Http response size in bytes', ['method', 'src', 'host', 'port', 'path'],
                          buckets=profiling.SIZE_BUCKETS)


class Director:

    def __init__(self, name, router, src, dest, app, scheme=Schemes.http, params=None):
        self.name = name
        self.router = router
        self.app = app
        self.hby = self.router.hby
        self.src = src
        self.dest = dest
        self.scheme = scheme
        self.app = app
        self.calls = decking.Deck()
        self.reqs = dict()  # allows external view
        self.reps = dict()  # allows external view

        self.params = params if params is not None else dict()
        self.handler = SocksReqHandler(hby=self.hby, params=self.params)
        self.finer = SocksFinHandler(director=self)
        self.exc = exchanging.Exchanger(hby=self.hby, handlers=[self.handler, self.finer])
        self.parser = parsing.Parser(exc=self.exc)

        self.cues = decking.Deck()
        self.msgs = decking.Deck()

    def requestant(self, address, port, xip):
        if (rant := self.reqs.get((address, port, xip))) is None:
            logger.info(f"creating reactant for {address}:{port} - {xip}")

            # rant.msg is the input for the request
            rant = Requestant(msg=bytearray(), remoter=Remoter(ha=(address, port), ca=xip, tymeout=3.0))
            self.reqs[(address, port, xip)] = rant

        return rant

    def parse(self, msg):
        """Decodes a message and processes it if it is valid.

        Parameters:
            msg (dict): The message to decode.

        Raises:
            ValueError: If the message or event is invalid.
        """
        payload = msg['a']
        if "serder" not in payload or "atc" not in payload:
            raise ValueError(f"invalid message to http proc={msg}")

        serder = serdering.SerderKERI(sad=payload['serder'])
        if serder.ilk != Ilks.exn:
            raise ValueError(f"invalid event (route={serder.ked['r']}) to http proc={serder.ked}")

        atc = payload['atc']
        ims = bytearray(serder.raw)
        ims.extend(atc.encode("utf-8"))

        self.parser.parseOne(ims=ims)

    def processMsgs(self):
        """Processes all messages in the deck.

        Decodes each message and logs any errors that occur during decoding.
        """
        while self.msgs:
            msg = self.msgs.pull()
            try:
                self.parse(msg)
            except Exception as e:
                logger.error(f"error={e} parsing exn /socks/req msg={msg}")

    def processReqs(self):
        while self.handler.reqs:
            (ked, body) = self.handler.reqs.pull()
            try:
                payload = ked['a']
                address = payload['address']
                port = payload['port']
                xip = payload['xip']

                rant = self.requestant(address, port, xip)
                rant.msg.extend(body)

            except Exception as e:
                logger.error(f"error={e} when executing socks req=req")

    def processResponses(self):
        for (address, port, xip), requestant in self.reqs.items():

            if requestant.remoter.txbs:
                data = requestant.remoter.txbs[0:8192]
                del requestant.remoter.txbs[0:8192]

                dig = core.Diger(ser=data, code=core.MtrDex.Blake3_256).qb64
                payload = dict(
                    body=dig,
                    address=address,
                    port=port,
                    xip=xip
                )

                hab = self.router.hab(self.src)

                exn, _ = exchanging.exchange(route="/socks/rep",
                                             payload=payload,
                                             sender=hab.pre,
                                             )
                ims = hab.endorse(serder=exn, last=False, pipelined=False)
                ims.extend(counting.Counter(code=counting.CtrDex_1_0.ESSRPayloadGroup, count=1, gvrsn=Vrsn_1_0).qb64b)
                texter = coring.Matter(raw=data, code=coring.MtrDex.Bytes_L0)
                ims.extend(texter.qb64b)

                atc = ims[exn.size:]

                cue = dict(i=Procs.sockssrv, c={}, src=self.src, dest=self.dest,
                           a=dict(serder=exn.ked, atc=atc.decode("utf-8")))
                self.cues.append(cue)

                hab.db.essrs.rem(keys=(exn.said,))
                hab.db.epath.rem(keys=(exn.said,))

    def processEscrows(self):
        """Processes escrows in the exchanger."""
        self.exc.processEscrow()

    def serviceReqs(self):
        """
        Service pending requestants
        """
        for ca, requestant in list(self.reqs.items()):
            if requestant.parser:
                try:
                    requestant.parse()
                except httping.HTTPException as ex:  # unkown error cause this may be superfluous
                    logger.error(ex)
                    sys.stderr.write(str(ex))
                    self.closeConnection(*ca)
                    continue  # give up on request since shouldn't be here

                if requestant.ended:
                    if requestant.errored:  # parse may swallow error but set .errored and .error
                        sys.stderr.write(requestant.error)
                        self.closeConnection(*ca)
                        continue

                    logger.info("Parsed Request: %s %s %s", requestant.method,
                                requestant.path,
                                requestant.version)
                    logger.debug("Headers/Body: %s -- %s", requestant.headers,
                                 requestant.body)
                    # create or restart wsgi app responder here
                    environ = self.buildEnviron(requestant)
                    if ca not in self.reps:
                        chunkable = True if requestant.version >= (1, 1) else False
                        responder = Responder(incomer=requestant.remoter,
                                              app=self.app,
                                              environ=environ,
                                              chunkable=chunkable)
                        self.reps[ca] = responder
                    else:  # reuse
                        responder = self.reps[ca]
                        responder.reset(environ=environ)

                if requestant.remoter.tymeout > 0.0 and requestant.remoter.tymer.expired:
                    self.closeConnection(*ca)

    def buildEnviron(self, requestant):
        """
        Returns wisgi environment dictionary for supplied requestant
        """
        environ = dict()  # maybe should be mudict for cookies or other repeated headers

        # WSGI variables
        environ['wsgi.version'] = (1, 0)
        environ['wsgi.url_scheme'] = self.scheme
        environ['wsgi.input'] = io.BytesIO(requestant.body)
        environ['wsgi.errors'] = sys.stderr
        environ['wsgi.multithread'] = False
        environ['wsgi.multiprocess'] = False
        environ['wsgi.run_once'] = False
        environ["wsgi.server_name"] = self.name
        environ["wsgi.server_version"] = (1, 0)

        # Required CGI variables
        environ['REQUEST_METHOD'] = requestant.method      # GET
        environ['SERVER_NAME'] = requestant.remoter.ha[0]      # localhost
        environ['SERVER_PORT'] = str(requestant.remoter.ha[1])  # 8888
        environ['SERVER_PROTOCOL'] = "HTTP/{0}.{1}".format(*requestant.version)  # used by request http/1.1
        environ['SCRIPT_NAME'] = u''
        environ['PATH_INFO'] = quote(requestant.path)        # /hello?name=john

        # Optional CGI variables
        environ['QUERY_STRING'] = requestant.query        # name=john
        environ['REMOTE_ADDR'] = requestant.remoter.ca
        environ['CONTENT_TYPE'] = requestant.headers.get('content-type', '')
        if requestant.length is not None:
            environ['CONTENT_LENGTH'] = str(requestant.length)

        # recieved http headers mapped to all caps with HTTP_ prepended
        for key, value in requestant.headers.items():
            key = "HTTP_" + key.replace("-", "_").upper()
            environ[key] = value

        return environ

    def serviceReps(self):
        """
        Service pending responders
        """
        for ca, responder in list(self.reps.items()):
            if responder.closed:
                self.closeConnection(*ca)
                continue

            if not responder.ended:
                responder.service()

            if responder.ended:
                requestant = self.reqs[ca]
                if requestant.persisted:
                    if requestant.parser is None:  # reuse
                        requestant.makeParser()  # resets requestant parser
                else:  # not persistent so close and remove requestant and responder
                    # ix = self.servant.ixes[ca]
                    # if not ix.txbs:  # wait for outgoing txbs to be empty
                    self.closeConnection(*ca)

    def closeConnection(self, address, port, xip):
        """
        Close and remove connection given by ca
        """
        ca = (address, port, xip)
        if ca in self.reqs:
            self.reqs[ca].close()  # this signals request parser
            del self.reqs[ca]
        if ca in self.reps:
            self.reps[ca].close()  # this signals response handler
            del self.reps[ca]

    def service(self):
        """Services the Decodant by processing messages and escrows."""
        self.processMsgs()
        self.processEscrows()
        self.processReqs()
        self.serviceReqs()
        self.serviceReps()
        self.processResponses()

    def close(self):
        self.msgs.clear()
        self.cues.clear()


class DirectorDoer(doing.Doer):
    """
    HTTP WSGI Server Doer

    See Doer for inherited attributes, properties, and methods.

    Attributes:
       .server is HTTP WSGI Server instance

    Properties:

    """

    def __init__(self, director, **kwa):
        """
        Initialize

        Parameters:
           server is HTTP Server instance
        """
        super(DirectorDoer, self).__init__(**kwa)
        self.director = director

    def recur(self, tyme):
        """"""
        self.director.service()

    def exit(self):
        """"""
        self.director.close()


class Remoter(tyming.Tymee):
    """
    Class to service an incoming nonblocking TCP connection from a remote client.
    Should only be used by an Acceptor subclass such as Server
    """
    Tymeout = 0.0  # virtual tymeout in seconds

    def __init__(self,
                 ha,
                 ca,
                 tymeout=None,
                 refreshable=True,
                 bs=8096,
                 wl=None,
                 **kwa
                 ):

        """
        Initialization method for instance.
        ha = host address duple (host, port) near side of connection. cs.getsockname()
             useful for debugging after cs is closed
        ca = connection address used as key in severs's ixes. Need this to
             know how to delete from .ixes when connection closed as .cs loses
             cs.getpeername() after its closed.
        cs = connection socket object
        tymeout = tymeout for .tymer
        refreshable = True if tx/rx activity refreshes timer False otherwise
        bs = buffer size
        wl = WireLog object if any
        """
        super(Remoter, self).__init__(**kwa)
        self.ha = ha  # connection address of server
        self.ca = ca  # connection address of peer used to index in server.ixes
        self.tymeout = tymeout if tymeout is not None else self.Tymeout
        self.tymer = tyming.Tymer(tymth=self.tymth, duration=self.tymeout)
        self.cutoff = False  # True when detect connection closed on far side
        self.refreshable = refreshable
        self.bs = bs
        self.txbs = bytearray()  # bytearray of data to send
        self.rxbs = bytearray()  # bytearray of data received
        self.wl = wl

    def wind(self, tymth):
        """
        Inject new tymist.tymth as new ._tymth. Changes tymist.tyme base.
        Updates winds .tymer .tymth
        """
        super(Remoter, self).wind(tymth)
        self.tymer.wind(tymth)

    def refresh(self):
        """
        Restart tymer
        """
        self.tymer.restart()

    def clearRxbs(self):
        """
        Clear .rxbs
        """
        del self.rxbs[:]

    def tx(self, data):
        """
        Queue data onto .txbs
        """
        self.txbs.extend(data)


class SocksCallProc:
    def __init__(self, router, name, src, dest, app, params):
        self.router = router
        self.hby = self.router.hby

        module = importlib.import_module(app)
        self.app = module.setup_app(router=self.router, **params)

        self.director = Director(router=router, name=name, src=src, dest=dest, app=self.app)

    @property
    def inbound(self):
        return self.director.msgs

    @property
    def outbound(self):
        return self.director.cues

    def service(self):
        """"""
        self.director.service()

    def close(self):
        """"""
        self.director.close()



class SocksReqHandler:
    """
    Handler for forward `exn` messages used to envelope other KERI messages intended for another recipient.
    This handler acts as a mailbox for other identifiers and stores the messages in a local database.

    on
        {
           "v": "KERI10JSON00011c_",                               // KERI Version String
           "t": "exn",                                             // peer to peer message ilk
           "d": "EAhDiMFIINHBIn139nSG7QlNj7Sa2YHdZDIvzRYylQeE",
           "dt": "2020-08-22T17:50:12.988921+00:00"
           "r": "/socks/req",
           "q": {
            }
           "a": '{
              "d": "EAhDiMFIINHBIn139nSG7QlNj7Sa2YHdZDIvzRYylQeE"
              "method": "POST",
              "path": "/foo/bar",
              "body": "data"
           }
        }-AABAA1o61PgMhwhi89FES_vwYeSbbWnVuELV_jv7Yv6f5zNiOLnj1ZZa4MW2c6Z_vZDt55QUnLaiaikE-d_ApsFEgCA

    """

    resource = "/socks/req"

    def __init__(self, hby, reqs=None, params=None):
        """

        Parameters:
            hby (Habery): database environment
            reqs (Deck): message storage outgoing requests to be made

        """
        self.hby = hby
        self.reqs = reqs if reqs is not None else decking.Deck()
        self.params = params or {}

    def handle(self, serder, attachments=None, essr=None):
        """  Perform SOCKs request from payload of /socks/req exn message

        Parameters:
            serder (Serder): Serder of the http req exn message
            attachments (list): list of tuples of root pathers and CESR SAD path attachments to the exn event
            essr (bytes):  essr attachment

        """
        if essr:
            dig = serder.ked['a']['body']
            diger = core.Diger(qb64=dig)
            if not diger.verify(ser=essr):
                logger.error(f"invalid http request body for event={serder.ked}, digest does not match body")
                return

            body = essr
        else:
            logger.info("Empty /socks/req request, ignoring")
            return

        self.reqs.append((serder.ked, body))

        self.hby.db.essrs.rem(keys=(serder.said,))
        self.hby.db.epath.rem(keys=(serder.said,))


class SocksFinHandler:
    """
    Handler for SOCKS /socks/fin messages from the sending gateway to indicate that a connection is closed
    and must be terminated on this side.

    on
        {
           "v": "KERI10JSON00011c_",                               // KERI Version String
           "t": "exn",                                             // peer to peer message ilk
           "d": "EAhDiMFIINHBIn139nSG7QlNj7Sa2YHdZDIvzRYylQeE",
           "dt": "2020-08-22T17:50:12.988921+00:00"
           "r": "/socks/fin",
           "q": {
            }
           "a": '{
              "xip": "EAhDiMFIINHBIn139nSG7QlNj7Sa2YHdZDIvzRYylQeE"
              "address": "127.0.0.1",
              "port": 8080
           }
        }-AABAA1o61PgMhwhi89FES_vwYeSbbWnVuELV_jv7Yv6f5zNiOLnj1ZZa4MW2c6Z_vZDt55QUnLaiaikE-d_ApsFEgCA

    """

    resource = "/socks/fin"

    def __init__(self, director, params=None):
        """

        Parameters:
            director (Director): Server director responsible for managing requestants

        """
        self.director = director
        self.params = params or {}

    def handle(self, serder, attachments=None, essr=None):
        """  Perform SOCKs request from payload of /socks/req exn message

        Parameters:
            serder (Serder): Serder of the http req exn message
            attachments (list): list of tuples of root pathers and CESR SAD path attachments to the exn event
            essr (bytes):  essr attachment

        """
        try:
            payload = serder.ked['a']
            address = payload['address']
            port = payload['port']
            xip = payload['xip']

            if (rant := self.director.reqs.get((address, port, xip))) is not None:
                logger.info(f"socks fin requesting closing connection {rant.remoter.ha}, {rant.remoter.ca}")
                self.director.closeConnection(address, port, xip)
        except Exception as e:
            logger.info(e)
