# -*- encoding: utf-8 -*-
"""
rack.proc.socks.serving module

"""
import socket
import struct

from hio.base import doing
from hio.core import tcp
from hio.help import decking
from keri import help, core
from keri.core import serdering, counting, coring, parsing
from keri.kering import Ilks, Vrsn_1_0
from keri.peer import exchanging
from prometheus_client import Counter

from rack.core import pinging
from rack.core.scheming import Procs

logger = help.ogler.getLogger()

REQUESTS = Counter('rack_sockssrv_request_duration_seconds', 'TCP SOCKS server request duration in seconds',
                   ['src', 'dest'])


class Directant(doing.DoDoer):
    """
    Directant class with SOCKS5 TCP-only Server.
    Responds to initiated connections from a remote Director by creating and
    running a Reactant per connection. Each Reactant has TCP remoter.

    """

    def __init__(self, router, src, dests, server, msgs=None, cues=None, doers=None, **kwa):
        """
        Initialize instance.

        Inherited Parameters:
            tymist is  Tymist instance
            tock is float seconds initial value of .tock

        Parameters:
            db is database instance of local controller's context
            verifier (optional) is Verifier instance of local controller's TEL context
            server is TCP Server instance
        """
        self.router = router
        self.src = src
        self.targets = {(address, port): aid for (aid, address, port) in dests}
        self.msgs = msgs if msgs is not None else decking.Deck()
        self.cues = cues if cues is not None else decking.Deck()

        self.server = server  # use server for cx
        self.rants = dict()

        self.msgParser = MessageParser(router=self.router, name="sockssrv", params={}, msgs=self.msgs)
        doers = doers if doers is not None else []
        doers.extend([doing.doify(self.serviceDo), self.msgParser])
        super(Directant, self).__init__(doers=doers, **kwa)
        if self.tymth:
            self.server.wind(self.tymth)

    def wind(self, tymth):
        """
        Inject new tymist.tymth as new ._tymth. Changes tymist.tyme base.
        Updates winds .tymer .tymth
        """
        super(Directant, self).wind(tymth)
        self.server.wind(tymth)

    def serviceDo(self, tymth=None, tock=0.0, **kwa):
        """  Process incoming comnnections in a Do loop by provisioning a Reactant for each connection

        Parameters:
            tymth (Tymyth):  Timer object
            tock (float):  Pause time until the scheduler processes this look again

        Returns:
            Never

        """
        # start enter context
        self.wind(tymth)
        self.tock = tock
        yield self.tock

        while True:
            for ca, ix in list(self.server.ixes.items()):
                if ix.cutoff:
                    self.closeConnection(ca)
                    continue

                if ca not in self.rants:  # create Reactant and extend doers with it
                    rant = yield from self.connect(remoter=ix)
                    self.rants[ca] = rant
                    # add Reactant (rant) doer to running doers
                    self.extend(doers=[rant])  # open and run rant as doer

                if ix.tymeout > 0.0 and ix.tymer.expired:
                    self.closeConnection(ca)  # also removes rant

            yield

    def connect(self, remoter):
        # Get connection request
        while not remoter.rxbs:
            yield self.tock

        version, nmethods = struct.unpack("!BB", self.recv(remoter, 2))
        methods = self.recv(remoter, nmethods)

        if 0x00 not in methods:
            logger.info(f"No acceptable methods {methods}")
            remoter.tx(struct.pack("!BB", 0x05, 0xFF))  # No acceptable methods
            remoter.cutoff = True
            return

        # Send authentication choice (no auth)
        remoter.tx(struct.pack("!BB", 0x05, 0x00))

        # Get connection request
        while not remoter.rxbs:
            yield self.tock

        version, cmd, _, address_type = struct.unpack("!BBBB", self.recv(remoter, 4))

        if cmd != 0x01:  # Only support CONNECT method
            logger.info("No CONNECT method")
            remoter.tx(struct.pack("!BBBBIH", 0x05, 0x07, 0x00, 0x01, 0, 0))
            remoter.cutoff = True
            return

        if address_type == 0x01:  # IPv4
            address = socket.inet_ntoa(self.recv(remoter, 4))
        elif address_type == 0x03:  # Domain name
            domain_length = self.recv(remoter, 1)[0]
            address = self.recv(remoter, domain_length).decode()
        else:  # Unsupported address type
            logger.info("Unsupported address type")
            remoter.tx(struct.pack("!BBBBIH", 0x05, 0x08, 0x00, 0x01, 0, 0))
            remoter.cutoff = True
            return

        # Get port number
        port = struct.unpack('!H', self.recv(remoter, 2))[0]

        if (address, port) in self.targets:
            cid = self.targets[(address, port)]

            # create UUID for connection
            logger.info(f"ESSR protecting connection to {address}:{port} for {cid}")

            rant = ESSRForwardReactant(tymth=self.tymth, router=self.router, src=self.src, targets=self.targets,
                                       msgs=self.msgs, cues=self.cues, remoter=remoter, address=address, port=port)
            self.msgParser.register(rant)
            return rant

        else:
            logger.info(f"Creating forward pass through for {address}:{port}")
            # Create connection to remote server
            rant = ProxyReactant(tymth=self.tymth, router=self.router, src=self.src, targets=self.targets,
                                 msgs=self.msgs, cues=self.cues, remoter=remoter, address=address, port=port)
            return rant

    @staticmethod
    def recv(remoter, cnt: int):
        data = remoter.rxbs[0:cnt]
        del remoter.rxbs[0:cnt]
        return data

    def closeConnection(self, ca):
        """
        Close and remove connection given by ca and remove associated rant at ca.
        """

        if ca in self.server.ixes:  # remoter still there
            self.server.ixes[ca].serviceSends()  # send final bytes to socket
        self.server.removeIx(ca)
        if ca in self.rants:  # remove rant (Reactant) if any
            rant = self.rants[ca]
            rant.close()
            self.remove([self.rants[ca]])  # close and remove rant from doers list
            del self.rants[ca]


class ESSRForwardReactant(doing.DoDoer):
    """
         SOCKS5 TCP-only Reactant DoDoer for forwarding client connections
    """

    def __init__(self, router, src, targets, remoter, address, port, msgs=None, cues=None, doers=None, **kwa):
        """
        Initialize instance.

        Inherited Parameters:
            tymist is  Tymist instance
            tock is float seconds initial value of .tock
            doers is list of doers (do generator instancs or functions)

        Parameters:
            router (Router): The Router object for managing routes.
            src (str): qb64 identifier prefix of data source
            remoter is TCP Remoter instance
            doers is list of doers (do generator instances, functions or methods)

        """
        self.router = router
        self.src = src
        self.targets = targets
        self.cues = cues if cues is not None else decking.Deck()

        self.remoter = remoter  # use remoter for both rx and tx
        self.address = address
        self.port = port
        self.xip = coring.randomNonce()

        self.msgs = msgs if msgs is not None else decking.Deck()

        doers = doers if doers is not None else []
        doers.extend([doing.doify(self.forwardDo)])

        super(ESSRForwardReactant, self).__init__(doers=doers, **kwa)
        if self.tymth:
            self.remoter.wind(self.tymth)

    def wind(self, tymth):
        """
        Inject new tymist.tymth as new ._tymth. Changes tymist.tyme base.
        Updates winds .tymer .tymth
        """
        super(ESSRForwardReactant, self).wind(tymth)
        self.remoter.wind(tymth)

    def close(self):
        """
        Send SOCKS fin message to tell remote gateway to close connection.

        """
        payload = dict(
            address=self.address,
            port=self.port,
            xip=self.xip,
        )

        hab = self.router.hab(self.src)

        logger.info(f"sending fin for {payload}")
        exn, _ = exchanging.exchange(route="/socks/fin",
                                     payload=payload,
                                     sender=hab.pre)
        ims = hab.endorse(serder=exn, last=False, pipelined=False)
        atc = ims[exn.size:]

        cue = dict(i=Procs.sockssrv, c={}, a=dict(serder=exn.ked, atc=atc.decode("utf-8")))
        self.cues.append(cue)

    def forwardDo(self, tymth=None, tock=0.0, **opts):
        """ Package chunks in /socks/req exn messages for encryption and signing  in pipeline.

        Parameters:
            tymth (Tymyth):  Timer object
            tock (float):  Pause time until the scheduler processes this look again
            **opts (dict): kwargs that contains address, port, cid and eid of connection

        Returns:
            Never

        """
        # start enter context
        self.wind(tymth)
        self.tock = tock
        yield self.tock

        addr = struct.unpack("!I", socket.inet_aton(self.address))[0]
        self.remoter.tx(struct.pack("!BBBBIH", 0x05, 0x00, 0x00, 0x01, addr, self.port))
        logger.info("ESSR Success sent")

        while True:
            if self.remoter.rxbs:
                data = self.recv(8192)
                dig = core.Diger(ser=data, code=core.MtrDex.Blake3_256).qb64
                payload = dict(
                    body=dig,
                    address=self.address,
                    port=self.port,
                    xip=self.xip,
                )

                hab = self.router.hab(self.src)

                exn, _ = exchanging.exchange(route="/socks/req",
                                             payload=payload,
                                             sender=hab.pre,
                                             )
                ims = hab.endorse(serder=exn, last=False, pipelined=False)
                ims.extend(counting.Counter(code=counting.CtrDex_1_0.ESSRPayloadGroup, count=1, gvrsn=Vrsn_1_0).qb64b)
                texter = coring.Matter(raw=data, code=coring.MtrDex.Bytes_L0)
                ims.extend(texter.qb64b)

                atc = ims[exn.size:]

                cue = dict(i=Procs.sockssrv, c={}, a=dict(serder=exn.ked, atc=atc.decode("utf-8")))
                self.cues.append(cue)

                hab.db.essrs.rem(keys=(exn.said,))
                hab.db.epath.rem(keys=(exn.said,))

            yield self.tock

    def recv(self, cnt: int):
        data = self.remoter.rxbs[0:cnt]
        del self.remoter.rxbs[0:cnt]
        return data

    def sendMessage(self, msg, label=""):
        """
        Sends message msg and loggers label if any
        """
        self.remoter.tx(msg)  # send to remote
        hab = self.router.hab(self.src)
        logger.info("SOCKS Server %s: sent %s: %d", hab.name,
                    label, len(msg))


class ProxyReactant(doing.DoDoer):
    """
         SOCKS5 TCP-only Reactant DoDoer for forwarding client connections
    """

    def __init__(self, router, src, targets, remoter, address, port, msgs=None, cues=None, doers=None, **kwa):
        """
        Initialize instance.

        Inherited Parameters:
            tymist is  Tymist instance
            tock is float seconds initial value of .tock
            doers is list of doers (do generator instancs or functions)

        Parameters:
            router (Router): The Router object for managing routes.
            src (str): qb64 identifier prefix of data source
            remoter is TCP Remoter instance
            doers is list of doers (do generator instances, functions or methods)

        """
        self.router = router
        self.src = src
        self.targets = targets
        self.cues = cues if cues is not None else decking.Deck()

        self.remoter = remoter  # use remoter for both rx and tx
        self.client = tcp.Client(host=address, port=port)
        self.msgs = msgs if msgs is not None else decking.Deck()

        doers = doers if doers is not None else []
        doers.extend([tcp.ClientDoer(self.client), doing.doify(self.proxyDo)])

        super(ProxyReactant, self).__init__(doers=doers, **kwa)
        if self.tymth:
            self.remoter.wind(self.tymth)

    def wind(self, tymth):
        """
        Inject new tymist.tymth as new ._tymth. Changes tymist.tyme base.
        Updates winds .tymer .tymth
        """
        super(ProxyReactant, self).wind(tymth)
        self.remoter.wind(tymth)

    def close(self):
        """ No op for proxy class """
        pass

    def proxyDo(self, tymth=None, tock=0.0, **kwa):
        """  Pass-through proxy of data to remote server, no special processing

        Parameters:
            tymth (Tymyth):  Timer object
            tock (float):  Pause time until the scheduler processes this look again

        Returns:
            Never

        """

        # start enter context
        self.wind(tymth)
        self.tock = tock
        yield self.tock

        while not self.client.open():
            yield self.tock

        bind_address = self.client.cs.getsockname()

        # Send success response
        addr = struct.unpack("!I", socket.inet_aton(bind_address[0]))[0]
        port = bind_address[1]
        self.remoter.tx(struct.pack("!BBBBIH", 0x05, 0x00, 0x00, 0x01, addr, port))
        logger.info("Success sent")

        while True:
            if self.remoter.rxbs:
                data = self.recv(8192)
                self.client.tx(data)

            if self.client.rxbs:
                data = self.client.rxbs[0:8192]
                del self.client.rxbs[0:8192]
                self.remoter.tx(data)

            yield self.tock

    def recv(self, cnt: int):
        data = self.remoter.rxbs[0:cnt]
        del self.remoter.rxbs[0:cnt]
        return data


class SocksSrcProc:
    def __init__(self, router, name, host, port, src, dests, params):
        self.router = router
        self.hby = self.router.hby
        self.name = name
        self.src = src
        self.dests = dests
        self.msgs = decking.Deck()
        self.cues = decking.Deck()

        self.host = host
        self.port = port
        self.params = params
        self.server = tcp.Server(host=host, port=port)

        if not self.server.reopen():
            raise RuntimeError(f"cannot create tcp server on port {port}")

        self.directant = Directant(router=router, src=src, dests=dests, server=self.server,
                                   msgs=self.msgs, cues=self.cues)

        self.doers = [self.directant, tcp.ServerDoer(server=self.server)]

    @property
    def inbound(self):
        return self.msgs

    @property
    def outbound(self):
        return self.cues

    def service(self):
        """"""
        pass

    def close(self):
        """"""
        pass


class MessageParser(doing.Doer):

    def __init__(self, router, name, params, msgs=None):
        self.router = router
        self.rants = {}
        self.msgs = msgs if msgs is not None else decking.Deck()

        self.handler = SOCKSResponseHandler(router=self.router, params=params)
        pong = pinging.PongHandler(rt=self.router.rt, name=name)
        self.exc = exchanging.Exchanger(hby=self.router.hby, handlers=[self.handler, pong])
        self.parser = parsing.Parser(exc=self.exc)
        super(MessageParser, self).__init__()

    def register(self, rant):
        self.rants[rant.xip] = rant

    def recur(self, tyme):
        while self.msgs:
            msg = self.msgs.pull()
            try:
                self.parseMessage(msg)
            except Exception as e:
                logger.error(f"error={e} message parser decoding msg={len(msg)}")

        while self.handler.cues:
            rep = self.handler.cues.pull()
            data = rep["data"]
            xip = rep["xip"]

            rant = self.rants.get(xip)
            if rant:
                rant.sendMessage(data)

    def parseMessage(self, msg):
        payload = msg['a']
        if "serder" not in payload or "atc" not in payload:
            raise ValueError(f"invalid message to dessr proc={msg}")

        serder = serdering.SerderKERI(sad=payload['serder'])
        if serder.ilk != Ilks.exn:
            raise ValueError(f"invalid event to httpsrv proc={serder.ked}")

        atc = payload['atc']
        ims = bytearray(serder.raw)
        ims.extend(atc.encode("utf-8"))

        self.parser.parseOne(ims=ims)


class SOCKSResponseHandler:
    """
    Handler for HTTP response messages received from proxied calls on a cooresponding HTTP or HTTPCALL process

    on
        {
           "v": "KERI10JSON00011c_",                               // KERI Version String
           "t": "exn",                                             // peer to peer message ilk
           "d": "EAhDiMFIINHBIn139nSG7QlNj7Sa2YHdZDIvzRYylQeE",
           "dt": "2020-08-22T17:50:12.988921+00:00"
           "r": "/socks/rep",
           "q": {
            }
           "a": '{
              "d": "6AA-AABWcUNwTFZON3I4WV9tV1VRSDFpWS10WW5RMjVFb3V4SWtheGxHZHRreWdRM1oxYzVx...",
              "i": "EAhDiMFIINHBIn139nSG7QlNj7Sa2YHdZDIvzRYylQeE"
           }
        }-AABAA1o61PgMhwhi89FES_vwYeSbbWnVuELV_jv7Yv6f5zNiOLnj1ZZa4MW2c6Z_vZDt55QUnLaiaikE-d_ApsFEgCA

    """

    resource = "/socks/rep"

    def __init__(self, router, cues=None, params=None):
        """

        Parameters:
            router (Router): The Router object for managing routes.
            cues (Deck): message storage for store and forward

        """
        self.router = router
        self.hby = router.hby

        self.cues = cues if cues is not None else decking.Deck()
        self.params = params or {}

    def handle(self, serder, attachments=None, essr=None):
        """

        This handler decrypts the the encrypted payload, verifies that the sender is in the encrypted payload
        and verifies that the recipient AID was signed as part of the package

        Parameters:
            serder (Serder): Serder of the IPEX protocol exn message
            attachments (list): list of tuples of root pathers and CESR SAD path attachments to the exn event
            essr (bytes):  essr attached bytes

        """

        # Get the response body
        if essr:
            dig = serder.ked['a']['body']
            diger = core.Diger(qb64=dig)
            if not diger.verify(ser=essr):
                logger.error(f"invalid http request body for event={serder.ked}, digest does not match body")
                return

            data = essr
        else:
            enc = serder.ked['a']['d']
            data = coring.Texter(qb64=enc).raw

        # Ensure that the encrypted sender is the one that also signed it
        cue = serder.ked['a']
        cue['data'] = data

        self.cues.append(cue)

        self.hby.db.essrs.rem(keys=(serder.said,))
        self.hby.db.epath.rem(keys=(serder.said,))
