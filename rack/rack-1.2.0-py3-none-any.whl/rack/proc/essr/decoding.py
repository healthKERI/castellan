# -*- encoding: utf-8 -*-
"""
rack.proc.essr.decoding module

"""
import time
import traceback
import cbor2 as cbor

from hio.base import doing
from hio.help import decking
from keri import help, kering
from keri.core import serdering, coring, parsing
from keri.kering import Ilks
from keri.peer import exchanging
from prometheus_client import Histogram

from rack.core import profiling
from rack.core.scheming import Procs

logger = help.ogler.getLogger()

REQUEST_TIME = Histogram('rack_dessr_duration_seconds', 'DESSR duration in seconds', ['src', 'dest'])
REQUEST_SIZE = Histogram('rack_dessr_size_bytes', 'DESSR decoded size in bytes', ['src', 'dest'],
                         buckets=profiling.SIZE_BUCKETS)


class Decodant:
    """A class to handle decoding operations for a specified source and destination.

    Attributes:
        hby (object): The HBY object for managing habitats.
        router (Router): The Router object for managing routes.
        src (str): The source identifier.
        handler (DecodeHandler): The handler for decoding.
        exc (exchanging.Exchanger): The exchanger for handling exchanges.
        parser (parsing.Parser): The parser for parsing messages.
        msgs (decking.Deck): The deck for holding messages.
    """

    def __init__(self, router, encryption_target, params=None):
        """Initializes the Decodant class with the specified parameters.

        Parameters:
            router (Router): The Router object for managing routes.
            src (str): The source identifier.
            dest (str): The destination identifier.
            params (dict, optional): Additional parameters for the DecodeHandler. Defaults to None.

        Raises:
            kering.ConfigurationError: If the destination is not a valid habitat.
        """
        self.router = router
        self.hby = self.router.hby
        self.encryption_target = encryption_target
        self.ctxs = dict()

        self.handler = DecodeHandler(router=self.router, encryption_target=encryption_target,
                                     params=params, ctxs=self.ctxs)
        self.exc = exchanging.Exchanger(hby=self.hby, handlers=[self.handler])
        self.parser = parsing.Parser(exc=self.exc)

        self.msgs = decking.Deck()

    @property
    def cues(self):
        """Property to get cues from the handler.

        Returns:
            Deck: A list of cues from the DecodeHandler.
        """
        return self.handler.cues

    def decode(self, msg):
        """Decodes a message and processes it if it is valid.

        Parameters:
            msg (dict): The message to decode.

        Raises:
            ValueError: If the message or event is invalid.
        """
        payload = msg['a']
        if "serder" not in payload or "atc" not in payload:
            raise ValueError(f"invalid message to dessr proc={msg}")

        serder = serdering.SerderKERI(sad=payload['serder'])
        if serder.ilk != Ilks.exn or serder.ked['r'] != "/essr/req":
            raise ValueError(f"invalid event to dessr proc={serder.ked}")

        atc = payload['atc']
        if hasattr(atc, "encode"):
            atc = atc.encode("utf-8")

        ims = bytearray(serder.raw)
        ims.extend(atc)

        ctx = msg.get('ctx', {})
        self.ctxs[serder.said] = ctx

        self.parser.parseOne(ims=ims)

    def processMsgs(self):
        """Processes all messages in the deck.

        Decodes each message and logs any errors that occur during decoding.
        """
        while self.msgs:
            msg = self.msgs.pull()
            try:
                self.decode(msg)
            except Exception as e:
                print(traceback.format_exc())
                logger.error(f"error={e} essr decoding msg={len(msg)}")

    def processEscrows(self):
        """Processes escrows in the exchanger."""
        self.exc.processEscrow()

    def service(self):
        """Services the Decodant by processing messages and escrows."""
        self.processMsgs()
        self.processEscrows()


class DessrDoer(doing.Doer):
    """A doer class to handle the recurrent servicing of a Decodant.

    Attributes:
        decodant (Decodant): The Decodant object to be serviced.
    """

    def __init__(self, decodant, **kwa):
        """Initializes the DecodantDoer with the given Decodant.

        Args:
            decodant (Decodant): The Decodant object to be serviced.
            **kwa: Additional keyword arguments for the superclass initializer.
        """
        self.decodant = decodant
        super(DessrDoer, self).__init__(**kwa)

    def recur(self, tyme):
        """Calls the service method of the Decodant at each recurrence.

        Args:
            tyme (float): The current time.
        """
        self.decodant.service()


class DessrProc:
    """A doer class to process and handle decoding operations using a Decodant.

    Attributes:
        decodant (Decodant): The Decodant object for decoding operations.
    """

    def __init__(self, router, encryption_target):
        """Initializes the DessrProc with the given parameters.

        Args:
            router (Router): The Router object for managing routes.
            encryption_target (str): The destination identifier.
        """
        self.decodant = Decodant(router=router, encryption_target=encryption_target)

    @property
    def inbound(self):
        """Property to get messages from the Decodant.

        Returns:
            decking.Deck: The deck of messages from the Decodant.
        """
        return self.decodant.msgs


    @property
    def outbound(self):
        """Property to get cues from the Decodant.

        Returns:
            list: A list of cues from the Decodant.
        """
        return self.decodant.cues

    def service(self):
        self.decodant.service()

    def close(self):
        pass



class DecodeHandler:
    """
    Handler for essr encoded `exn` messages used to secure other messages intended for another recipient.
    This handler verifies the signer is correctly encryped in the payload and that the recipient was signed

    on
        {
           "v": "KERI10JSON00011c_",                               // KERI Version String
           "t": "exn",                                             // peer to peer message ilk
           "d": "EAhDiMFIINHBIn139nSG7QlNj7Sa2YHdZDIvzRYylQeE",
           "dt": "2020-08-22T17:50:12.988921+00:00"
           "r": "/essr/req",
           "q": {
            }
           "a": '{
              "d": "6AA-AABWcUNwTFZON3I4WV9tV1VRSDFpWS10WW5RMjVFb3V4SWtheGxHZHRreWdRM1oxYzVx...",
              "i": "EAhDiMFIINHBIn139nSG7QlNj7Sa2YHdZDIvzRYylQeE"
           }
        }-AABAA1o61PgMhwhi89FES_vwYeSbbWnVuELV_jv7Yv6f5zNiOLnj1ZZa4MW2c6Z_vZDt55QUnLaiaikE-d_ApsFEgCA

    """

    resource = "/essr/req"

    def __init__(self, router, ctxs, encryption_target, cues=None, params=None):
        """

        Parameters:
            router (Router): The Router object for managing routes.
            cues (Deck): message storage for store and forward

        """
        self.router = router
        self.hby = router.hby
        self.ctxs = ctxs
        self.encryption_target = encryption_target

        self.cues = cues if cues is not None else decking.Deck()
        self.params = params or {}

    def handle(self, serder, attachments=None, essr=None):
        """

        This handler decrypts the the encrypted payload, verifies that the sender is in the encrypted payload
        and verifies that the recipient AID was signed as part of the package

        Parameters:
            serder (Serder): Serder of the IPEX protocol exn message
            attachments (list): list of tuples of root pathers and CESR SAD path attachments to the exn event
            essr (bytes):  essr attached bytes

        """

        # Get the encrypted payload
        start = time.time()

        if essr:
            data = essr
        else:
            enc = serder.ked['a']['d']
            data = coring.Texter(qb64=enc).raw

        rp = serder.ked['rp']
        logger.info(f"Full ked for message that is being decoded {serder.ked}")
        try:
            hab = self.router.hab(rp)
        except kering.ConfigurationError:
            logger.info(f"dessr: invalid encryption target from msg for rp={rp}")
            return

        # Ensure the signed receiver is us
        if hab is None or not (hab.pre == self.encryption_target or hab.kever.delpre == self.encryption_target):
            logger.error(f"dessr: invalid /essr/req message, rp={rp} not one of us={self.encryption_target}")
            return

        # Decrypt it with our dest hab
        raw = hab.decrypt(data)
        size = len(raw)
        req = cbor.loads(raw)

        # Ensure that the encrypted sender is the one that also signed it
        sender = req["i"]
        payload = req['a']
        if sender != serder.ked['i']:
            logger.error(
                f"dessr: invalid essr req message, encrypted sender={sender} not equal to message signer={serder.ked['i']}")
            return

        # Ensure that we know about this sender
        if sender not in self.hby.kevers:
            logger.error(f"dessr: unknown src aid={sender}")
            return

        ctx = self.ctxs.get(serder.said)
        ctx["dessr"] = dict(originating_signer=sender)

        cue = dict(i=Procs.dessr, src=sender, dest=rp, c=self.params, ctx=ctx, a=payload)
        self.cues.append(cue)

        decode_time = time.time() - start
        kwargs = dict(src=sender, dest=hab.pre)
        REQUEST_TIME.labels(**kwargs).observe(decode_time)
        REQUEST_SIZE.labels(**kwargs).observe(size)

        hab.db.essrs.rem(keys=(serder.said,))
        hab.db.epath.rem(keys=(serder.said,))
