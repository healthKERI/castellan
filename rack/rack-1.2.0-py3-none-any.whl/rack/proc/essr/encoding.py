# -*- encoding: utf-8 -*-
"""
rack.proc.essr.encoding module

"""
import math
import time
import cbor2 as cbor

import pysodium
from hio.base import doing
from hio.help import decking
from keri import core
from keri import help
from keri.core import coring, MtrDex
from keri.core.counting import CtrDex_1_0
from keri.help import helping
from keri.kering import Vrsn_1_0, ConfigurationError
from keri.peer import exchanging
from prometheus_client import Histogram

from rack.core import profiling, scheduling
from rack.core.scheming import Procs

logger = help.ogler.getLogger()

REQUEST_TIME = Histogram('rack_essr_duration_seconds', 'ESSR duration in seconds', ['src', 'dest'])
REQUEST_SIZE = Histogram('rack_essr_size_bytes', 'ESSR encoded size in bytes', ['src', 'dest'],
                         buckets=profiling.SIZE_BUCKETS)

CHUNK_SIZE = 65536


class Encoder:

    def __init__(self, router, signer, encryption_target=None):
        """  Create encoder to sign and encrypt messages

        If self.encryption_target is None, it must retrieve the target for encryption from the message, otherwise use self.encryption_target

        Args:
            router (Router):  Route factory and manager
            signer (str): qb64 AID of signing for all messages
            encryption_target (str): qb64 AID of destination for encryption or NONE if dest should be extracted from the context

        """
        self.router = router
        self.hby = self.router.hby
        self.signer = signer
        self.encryption_target = encryption_target
        self.cues = decking.Deck()
        self.msgs = decking.Deck()

    def encode(self, msg):
        ctx = msg.get("ctx", {})
        start = time.time()

        hab = self.router.hab(self.signer)  # Signer is always hardcoded

        # create the payload to be encrypted... must include sender
        payload = dict(i=hab.pre, a=msg['a'])

        # Must extract the encryption target from the message context from DESSR or get is from self.encryption_target
        target = ctx.get("dessr", {}).get("originating_signer", None) or self.encryption_target
        if target is None:
            raise ConfigurationError(f"Unable to determine encryption target {ctx}")

        rkever = self.router.kever(target)

        # convert signing public key to encryption public key
        pubkey = pysodium.crypto_sign_pk_to_box_pk(rkever.verfers[0].raw)
        raw = pysodium.crypto_box_seal(cbor.dumps(payload), pubkey)
        diger = coring.Diger(ser=raw, code=MtrDex.Blake3_256)

        exn, _ = exchanging.exchange(route="/essr/req",
                                     diger=diger,
                                     sender=hab.pre,
                                     recipient=rkever.prefixer.qb64,  # Must sign receiver
                                     date=helping.nowIso8601())

        ims = hab.endorse(serder=exn, pipelined=False)

        size = len(raw)
        chunks = math.ceil(size / CHUNK_SIZE)
        ims.extend(core.Counter(code=CtrDex_1_0.ESSRPayloadGroup, count=chunks, gvrsn=Vrsn_1_0).qb64b)
        for idx in range(chunks):
            start = idx * CHUNK_SIZE
            end = start + CHUNK_SIZE
            texter = coring.Matter(raw=raw[start:end], code=MtrDex.Bytes_L0)
            ims.extend(texter.qb64b)

        hab.psr.parseOne(ims=bytes(ims))

        atc = ims[exn.size:]

        hab.db.essrs.rem(keys=(exn.said,))
        hab.db.epath.rem(keys=(exn.said,))
        self.router.rt.encs.add(keys=(hab.kever.serder.said,), val=exn.said)

        encode_time = time.time() - start

        kwargs = dict(src=self.signer, dest=self.encryption_target)
        REQUEST_TIME.labels(**kwargs).observe(encode_time)
        REQUEST_SIZE.labels(**kwargs).observe(size)

        return dict(i=Procs.essr,
                    src=self.signer,
                    dest=self.encryption_target,
                    c=dict(s=self.signer, d=self.encryption_target),
                    ctx=ctx,
                    a=dict(serder=exn.ked, atc=atc))

    def processMsgs(self):
        if self.msgs:
            msg = self.msgs.pull()
            try:
                cue = self.encode(msg)
                self.cues.append(cue)
            except Exception as e:
                logger.error(f"error={e} essr encoding msg")


class EssrDoer(doing.Doer):

    def __init__(self, encoder, **kwa):
        self.encoder = encoder

        super(EssrDoer, self).__init__(**kwa)

    def recur(self, tyme):
        self.encoder.service()


class EssrProc:
    def __init__(self, router, signer, encryption_target=None, **kwa):
        self.encoder = Encoder(router=router, signer=signer, encryption_target=encryption_target)

        # if there are any keys left, use them to as parameters to create a message anchorer
        self.anchorer = None
        if any(key in kwa for key in ('maximum', 'interactions', 'rotations', 'frequency')):
            self.anchorer = scheduling.MessageAnchorer(router=router, signer=signer, **kwa)

    @property
    def inbound(self):
        return self.encoder.msgs

    @property
    def outbound(self):
        return self.encoder.cues

    def service(self):
        self.encoder.processMsgs()
        if self.anchorer:
            self.anchorer.processMaximums()
            self.anchorer.schedule.run_pending()

    def close(self):
        pass

